function [ x,beta,pf, UU,xx,gg ,n_vector ,g_num] = JC_based_method_line_search_min_g( u,std,type )
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];    mpp_tmp_array=[];
ab_array=[];
n_k_array=[];
weishu=num;  tmp_bjc=bjc;  tmp_u=u;  method=0;  g_num=0;
nn=0; t_i=0.5;
 
%---------��ͼ---------------------
hold off;
if aa.type==9||aa.type==10||aa.type==31
    f0=fun(u,type);%���ֵ
    k1=-5; k2=5;
    if aa.type==9
            k1=-5; k2=5;
    elseif aa.type==10
            k1=-6; k2=6;
    end
    length0=0.5;t_min=-1.8;t_max=f0*1;jingdu=1e-2;
    a1=k1;a2=k2;b1=k1;b2=k2;%k1=-1; k2=5;a1=k1;a2=k2;b1=k1;b2=k2;
    [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);
    x1_ori=x1*bjc(1)+u(1);x2_ori=x2*bjc(2)+u(2);
    Z=fun([x1_ori,x2_ori],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));  g=18.46154-74769.23*x1/x2^3
    t_min=-f0;t_max=f0;
    tt=t_min:(t_max-t_min)/3:t_max;%1e-10
    if aa.type~=31
        for i=1:size(tt,2)
            t_value=tt(i);
       [C,h] = contour(x1,x2,Z,t_value,'r');axis([a1 a2 b1 b2]); grid on;hold on;
        end
    end
    [C,h] = contour(x1,x2,Z,1e-8,'g');grid on;hold on;

    [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*bjc(1)+u(1);xx2_ori=xx2*bjc(2)+u(2);
    Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
    quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;
end





while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;  g_num=g_num+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==4||type==325 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==325
                    num_tmp=num;    
                 end   
                
%                 u=X.*(6.517-log(X));
%                 bjc=aa.bjc./aa.u.*X;
                %aa.u=250;aa.bjc=25; X=210;
                %https://blog.csdn.net/wanjiac/article/details/125057533 ������̫�ֲ� ��������
%                 logn_para_u=log(u(1:num).^2./(bjc(1:num).^2+u(1:num).^2).^0.5);
%                 logn_para_sigma=(log(  bjc(1:num).^2./u(1:num).^2+1)  ).^0.5;
%                 F_x=cdf('logn',X,logn_para_u,logn_para_sigma);
%                 inv_norm_F_x=icdf('normal',F_x,0,1);
%                 tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X,logn_para_u,logn_para_sigma);
%                 tmp_u=X-inv_norm_F_x.*tmp_bjc;
%                 bjc(1:num)=tmp_bjc;  u(1:num)=tmp_u;
%                 x_start_bj(1:num)= ( X-u(1:num) )./bjc(1:num);
%                u=365.8;bjc=54.9;X=u;
                X=x_start;
                VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
%                 logn_para_u=log(u.^2./(bjc.^2+u.^2).^0.5);
%                 logn_para_sigma=(log(  bjc.^2./u.^2+1)  ).^0.5;
%                 F_x=cdf('logn',X,logn_para_u,logn_para_sigma);
%                 inv_norm_F_x=icdf('normal',F_x,0,1);
%                 tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X,logn_para_u,logn_para_sigma);
%                tmp_u=X-inv_norm_F_x.*tmp_bjc;
                %bjc=tmp_bjc;  u=tmp_u;
                %x_start_bj= ( X-tmp_u )./tmp_bjc;
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
%                    mu=100;sigma=12;
%                    aEv=sqrt(6)*sigma/pi;  uEv=-psi(1)*aEv-mu;
%                    FQ=1-evcdf(-150,uEv,aEv);%
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==430  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   aEv=sqrt(6)*bjc((5:7))/pi; uEv=-psi(1)*aEv-u((5:7));
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X((5:7)),uEv,aEv);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc((5:7))=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u((5:7))=X((5:7))-inv_norm_F_x.*tmp_bjc((5:7));  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   %x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            end         
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        %norm(UU(end-1,:)-x_start_bj)
    end
    %%delta0
%     if method~=1
            %if nn<=3%JC��
            %1)JC������MPP��
                [ x,U_k_new,diff_g_u_bj,beta  ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type); g_num=g_num+weishu;
                 plot(U_k_new(1),U_k_new(2),'o');  %g_start_x=fun(x,type);
                 diff=[ diff;  diff_g_u_bj];   
        %          mpp_tmp=(pinv(diff_g_u_bj)*(diff_g_u_bj*x_start_bj'-g_start))';  
        %          mpp_tmp=x_start_bj-diff_g_u_bj*g_start;
                 ab=-diff_g_u_bj/norm(diff_g_u_bj)-x_start_bj/norm(x_start_bj);
                 %ab=-diff_g_u_bj-(-diff_g_u_bj*x_start_bj'*x_start_bj)/norm(x_start_bj)^2; %ab=ab/norm(ab);
                 ab_array=[ab_array;ab];
            %2)���ж�
            if nn>=2
            u3=U_k_new;u2=UU(end,:);u1=UU(end-1,:);
            n3=u3/norm(u3);  n2=u3/norm(u2);  n1=u3/norm(u1);
            %hui_k=(n3-n2)*(n2-n1)';  
            hui_k=(u3-u2)*(u2-u1)';
            if nn==6
                t=1;
            end
                if(hui_k<-aa.jingdu) || norm(u3-u2)>norm(u2-u1)   %˵���񵴣����¼���MPP 


                %line search
                    %[ x_tmp_k,U_tmp_k,diff_g_u_bj ] =JC_compute_mpp(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
                    U_pt_start=x_start_bj;  U_pt_end=U_k_new;     
                    if method==0
%                             g_pt_start=g_start;  g_pt_end=fun(U_pt_end.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
%                             diff_pt_start=diff_g_u_bj;
%                             diff_pt_end=diff_chafen(U_pt_end,delta0,tmp_u,tmp_bjc,g_start,type); g_num=g_num+weishu+1;
                %             
                %             U_k_new=(diff_pt_start-diff_pt_end)*(g_pt_end-g_pt_start+diff_pt_start*U_pt_start'-diff_pt_end*U_pt_end')/norm(diff_pt_start-diff_pt_end)^2;
                %            
                            ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:));
                            v_i=U_pt_start+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start);
                            g_v_i=fun(v_i.*aa.bjc+aa.u,type);  g_num=g_num+1;

                            plot(v_i(1),v_i(2),'+'); 
                %             U_k_new=v_i*norm(U_pt_start);
                %             beta_k=norm(U_k_new);
                            if nn==4
                               t=1; 
                            end
                %             [ beta_k,t_i_new,g_u_k ] =fun_newton(U_pt_start,U_pt_end,tmp_u,tmp_bjc,diff_g_u_bj,type,0.5,g_start);
                %             v_i=U_pt_start+t_i_new*(U_pt_end-U_pt_start);
                %             plot(v_i(1),v_i(2),'+'); 
                %             beta_i=norm(v_i);
                           if_plot=0;jianju_mpp=norm(UU(end,:)-UU(end-1,:));if_plot=0;
                           %�ҳ�ԭ����MPP֮���ֱ�� �� g(u)=0�Ľ��� 
                           [U_k_new,g_U_k_new,g_num0]=fun_find_g0_mpp(0,v_i,tmp_u,tmp_bjc,type,g_v_i,delta0,jianju_mpp,if_plot);
                           [ t_i,U_k_new,g_U_k_new,g_num0 ] =fun_Steffensen(norm(v_i),g_v_i,type,v_i,delta0,tmp_u,tmp_bjc,0,if_plot);
                           beta_k=norm(U_k_new);  g_num=g_num+g_num0;
                           if(g_U_k_new<aa.jingdu)
                                 method=1;
                           end
                    else%method==1
                           if nn==5
                                t=1;
                           end
%                            delta_ti=delta0; if_plot=1;  jianju_mpp=norm(UU(end,:)-UU(end-1,:));
%                            [U_k_new,g_U_k_new,t_i_end,g_num2]=fun_find_best_mpp(x_start_bj,ab,tmp_u,tmp_bjc,type,if_plot,g_start,delta_ti,jianju_mpp);
%                            beta_k=norm(U_k_new); g_num=g_num+g_num2;
                           ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:));
                           v_i=x_start_bj+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start);
                           %U_k_new=x_start_bj+norm(ab)/(norm(ab)+norm(ab_array(end-1,:)))*(U_k_new-x_start_bj);
                           %v_i=U_k_new;
                           g_v_i=fun(v_i.*aa.bjc+aa.u,type);  g_num=g_num+1; jianju_mpp=norm(UU(end,:)-UU(end-1,:));
                           [U_k_new,g_U_k_new,g_num0]=fun_find_g0_mpp(0,v_i,tmp_u,tmp_bjc,type,g_v_i,delta0,jianju_mpp,if_plot); g_num=g_num+g_num0;
                           beta_k=norm(U_k_new);
%                            ramba=(-diff_g_u_bj*x_start_bj')/norm(-diff_g_u_bj)/norm(x_start_bj); 
%                            %ramba=exp(acos((-diff_g_u_bj*x_start_bj')/norm(-diff_g_u_bj)/norm(x_start_bj)));
%                            v_i=U_pt_start+ramba*(-diff_g_u_bj)/norm(diff_g_u_bj);
%                            v_i=U_pt_start+ramba*(ab)/norm(ab);
%                            plot(v_i(1),v_i(2),'+');
%                            g_v_i=fun(v_i.*tmp_bjc+tmp_u,type);
%                            [ t_i,U_k_new,g_U_k_new,g_num ] =fun_Steffensen(norm(v_i),g_v_i,type,v_i,delta0,tmp_u,tmp_bjc,0,if_plot);
%                            plot(U_k_new(1),U_k_new(2),'o');
                           t=1;
                          %U_pt_start/norm(U_pt_start)+diff_g_u_bj/norm(diff_g_u_bj);
        %                    U_pt_end=U_pt_start-diff_g_u_bj/norm(diff_g_u_bj)/norm(U_pt_start); v_i=U_pt_end-0;
        %                    
        %                    %ab/
        %                    plot(U_pt_end(1),U_pt_end(2),'r+'); 
        %                    g_pt_end=fun(U_pt_end.*tmp_bjc+tmp_u,type); 
        %                    if_plot=0;
        %                   [ t_i,U_k_new,g_U_k_new,g_num ] =fun_Steffensen(norm(U_pt_end),g_pt_end,type,v_i,delta0,tmp_u,tmp_bjc,0,if_plot);

        %                   vector=ab/norm(ab); if_plot=1;
        %                   delta_ti=delta0;
        %                   x_start_bj_delta=x_start_bj+vector*(0+delta_ti);
        %                   g_start_delta=fun(x_start_bj_delta.*tmp_bjc+tmp_u,type); 
        %                   k_ti=(g_start_delta-g_start)/delta_ti;
        %                   [ t_i,u_i,f_t_i,g_num ] =fun_Steffensen_diff(0,k_ti,type,vector,delta_ti,tmp_u,tmp_bjc,x_start_bj,if_plot);
                          t=1;
                           %v_i=U_pt_end-U_pt_start;  g_start=fun((U_pt_start+U_pt_end)*0.5.*aa.bjc+aa.u,type);
                           %[ t_i,U_k_new,g_U_k_new,g_num ] =fun_Steffensen(0.5,g_start,type,v_i,delta0,tmp_u,tmp_bjc,U_pt_start);
                    end
        %             beta_inital=norm(v_i)*0.9;
        %             g_inital=fun(beta_inital*v_i/norm(v_i).*aa.bjc+aa.u,type);

                   %[ beta_k,g_mpp ,g_num] =fun_gexianfa(beta_inital,norm(v_i),g_inital,g_u_k,v_i,type);
        %             U_k_new=beta_k*v_i/norm(v_i);
        %             x_new=tmp_u+tmp_bjc.*U_k_new;

        %             U_k_new=v_i;
                    plot(U_k_new(1),U_k_new(2),'*'); 
        %             U_tmp_k=U_k_new;
        %             U_k=x_start_bj;
        %             v_i=U_k+t_i*(U_tmp_k-U_k);
        %             g_u_k=g_start;
        %             beta_k=  -(g_u_k-diff_g_u_bj*U_k')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);
        %             U_k_new=-beta_k*v_i/norm(v_i);
                    array_beta=[array_beta;beta_k];

                else
                    array_beta=[array_beta;beta];
                    %mpp_tmp_array=[ mpp_tmp_array; mpp_tmp ];
                end
            else
                array_beta=[array_beta;beta];  
                %mpp_tmp_array=[ mpp_tmp_array; mpp_tmp ];
            end
%     else%method==1
%                           [ x,U_k_new,diff_g_u_bj,beta  ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
%                           ab=-diff_g_u_bj-(-diff_g_u_bj*x_start_bj'*x_start_bj)/norm(x_start_bj)^2;
%                            ramba=1/exp(acos((diff_g_u_bj*x_start_bj')/norm(-diff_g_u_bj)/norm(x_start_bj)));
%                            v_i=x_start_bj+ramba*ab/norm(ab);
%                            plot(v_i(1),v_i(2),'+');
%                            g_v_i=fun(v_i.*tmp_bjc+tmp_u,type);
%                            [ t_i,U_k_new,g_U_k_new,g_num ] =fun_Steffensen(norm(v_i),g_v_i,type,v_i,delta0,tmp_u,tmp_bjc,0,if_plot);
%                            plot(U_k_new(1),U_k_new(2),'o');
%                            t=1;
%                            array_beta=[array_beta;beta]; 
%     end

    n_k_array=[n_k_array; U_k_new/norm(U_k_new) ];
    
    
    if size(diff,1)>=2
        error_diff=[error_diff; diff(end,:)-diff(end-1,:)];
        error=[error;  norm(error_diff(end,:))];
    end
    
    %t=1 
    %nn
    %kkt=[kkt ;U_k_new/norm(U_k_new)+diff_g_x_bj/norm(diff_g_x_bj)];
       %theta(nn,:)=acos(U_k_new*diff_g_x_bj'/norm(U_k_new)/norm(diff_g_x_bj))/pi*180;
   if nn>=1
%       theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
%       theta(nn,:)=acos(theta(nn,:))/pi*180;
   end
            if nn==2
               t=1; 
            end
    if nn>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
            
        end
    end
    x_start_bj=U_k_new;
    x=x_start_bj.*tmp_bjc+tmp_u;
    xx=[xx;X];
    nn=nn+1;
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
    %t1 = toc  % ���㾭����ʱ��
    aa.nn=nn;
end
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)];  UU=[UU; U_k_new];
aa.gg=gg; aa.xx=xx;aa.UU=UU;% aa.kkt=kkt;  aa.theta=theta; 
% aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
% aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
 n_vector=[];
%  for i=2:size(UU,1)
%     n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
%  end
%  UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
t=1;
end


function [ t_i,u_i,f_t_i,g_num ] =fun_Steffensen(t_inial,g_inial,type,vector,delta0,tmp_u,tmp_bjc,start_u0,if_plot)%https://mp.weixin.qq.com/s/JoPuDvjgX8zY6C56Y4elOw
global aa;
   g_num=0; iter_num=0;
   t_i=t_inial;   f_t_i=g_inial;  array_t_i=[t_i];  array_f_t_i=[f_t_i];
   diff_g_v_i=vector/norm(vector); 
   u_i=start_u0+t_i*diff_g_v_i; 
   while 1
       %1)����v_i���ݶȷ���

       %[diff_g_v_i]=diff_chafen(v_i,delta0,tmp_u,tmp_bjc,g_v_i,type);g_num=g_num+size(v_i,1);
       
       %2)����t_i=0.5ʱ��Ӧ�ĵ�u_i
        %u_i=v_i+t_i*diff_g_v_i/norm(diff_g_v_i);
       if iter_num>=1
           u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);
           if if_plot==1
               plot(u_i(1),u_i(2),'*');
           end
           f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);   g_num=g_num+1;  
           array_f_t_i=[array_f_t_i;f_t_i]; 
           array_t_i=[array_t_i; t_i];
       end

        %f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  
%         y=t_i+f_t_i;
%         y=f_t_i;
%         y_u_i_tmp=start_u0+y*diff_g_v_i/norm(diff_g_v_i);
%         z=y+fun(y_u_i_tmp.*tmp_bjc+tmp_u,type);
%         z=fun(y_u_i_tmp.*tmp_bjc+tmp_u,type);
%         t_i_new=t_i-(y-t_i)^2/(z-2*y+t_i);
        
        t_i_tmp=t_i+f_t_i;
        u_i_tmp=start_u0+t_i_tmp*diff_g_v_i/norm(diff_g_v_i);
        f_t_i_tmp=fun(u_i_tmp.*tmp_bjc+tmp_u,type);   g_num=g_num+1;
        t_i_new=t_i-(f_t_i)^2/(f_t_i_tmp-f_t_i);

        %plot(u_i_tmp(1),u_i_tmp(2),'+'); 
        if(abs(f_t_i)<aa.jingdu*1e-2) %||  (abs(t_i_new-t_i)<aa.jingdu*1e-2)
            %u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);  f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
            break;
        end
        t_i=t_i_new;  array_t_i=[array_t_i; t_i];
        
        iter_num=iter_num+1;
   end
end



function [ u_x,g_x,g_num ] =fun_gexianfa(u1,u2,g1,g2,v_i,type)
global aa;
            if aa.nn==3
               t=1; 
            end
     g_num=0;
     while 1
        u_x=u2-g2*(u2-u1)/(g2-g1);
        u_point=u_x*v_i/norm(v_i);
        g_x=fun(u_point.*aa.bjc+aa.u,type);  g_num=g_num+1;
        if(abs(g_x)<aa.jingdu*1e-3)
            break;
        else
            if(abs(g2)<abs(g1))
                u1=u_x;
                g1=g_x;
            else
                u2=u_x;
                g2=g_x;
            end
        end
     end
end
function [ beta_k,g_mpp ] =fun_beta_ti(t_i,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,if_plot,g_pt_start)
global aa;
            v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
            g_v_i=fun(v_i.*aa.bjc+aa.u,type);
            
            
%             g_start=g_pt_start;%fun(X_pt_start,type);   %g_end=fun(X_pt_end,type);
%             g_u_k=g_start;
%             U_k=U_pt_start;
% 
%             
%             beta_inital=norm(v_i)*0.9;
%             g_inital=fun(beta_inital*v_i/norm(v_i).*aa.bjc+aa.u,type);
%             
%            [ beta_k,g_mpp ,g_num] =fun_gexianfa(beta_inital,norm(v_i),g_inital,g_v_i,v_i,type);
%             %beta_k=  -(g_u_k-diff_g_u_bj*U_k')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);
% 
%             uu=beta_k*v_i/norm(v_i);
%             x_ori_uu=uu.*aa.bjc+aa.u;
%             %g_start=fun(x_ori_uu,type);
%             if if_plot==1
%                %plot(x_ori_uu(1),x_ori_uu(2),'*'); 
%             end
            
            beta_k=g_v_i;
            g_mpp=g_v_i;
end

function [ K_ti,g_mpp,beta_k ] =fun_K_ti(t0,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,delta,if_fist_compute,g_pt_start)
            t_x=t0;
            [ beta_k,g_mpp ] =fun_beta_ti(t_x,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,if_fist_compute,g_pt_start);

            [ beta_delta ] =fun_beta_ti(t_x+delta,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,0,g_pt_start);
            
            diff_beta_ti=(beta_delta-beta_k)/delta;
            K_ti=diff_beta_ti;
end

%function [ x,U_k_new,diff_g_u_bj,beta ] =fun_newton(X,x_start_bj,tmp_u,tmp_bjc,diff_g_u_bj,type,t0)
function [ beta_k,t_i_new,g_u_k ,g_compute_num] =fun_newton(U_pt_start,U_pt_end,tmp_u,tmp_bjc,diff_g_u_bj,type,t0,g_start)
global aa;
            distance=norm(U_pt_start-U_pt_end);
            X_pt_start=U_pt_start.*tmp_bjc+tmp_u;
            X_pt_end=U_pt_end.*tmp_bjc+tmp_u;  g_compute_num=0;
            %delta_1=min(distance*0.01,1e-6);
            
            
            t_i=t0;
            
            iter=0;g_new=1e10;t_new=0.5;  t_limit_1=0; t_limit_2=1; t_array=[];  method_type=[]; K_ti_array=[];
            t_array_ori=[];
            jiange=min(abs(t_limit_2-t_limit_1)*0.01,1e-3);   jiange=abs(t_limit_2-t_limit_1)*0.01;    
            while(1)
                iter=iter+1;
                %1)����K(ti)
                t_1=t_i;%t2=t0+delta_1
                if_fist_compute=1;
                [ K_ti,g_u_k,beta_k ] =fun_K_ti(t_1,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,jiange*1e-3,if_fist_compute,g_start);  g_compute_num=g_compute_num+2;
                t_array_ori=[t_array_ori t_i];
                if isnan(K_ti)
                     t=1; 
                end
                %����t_new�����Ҽ���λ��
                if K_ti<0%  t_new���t_start ����ʵ���ͬ��
                            g_diff_limit_1=K_ti;
                            t_limit_1=t_i;
                            %g_limit_1=g_new;
               else
                            g_diff_limit_2=K_ti;
                            t_limit_2=t_i;   
                            %g_limit_2=g_new;
              end
                
                
                %plot(t_new,(g_diff_new),'o');hold on;
                if iter>=3   
                     t_array=[t_array ;t_i];
                     K_ti_array=[K_ti_array; K_ti];
                     [t_array,g_diff_array]=fun_sort(t_array,K_ti_array);%��С��������
                     [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,K_ti_array);
                end
                if  size(t_array,1)<=2
                        t_array=[t_array ;t_i]; K_ti_array=[K_ti_array ;K_ti] ;
                        if size(t_array,1)==2
                            [t_array,K_ti_array]=fun_sort(t_array,K_ti_array);%��С��������
                            %t_array���ҳ�K_ti_arrayС��0��t����ֵ
                            [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,K_ti_array);
                        end
                end      
                
                
                
 
                %2)����K(ti+��)
                t_x_bias=t_i+jiange;
                if_fist_compute=0;
                [ K_ti_delta ] =fun_K_ti(t_x_bias,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,jiange*1e-3,if_fist_compute,g_start);  g_compute_num=g_compute_num+2;

                diff_K_ti=(K_ti_delta-K_ti)/jiange;
                %3)����ti

                t_i_new=t_i-K_ti/diff_K_ti; 
                if isnan(t_i_new)
                     t=1; 
                end
                if_find_t_success=1;
                
                if iter>=1  &&   (t_i_new-t_limit_1)*(t_i_new-t_limit_2)>0  %||if_always_erfenfa==1)%t_new����t_limit_1~t_limit_2֮��     �ĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸ�--����2��Ϊ1
                          t_i_new=(t_limit_1+t_limit_2)*0.5;%���ַ�
                          if_find_t_success=0;
                end
                method_type=[method_type ;if_find_t_success];
                
                
            
                if abs(t_i_new-t_i)<aa.jingdu|| abs(K_ti)<aa.jingdu
                    t_i=t_i_new;
                    break;
                else
                    t_i=t_i_new;
                end
            end
            t=1;
%             v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
%             U_k_new=beta_k*v_i/nomr(v_i);
% %             v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
%              x_new=tmp_u+tmp_bjc*U_k_new;
%             beta_k=  -(g_u_k-diff_g_u_bj*U_pt_start')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);

end


function [ x,U_k_new,diff_g_u_bj,beta ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type)

            %delta0
            [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
            %diff_g_x_bj
                        if isnan(diff_g_x_bj(1))
                            t=1;
                        end
            diff_g_x=diff_g_x_bj./tmp_bjc;
            gs=diff_g_x.*tmp_bjc;
        %     tidu_bj=tidu.*bjc;
               beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  
               beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
               u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
               alpha=-gs./norm(gs);%----------------���ݶȷ���
             x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;

            diff_g_u_bj=diff_g_x_bj;
end

%        diff_g_x=diff_g_x_bj./std;
%     %����Ƕȣ��ɿ���ֵ���µ������
%     gs=diff_g_x_bj;
%     alpha=-gs/norm(gs);%----------------���ݶȷ���
%     beta=(g_start+diff_g_x*(u-x)')/norm(gs);
%     x=u+beta*std.*alpha;   
%     UU=[UU; (x-u)./std];

function  [t_array,k_array]=fun_sort(t_array,k_array)
               [t_array,index]=sort(t_array,'ascend');%С��������
                k_array_tmp=k_array;
                %g_output_array_tmp=g_output_array;
                for hh=1:size(t_array,1)
                      k_array(hh,:)=k_array_tmp(index(hh),:);
                      %g_output_array(i,:)=g_output_array_tmp(index(i),:);
                end
        
        
end

function [ t_limit_1 ,t_limit_2 ,g_diff_limit_1 ,g_diff_limit_2]=update_limite(t_limit_1x,t_limit_2x,t_array,g_diff_array)
                            t_limit_1=t_limit_1x;t_limit_2=t_limit_2x;
                            for i=1:size(t_array,1)%�����ݶ�g_diff_array�ķ��ţ�Ѱ���ݶ�g_diff_array �����ű仯ʱ�����ٽ�����������Ϊt_limit_1��t_limit_2
                                if(g_diff_array(i)<0)&& t_array(i)>t_limit_1x
                                    t_limit_1=t_array(i);
                                    g_diff_limit_1=g_diff_array(i);
                                end
                                if(g_diff_array(i)>0)&& t_array(i)<t_limit_2x
                                    t_limit_2=t_array(i);
                                    g_diff_limit_2=g_diff_array(i);
                                end
                            end  
end
%�ҳ�ԭ����MPP֮���ֱ�� �� g(u)=0�Ľ��� 
function [U_k_new,g_U_k_new,g_num]=fun_find_g0_mpp(start_u0,v_i,tmp_u,tmp_bjc,type,g_start,delta0,jianju_mpp,if_plot)
global aa;
        g_num=0;
        t_i0=norm(v_i); f_t_i0=g_start;
        if f_t_i0<0%g(u)<0
            t_i=t_i0/2;
            fuhao=1;%��ʾ��g(u)>0������
        else%g(u)>0
            t_i=t_i0*2;
            fuhao=-1;%��ʾ��g(u)<0������
        end
        
        iter_num=0;  vector=v_i/norm(v_i);
        %1)�ҳ�g(u)>0�ĵ�
        %t_i=min(0.5,0.5*jianju_mpp);
        
        while 1
           u_i=start_u0+vector*t_i;
           f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
           
           t_i_new=t_i0-f_t_i0/(f_t_i-f_t_i0)*(t_i-t_i0);%��ֵ��
           f_t_i0=f_t_i;
           t_i0=t_i;
           t_i=t_i_new;
           if(abs(f_t_i)<aa.jingdu *0.01)
               break;
           end
        end
        if if_plot==1
           plot(u_i(1),u_i(2),'o');
        end
        %if_plot=1;
        %2)�ҳ�g(u)=0�ĵ�
        %[ t_i_end,u_i_end,f_t_i_end,g_num_end ] =fun_Steffensen_vector(0,f_t_i,type,-vector,delta0,tmp_u,tmp_bjc,u_i,0);
         %U_k_new= u_i_end;  g_U_k_new=f_t_i_end;  g_num=g_num+g_num_end;
         U_k_new= u_i;  g_U_k_new=f_t_i;  

end
function [U_k_new,g_U_k_new,t_i_end,g_num]=fun_find_best_mpp(start_u0,ab,tmp_u,tmp_bjc,type,if_plot,g_start,delta0,jianju_mpp)
        g_num=0;
        t_i0=0; f_t_i0=g_start;
        iter_num=0;  vector=ab/norm(ab);
        %1)�ҳ�g(u)>0�ĵ�
        t_i=min(0.5,0.5*jianju_mpp);
        while 1
           u_i=start_u0+vector*t_i;
           f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
           if(f_t_i<0)
               t_i=2*t_i;
           else
               break;
           end
        end
        if if_plot==1
           plot(u_i(1),u_i(2),'o');
        end
        %if_plot=1;
        %2)�ҳ�g(u)=0�ĵ�
        [ t_i_end,u_i_end,f_t_i_end,g_num_end ] =fun_Steffensen_vector(0,f_t_i,type,-vector,delta0,tmp_u,tmp_bjc,u_i,0);

        %3)���g(u)=0��������,������ϲ���
        u_hebing=(start_u0+u_i_end)*0.5;
        g_hebing=fun(u_hebing.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
        %4)����ϲ�����ԭ���ֱ��   �� g(u)=0�Ľ���  
        [ t_i,U_k_new,g_U_k_new,g_num2 ] =fun_Steffensen(norm(u_hebing),g_hebing,type,u_hebing,delta0,tmp_u,tmp_bjc,0,0);
        if if_plot==1
           plot(u_i(1),u_i(2),'o');
           plot(u_i_end(1),u_i_end(2),'o');
           plot(U_k_new(1),U_k_new(2),'o');
        end
         g_num=g_num+g_num_end+g_num2;  
           t=1;
           

end
function [ t_i,u_i,f_t_i,g_num ] =fun_Steffensen_vector(t_inial,g_inial,type,vector,delta0,tmp_u,tmp_bjc,start_u0,if_plot)%https://mp.weixin.qq.com/s/JoPuDvjgX8zY6C56Y4elOw
global aa;
   g_num=0; iter_num=0;
   t_i=t_inial;   f_t_i=g_inial;  array_t_i=[t_i];  array_f_t_i=[f_t_i];  t_i_new=100;
   diff_g_v_i=vector/norm(vector); 
   u_i=start_u0+t_i*diff_g_v_i; 
   while 1
       %1)����v_i���ݶȷ���

       %[diff_g_v_i]=diff_chafen(v_i,delta0,tmp_u,tmp_bjc,g_v_i,type);g_num=g_num+size(v_i,1);
       %2)����t_i=0.5ʱ��Ӧ�ĵ�u_i
        %u_i=v_i+t_i*diff_g_v_i/norm(diff_g_v_i);

       if iter_num>=1
           u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);
           f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);   g_num=g_num+1;  
           if(abs(f_t_i)<aa.jingdu*0.01)
               break;
           end
           if if_plot==1
               plot(u_i(1),u_i(2),'*');
           end
           array_f_t_i=[array_f_t_i;f_t_i]; 
           array_t_i=[array_t_i; t_i];
       end

        %f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  
        t_i_tmp=t_i+f_t_i;
        u_i_tmp=start_u0+t_i_tmp*diff_g_v_i/norm(diff_g_v_i);
        f_t_i_tmp=fun(u_i_tmp.*tmp_bjc+tmp_u,type);   g_num=g_num+1;
        
        %plot(u_i_tmp(1),u_i_tmp(2),'+'); 
        t_i_new=t_i-(f_t_i)^2/(f_t_i_tmp-f_t_i);
%         if(abs(f_t_i)<aa.jingdu) ||  (abs(t_i_new-t_i)<aa.jingdu)
%             %u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);  f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
%             break;
%         end

        t_i=t_i_new;  %array_t_i=[array_t_i; t_i];
        
        iter_num=iter_num+1;
   end
end
% function [ t_i,u_i,f_t_i,g_num ] =fun_Steffensen_diff(t_inial,g_inial,type,vector,delta0,tmp_u,tmp_bjc,start_u0,if_plot)%https://mp.weixin.qq.com/s/JoPuDvjgX8zY6C56Y4elOw
% global aa;
%    g_num=0; iter_num=0;
%    t_i=t_inial;   k_t_i=g_inial;  array_t_i=[t_i];  array_k_t_i=[k_t_i];
%    diff_g_v_i=vector/norm(vector); 
%    u_i=start_u0+t_i*diff_g_v_i; 
%    while 1
%        %1)����v_i���ݶȷ���
% 
%        %[diff_g_v_i]=diff_chafen(v_i,delta0,tmp_u,tmp_bjc,g_v_i,type);g_num=g_num+size(v_i,1);
%        %2)����t_i=0.5ʱ��Ӧ�ĵ�u_i
%         %u_i=v_i+t_i*diff_g_v_i/norm(diff_g_v_i);
%        if iter_num>=1
%            u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);
%            f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);   g_num=g_num+2;  
%            if if_plot==1
%                plot(u_i(1),u_i(2),'*');
%            end
%            u_i_delta=start_u0+(t_i+delta0)*diff_g_v_i/norm(diff_g_v_i);
%            f_t_i_delta=fun(u_i_delta.*tmp_bjc+tmp_u,type); 
%            k_t_i=(f_t_i_delta-f_t_i)/delta0;
%            
%            array_k_t_i=[array_k_t_i;k_t_i]; 
%            array_t_i=[array_t_i; t_i];
%        end
% 
%         %f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  
%         t_i_tmp=t_i+k_t_i;
%         u_i_tmp=start_u0+t_i_tmp*diff_g_v_i/norm(diff_g_v_i);
%         f_t_i_tmp=fun(u_i_tmp.*tmp_bjc+tmp_u,type);   g_num=g_num+2;
%         
%         %plot(u_i_tmp(1),u_i_tmp(2),'+'); 
%         
%         u_i_tmp_delta=start_u0+(t_i_tmp+delta0)*diff_g_v_i/norm(diff_g_v_i);
%         f_t_i_tmp_delta=fun(u_i_tmp_delta.*tmp_bjc+tmp_u,type);
%         k_t_i_tmp=(f_t_i_tmp_delta-f_t_i_tmp)/delta0;
%         
% 
%         t_i_new=t_i-(k_t_i)^2/(k_t_i_tmp-k_t_i);
% 
%         if(abs(k_t_i)<aa.jingdu*1e-2) ||  (abs(t_i_new-t_i)<aa.jingdu*1e-2)
%             %u_i=start_u0+t_i*diff_g_v_i/norm(diff_g_v_i);  f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
%             break;
%         end
%         t_i=t_i_new;  array_t_i=[array_t_i; t_i];
%         
%         iter_num=iter_num+1;
%    end
% end

