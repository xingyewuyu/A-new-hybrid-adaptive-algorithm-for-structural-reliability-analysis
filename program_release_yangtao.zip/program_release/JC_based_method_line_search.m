function [ x,beta,pf, UU,xx,gg ,n_vector ] = JC_based_method_line_search( u,std,type )
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  
n_k_array=[];
weishu=num;  tmp_bjc=bjc;  tmp_u=u;
nn=0; t_i=0.5;
 
%---------��ͼ---------------------
hold off;
if aa.type==9
    f0=fun(u,type);%���ֵ
   k1=-5; k2=5;
    length0=0.5;t_min=-1.8;t_max=f0*1;jingdu=1e-2;k1=-5; k2=5;a1=k1;a2=k2;b1=k1;b2=k2;%k1=-1; k2=5;a1=k1;a2=k2;b1=k1;b2=k2;
    [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);
    x1_ori=x1*bjc(1)+u(1);x2_ori=x2*bjc(2)+u(2);
    Z=fun([x1_ori,x2_ori],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
    t_min=-f0;t_max=f0;
    tt=t_min:(t_max-t_min)/3:t_max;%1e-10
    for i=1:size(tt,2)
        t_value=tt(i);
   [C,h] = contour(x1,x2,Z,t_value,'r');axis([a1 a2 b1 b2]); grid on;hold on;
    end
    [C,h] = contour(x1,x2,Z,1e-8,'g');hold on;

    [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*bjc(1)+u(1);xx2_ori=xx2*bjc(2)+u(2);
    Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
    quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;
end





while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==4 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==35
                    num_tmp=2;    
                 end   
                X(1:num_tmp)=u(1:num_tmp)+bjc(1:num_tmp).*x_start_bj(1:num_tmp);
%                 u=X.*(6.517-log(X));
%                 bjc=aa.bjc./aa.u.*X;
                %aa.u=250;aa.bjc=25; X=210;
                logn_para_u=log(u(1:num_tmp).^2./(bjc(1:num_tmp).^2+u(1:num_tmp).^2).^0.5);
                logn_para_sigma=(log(  bjc(1:num_tmp).^2./u(1:num_tmp).^2+1)  ).^0.5;
                F_x=cdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                inv_norm_F_x=icdf('normal',F_x,0,1);
                tmp_bjc(1:num_tmp)=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                tmp_u(1:num_tmp)=X(1:num_tmp)-inv_norm_F_x.*tmp_bjc(1:num_tmp);
                x_start_bj(1:num_tmp)= ( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
%                    mu=100;sigma=12;
%                    aEv=sqrt(6)*sigma/pi;  uEv=-psi(1)*aEv-mu;
%                    FQ=1-evcdf(-150,uEv,aEv);%
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==430  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   aEv=sqrt(6)*bjc((5:7))/pi; uEv=-psi(1)*aEv-u((5:7));
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X((5:7)),uEv,aEv);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc((5:7))=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u((5:7))=X((5:7))-inv_norm_F_x.*tmp_bjc((5:7));  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   %x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            end         
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        %norm(UU(end-1,:)-x_start_bj)
    end
    %%delta0
    
    %if nn<=3%JC��
    %1)JC������MPP��
        [ x,U_k_new,diff_g_u_bj,beta  ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
         plot(x(1),x(2),'o');  g_start_x=fun(x,type);
         diff=[ diff;  diff_g_u_bj];   
    %2)���ж�
    if nn>=2
    u3=U_k_new;u2=UU(end,:);u1=UU(end-1,:);
    n3=u3/norm(u3);  n2=u3/norm(u2);  n1=u3/norm(u1);
    hui_k=(n3-n2)*(n2-n1)';
    
        if(hui_k<-aa.jingdu*0.01)    %˵���񵴣����¼���MPP 
        %line search
            %[ x_tmp_k,U_tmp_k,diff_g_u_bj ] =JC_compute_mpp(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
            U_pt_start=x_start_bj;  U_pt_end=U_k_new;
            if nn==4
               t=1; 
            end
            [ beta_k,t_i_new,g_u_k ] =fun_newton(U_pt_start,U_pt_end,tmp_u,tmp_bjc,diff_g_u_bj,type,0.5,g_start);
            
            
            v_i=U_pt_start+t_i_new*(U_pt_end-U_pt_start);
            U_k_new=beta_k*v_i/norm(v_i);
            x_new=tmp_u+tmp_bjc.*U_k_new;
            plot(U_k_new(1),U_k_new(2),'*'); 
%             U_tmp_k=U_k_new;
%             U_k=x_start_bj;
%             v_i=U_k+t_i*(U_tmp_k-U_k);
%             g_u_k=g_start;
%             beta_k=  -(g_u_k-diff_g_u_bj*U_k')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);
%             U_k_new=-beta_k*v_i/norm(v_i);
            array_beta=[array_beta;beta_k];
        else
            array_beta=[array_beta;beta];
        end
    else
        array_beta=[array_beta;beta];  
    end

    n_k_array=[n_k_array; U_k_new/norm(U_k_new) ];
    
    
    if size(diff,1)>=2
        error_diff=[error_diff; diff(end,:)-diff(end-1,:)];
        error=[error;  norm(error_diff(end,:))];
    end
    
    %t=1 
    %nn
    %kkt=[kkt ;U_k_new/norm(U_k_new)+diff_g_x_bj/norm(diff_g_x_bj)];
       %theta(nn,:)=acos(U_k_new*diff_g_x_bj'/norm(U_k_new)/norm(diff_g_x_bj))/pi*180;
   if nn>=1
%       theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
%       theta(nn,:)=acos(theta(nn,:))/pi*180;
   end
            if nn==2
               t=1; 
            end
    if nn>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
            
        end
    end
    x_start_bj=U_k_new;
    x=x_start_bj.*tmp_bjc+tmp_u;
    xx=[xx;X];
    nn=nn+1;
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
    %t1 = toc  % ���㾭����ʱ��
    aa.nn=nn;
end
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)];  UU=[UU; U_k_new];
aa.gg=gg; aa.xx=xx;aa.UU=UU;% aa.kkt=kkt;  aa.theta=theta; 
% aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
% aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
 n_vector=[];
%  for i=2:size(UU,1)
%     n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
%  end
%  UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
t=1;
end

function [ u_x,g_x,g_num ] =fun_gexianfa(u1,u2,g1,g2,v_i,type)
global aa;
            if aa.nn==3
               t=1; 
            end
     g_num=0;
     while 1
        u_x=u2-g2*(u2-u1)/(g2-g1);
        u_point=u_x*v_i/norm(v_i);
        g_x=fun(u_point.*aa.bjc+aa.u,type);  g_num=g_num+1;
        if(abs(g_x)<aa.jingdu*1e-3)
            break;
        else
            if(abs(g2)<abs(g1))
                u1=u_x;
                g1=g_x;
            else
                u2=u_x;
                g2=g_x;
            end
        end
     end
end
function [ beta_k,g_mpp ] =fun_beta_ti(t_i,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,if_plot,g_pt_start)
global aa;
            v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
            g_v_i=fun(v_i.*aa.bjc+aa.u,type);
            
            
            g_start=g_pt_start;%fun(X_pt_start,type);   %g_end=fun(X_pt_end,type);
            g_u_k=g_start;
            U_k=U_pt_start;

            
            beta_inital=norm(v_i)*0.9;
            g_inital=fun(beta_inital*v_i/norm(v_i).*aa.bjc+aa.u,type);
            
           [ beta_k,g_mpp ,g_num] =fun_gexianfa(beta_inital,norm(v_i),g_inital,g_v_i,v_i,type);
            %beta_k=  -(g_u_k-diff_g_u_bj*U_k')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);

            uu=beta_k*v_i/norm(v_i);
            x_ori_uu=uu.*aa.bjc+aa.u;
            %g_start=fun(x_ori_uu,type);
            if if_plot==1
               %plot(x_ori_uu(1),x_ori_uu(2),'*'); 
            end
            
end

function [ K_ti,g_mpp,beta_k ] =fun_K_ti(t0,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,delta,if_fist_compute,g_pt_start)
            t_x=t0;
            [ beta_k,g_mpp ] =fun_beta_ti(t_x,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,if_fist_compute,g_pt_start);

            [ beta_delta ] =fun_beta_ti(t_x+delta,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,0,g_pt_start);
            
            diff_beta_ti=(beta_delta-beta_k)/delta;
            K_ti=diff_beta_ti;
end

%function [ x,U_k_new,diff_g_u_bj,beta ] =fun_newton(X,x_start_bj,tmp_u,tmp_bjc,diff_g_u_bj,type,t0)
function [ beta_k,t_i_new,g_u_k ,g_compute_num] =fun_newton(U_pt_start,U_pt_end,tmp_u,tmp_bjc,diff_g_u_bj,type,t0,g_start)
global aa;
            distance=norm(U_pt_start-U_pt_end);
            X_pt_start=U_pt_start.*tmp_bjc+tmp_u;
            X_pt_end=U_pt_end.*tmp_bjc+tmp_u;  g_compute_num=0;
            %delta_1=min(distance*0.01,1e-6);
            
            
            t_i=t0;
            
            iter=0;g_new=1e10;t_new=0.5;  t_limit_1=0; t_limit_2=1; t_array=[];  method_type=[]; K_ti_array=[];
            t_array_ori=[];
            jiange=min(abs(t_limit_2-t_limit_1)*0.01,1e-3);   jiange=abs(t_limit_2-t_limit_1)*0.01;    
            while(1)
                iter=iter+1;
                %1)����K(ti)
                t_1=t_i;%t2=t0+delta_1
                if_fist_compute=1;
                [ K_ti,g_u_k,beta_k ] =fun_K_ti(t_1,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,jiange*1e-3,if_fist_compute,g_start);  g_compute_num=g_compute_num+2;
                t_array_ori=[t_array_ori t_i];
                if isnan(K_ti)
                     t=1; 
                end
                %����t_new�����Ҽ���λ��
                if K_ti<0%  t_new���t_start ����ʵ���ͬ��
                            g_diff_limit_1=K_ti;
                            t_limit_1=t_i;
                            %g_limit_1=g_new;
               else
                            g_diff_limit_2=K_ti;
                            t_limit_2=t_i;   
                            %g_limit_2=g_new;
              end
                
                
                %plot(t_new,(g_diff_new),'o');hold on;
                if iter>=3   
                     t_array=[t_array ;t_i];
                     K_ti_array=[K_ti_array; K_ti];
                     [t_array,g_diff_array]=fun_sort(t_array,K_ti_array);%��С��������
                     [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,K_ti_array);
                end
                if  size(t_array,1)<=2
                        t_array=[t_array ;t_i]; K_ti_array=[K_ti_array ;K_ti] ;
                        if size(t_array,1)==2
                            [t_array,K_ti_array]=fun_sort(t_array,K_ti_array);%��С��������
                            %t_array���ҳ�K_ti_arrayС��0��t����ֵ
                            [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,K_ti_array);
                        end
                end      
                
                
                
 
                %2)����K(ti+��)
                t_x_bias=t_i+jiange;
                if_fist_compute=0;
                [ K_ti_delta ] =fun_K_ti(t_x_bias,U_pt_start,U_pt_end,X_pt_start,type,diff_g_u_bj,jiange*1e-3,if_fist_compute,g_start);  g_compute_num=g_compute_num+2;

                diff_K_ti=(K_ti_delta-K_ti)/jiange;
                %3)����ti

                t_i_new=t_i-K_ti/diff_K_ti; 
                if isnan(t_i_new)
                     t=1; 
                end
                if_find_t_success=1;
                
                if iter>=1  &&   (t_i_new-t_limit_1)*(t_i_new-t_limit_2)>0  %||if_always_erfenfa==1)%t_new����t_limit_1~t_limit_2֮��     �ĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸ�--����2��Ϊ1
                          t_i_new=(t_limit_1+t_limit_2)*0.5;%���ַ�
                          if_find_t_success=0;
                end
                method_type=[method_type ;if_find_t_success];
                
                
            
                if abs(t_i_new-t_i)<aa.jingdu|| abs(K_ti)<aa.jingdu
                    t_i=t_i_new;
                    break;
                else
                    t_i=t_i_new;
                end
            end
            t=1;
%             v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
%             U_k_new=beta_k*v_i/nomr(v_i);
% %             v_i=U_pt_start+t_i*(U_pt_end-U_pt_start);
%              x_new=tmp_u+tmp_bjc*U_k_new;
%             beta_k=  -(g_u_k-diff_g_u_bj*U_pt_start')*v_i*diff_g_u_bj'/norm(diff_g_u_bj)^2/norm(v_i);

end


function [ x,U_k_new,diff_g_u_bj,beta ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type)

            %delta0
            [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
            %diff_g_x_bj
                        if isnan(diff_g_x_bj(1))
                            t=1;
                        end
            diff_g_x=diff_g_x_bj./tmp_bjc;
            gs=diff_g_x.*tmp_bjc;
        %     tidu_bj=tidu.*bjc;
               beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  
               beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
               u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
               alpha=-gs./norm(gs);%----------------���ݶȷ���
             x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;

            diff_g_u_bj=diff_g_x_bj;
end

%        diff_g_x=diff_g_x_bj./std;
%     %����Ƕȣ��ɿ���ֵ���µ������
%     gs=diff_g_x_bj;
%     alpha=-gs/norm(gs);%----------------���ݶȷ���
%     beta=(g_start+diff_g_x*(u-x)')/norm(gs);
%     x=u+beta*std.*alpha;   
%     UU=[UU; (x-u)./std];

function  [t_array,k_array]=fun_sort(t_array,k_array)
               [t_array,index]=sort(t_array,'ascend');%С��������
                k_array_tmp=k_array;
                %g_output_array_tmp=g_output_array;
                for hh=1:size(t_array,1)
                      k_array(hh,:)=k_array_tmp(index(hh),:);
                      %g_output_array(i,:)=g_output_array_tmp(index(i),:);
                end
        
        
end

function [ t_limit_1 ,t_limit_2 ,g_diff_limit_1 ,g_diff_limit_2]=update_limite(t_limit_1x,t_limit_2x,t_array,g_diff_array)
                            t_limit_1=t_limit_1x;t_limit_2=t_limit_2x;
                            for i=1:size(t_array,1)%�����ݶ�g_diff_array�ķ��ţ�Ѱ���ݶ�g_diff_array �����ű仯ʱ�����ٽ�����������Ϊt_limit_1��t_limit_2
                                if(g_diff_array(i)<0)&& t_array(i)>t_limit_1x
                                    t_limit_1=t_array(i);
                                    g_diff_limit_1=g_diff_array(i);
                                end
                                if(g_diff_array(i)>0)&& t_array(i)<t_limit_2x
                                    t_limit_2=t_array(i);
                                    g_diff_limit_2=g_diff_array(i);
                                end
                            end  
end
