
clear;
clc;
global aa;
global path;  
hold off;
load data_method_type_80_water_Transducer.mat

% [ x4,beta4,pf4, UU4,xx4,gg4 ,n_vector4,g_num4,nn4,array_beta4,v_i_array,U_k_new_array,u_k_pre_1,u_k_pre_2,nn_array  ] = JC_based_method_line_search_min_g_simplify( u,bjc,type, if_plot0 );num_g4=g_num4;aa.inner_num_g=0;hold off;
%     disp('test JC_based_method_line_search_min_g_simplify.............................................'); 
% hold off;  %U_k_new_array_all=[0 0; U_k_new_array];


    ymax=max([max(array_beta_AFRA)           max(array_beta_DSTM)       max(array_beta_rHLRF)     max(array_beta_BFGS)      max(array_beta__line_search)          ]);
    x_max=max([ size(array_beta_AFRA,1)  size(array_beta_DSTM,1)    size(array_beta_rHLRF,1)  size(array_beta_BFGS,1)   size(array_beta__line_search,1)]);
    x_max=(ceil(x_max/10))*10;
    
    plot(array_beta_DSTM,'c-+');hold on;%DSTM
    plot(array_beta_rHLRF,'g--^');%rHLRF
    plot(array_beta_AFRA,'r-.p');%AFRA  'r-.p'
    plot(array_beta_BFGS,'b:*');%HLRF_BFGS
    plot(array_beta__line_search,'m--o');%HAMA
    
%     plot(array_beta_DSTM,'c-+');hold on;%DSTM
%     plot(array_beta_rHLRF,'g--o');%rHLRF
%     plot(array_beta_AFRA,'r-.p');%AFRA
%     plot(array_beta_BFGS,'b:*');%HLRF_BFGS
%     plot(array_beta__line_search,'m--');%HAMA
    axis([ 1 x_max 0 ymax*1.2]); set(gcf,'color','white');
    h1_legend=legend('DSTM','rHLRF','AFRA','HLRF\_BFGS','HAMA');legend('boxoff'); box off;%ylim([0 8]);
    set(h1_legend,'Position',[0.7,0.55,0.1,0.1]);
if ~isempty(U_k_new_array__line_search)
    for i=1:size(U_k_new_array__line_search,1)
        tx(i)=norm(U_k_new_array__line_search(i,:)-v_i_array_line_search(i,:));
        ty(i)=norm(u_k_pre_1_line_search(i,:)-u_k_pre_2_line_search(i,:));
        bizhi(i)=tx(i)./ty(i);

    end
    tx=tx';ty=ty';bizhi=bizhi';
    for i=2:size(UU_line_search,1)-1
        t1(i)=norm(UU_line_search(i-1,:)-UU_line_search(i,:));
        t2(i)=norm(UU_line_search(i+1,:)-UU_line_search(i,:));
        bizhi2(i)=t2(i)./t1(i);

    end
    t1=t1';t2=t2';bizhi2=bizhi2';
    plot(bizhi,'bo-');
    hold off;
end

hold off;

t=1;

