function [ is_success] = method_Xian_ASSA_tidu_Newton(if_exlicit_diff_or_chafen, g_sysm, g_diff_sysm, beta, dim )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%�㷨˵����ͨ����u1��u2 ���ɵ����ϣ�����ֱ�߷��̣�Ȼ�� ������ֱ���������tֵ��Ӧ�� �ݶȣ�dg/dt ��
%Ȼ����spline��� t��dg/dt�Ĺ�ϵ������ֵ���ҵ� ����dg/dt=0��tֵ��
%   if_exlicit_diff_or_chafen=1;%���ý������ݶȱ���ʽ(=1)   ����  ��ּ����������ʽ(=0)
%global U_record g_record x_record
global aa;
num_u=aa.para_num_u;
%         aa.U_record=[];
%         aa.g_record=[];
%         aa.x_record=[];


% if 1 && (aa.index==1||aa.index==5||aa.index==6)
%     %---------��ͼ---------------------
%      fun_example=['example_',num2str(aa.index)];
%         if_need_giff=0;%����Ҫ�����ݶ�
%         if_exlicit_diff_or_chafen=0;%��㸳ֵ���ò���
%     colors = {'b','r','g','k','y'}; %
%     if 1
%         value=beta;type=200;%   example_5---- 200   example_1----201
%         a1=-value;a2=value;b1=-value;b2=value;  jingdu=1e-2;
%         %t_u=fun([aa.u(1),aa.u(2)],type)
%         %;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
%         t_u=fun([aa.u(1),aa.u(2)],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
%         %t_u=double(subs(g_sysm,U,aa.u));
%         
%         if aa.index==1
%              t_min=40;t_max=80; num=3;   
%         elseif aa.index==5
%             t_min=2;t_max=28; num=4;   
%         elseif aa.index==6
%             t_min=2;t_max=28; num=4;   
%         end
%        k1=-5; k2=5;
%         viscircles([0 0],beta,'EdgeColor',colors{3});hold on;%Բ������Ϊ(20,30)���뾶Ϊ10,������ɫΪ��ɫ
%         [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);
%         for i=1:size(x1,1)
%             for j=1:size(x1,2)
%                 %xx=[x1(i,j) x2(i,j)]; Z(i,j)=double(subs(g_sysm,U,xx));
%                 x_1=x1(i,j);  x_2=x2(i,j);
%                 x_1=aa.u(1)+x_1*aa.bjc(1); x_2=aa.u(2)+x_2*aa.bjc(2);
%                 if  aa.index==6
%                    Z(i,j)=0.2*log(      exp(  5*(1+x_1-x_2)  )+ exp(  5*(5-5*x_1-x_2)  )       );
%                 elseif aa.index==1
%                    Z(i,j)= x_1^4+2*x_2^4-20;
%                 elseif aa.index==5
%                    Z(i,j)= 0.3*x_1*x_1*x_2-x_2+0.8*x_1+1; 
%                 end
%             end
%         end
%         Z_min=min(min(Z)); Z_max=max(max(Z));
% %         x1_ori=x1*aa.bjc(1)+aa.u(1);x2_ori=x2*aa.bjc(2)+aa.u(2);
% %         Z=fun([x1_ori,x2_ori],type)
% %         ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
%         %t_min=-f0;t_max=f0;
%         tt=Z_min:(Z_max-Z_min)/Z_max:t_max;%1e-10
%         for i=1:size(tt,2)
%             t_value=tt(i);
%            % [C,h] = contour(x1,x2,Z,t_value,'r');
%            ii= mod(i,5);
%             %[C,h] = contour(x1,x2,Z,t_value,colors{ii});
%             [C,h] = contour(x1,x2,Z,t_value,'r');
%             axis([a1 a2 b1 b2]); grid on;hold on;
%         end
%         [C,h] = contour(x1,x2,Z,1e-8,'b');hold on;
% 
%         [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*aa.bjc(1)+aa.u(1);xx2_ori=xx2*aa.bjc(2)+aa.u(2);
%         for i=1:size(xx1,1)
%             for j=1:size(xx2,2)
%                 %xx=[x1(i,j) x2(i,j)]; Z(i,j)=double(subs(g_sysm,U,xx));
%                 x_1=xx1(i,j);  x_2=xx2(i,j);
%                 x_1=aa.u(1)+x_1*aa.bjc(1); x_2=aa.u(2)+x_2*aa.bjc(2);
%                 if  aa.index==6
%                    Z2(i,j)=0.2*log(      exp(  5*(1+x_1-x_2)  )+ exp(  5*(5-5*x_1-x_2)  )       );
%                 elseif aa.index==1
%                    Z2(i,j)= x_1^4+2*x_2^4-20;
%                 elseif aa.index==5
%                    Z2(i,j)= 0.3*x_1*x_1*x_2-x_2+0.8*x_1+1; 
%                 end
%             end
%         end
%         [Dx1,Dx2]=gradient(Z2);
%         %Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
%         quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;%��ʾ�ݶ�����
%     end
% end  
t=1;



% if aa.index==1
%     %---------��ͼ---------------------
%     colors = {'b','r','g','k','y'}; %
%     if 1
%         value=6;type=201;
%         a1=-value;a2=value;b1=-value;b2=value;  jingdu=1e-2;
%         t_u=fun([aa.u(1),aa.u(2)],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
%         t_min=40;t_max=80;
%         num=3;   
% 
% 
%        k1=-5; k2=5;
%         viscircles([0 0],beta,'EdgeColor',colors{3});hold on;%Բ������Ϊ(20,30)���뾶Ϊ10,������ɫΪ��ɫ
%         [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);
%         x1_ori=x1*aa.bjc(1)+aa.u(1);x2_ori=x2*aa.bjc(2)+aa.u(2);
%         Z=fun([x1_ori,x2_ori],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));
%         %t_min=-f0;t_max=f0;
%         tt=t_min:(t_max-t_min)/num:t_max;%1e-10
%         for i=1:size(tt,2)
%             t_value=tt(i);
%            % [C,h] = contour(x1,x2,Z,t_value,'r');
%            ii= mod(i,5);
%             %[C,h] = contour(x1,x2,Z,t_value,colors{ii});
%             [C,h] = contour(x1,x2,Z,t_value,'r');
%             axis([a1 a2 b1 b2]); grid on;hold on;
%         end
%         [C,h] = contour(x1,x2,Z,1e-8,'b');hold on;
% 
%         [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*aa.bjc(1)+aa.u(1);xx2_ori=xx2*aa.bjc(2)+aa.u(2);
%         Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
%         quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;
%     end
% end


%aa.iter_num
if aa.iter_num==12&&aa.con_fun_index==1
     t=1;
end
U=[];
for i=1:dim
   syms (['x',num2str(i)]);       %syms x1 x2
   syms (['U',num2str(i)]);       %syms U1 U2    UΪ��׼��̬�ռ���������
   U=[U  eval(['U' num2str(i)])     ]; %U=[U1 U2 ];   
end

U0=aa.U0;%��׼�ռ�ĳ�ʼֵ
if aa.if_RBDO_computaiton==1 &&aa.iter_num>=2
    eval([ 'U0=aa.MPP_con_' num2str(aa.con_fun_index) '(end,:);' ]);% U0= aa.MPP_con_i(end,:);
    eval([ 'X=aa.MPP_con_' num2str(aa.con_fun_index) '_X(end,:);' ]);% U0= aa.MPP_con_i_X(end,:);
    %
    if (strcmp(aa.type_variable,'logn'))
        logn_para_u=log(X.^2./(aa.bjc.^2+X.^2).^0.5);
        logn_para_sigma=(log(  aa.bjc.^2./X.^2+1)  ).^0.5;
        F_x=cdf('logn',X,logn_para_u,logn_para_sigma);
        inv_norm_F_x=icdf('normal',F_x,0,1);
        aa.bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X,logn_para_u,logn_para_sigma);
        aa.u=X-inv_norm_F_x.*aa.bjc;
        U0= ( X-aa.u )./aa.bjc;
    elseif (strcmp(aa.type_variable,'ev'))
        aa.ev_a=pi/6^0.5./aa.bjc;
        aa.ev_u=X+psi(1)./aa.ev_a;
        F_x=exp(-exp( -aa.ev_a.*(X-aa.ev_u)   ));
        inv_norm_F_x=icdf('normal',F_x,0,1);
        aa.bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('ev',X,aa.ev_u,aa.ev_a);
        aa.u=X-inv_norm_F_x.*aa.bjc;
        U0= ( X-aa.u )./aa.bjc;      
    end

    if aa.index_for_RBDO~=3
        for i=1:aa.para_num 
            aa.u(i)=aa.d(i);
        end
    end
end
ii=0;is_success=0;  g_compute_num=0;  branch_g_compute_num=[]; branch_i_num=0;
%ramba=0.15;%0.15~0.05,�����ȶ�����ʵ��1ȡ0.1��ã�
flag=0; g_output=1e10;  is_ao=0;%0---��ʾ�����ڸ�λ�ò��ǰ�����
if aa.run_con_fun_never==0
    ii_start=3;  
else
    ii_start=2;  
end
ii_start=3;
if aa.con_fun_index==10 &&  aa.iter_num==77
    t=1;
end
while(1)
          ii=ii+1;
          if ii==1
                  U_tmp=U0;
                  %U_amv=U_tmp;
                  %n=U_tmp/norm(U_tmp);
          else
                  %U_amv=U_tmp;
          end
          U_tmp_last=U_tmp;
         
          %aa.g_record=[aa.g_record; double(subs(g_sysm,U,U_tmp))];
          g_output_last=g_output;
          
%           if ii>=ii_start
%               is_ao=is_fun_ao();
%           end
          %if ii<=ii_start-1 ||is_ao==0%�����͹����
          %if ii<=ii_start-1 ||is_ao==0%�����͹����    
        
                        if if_exlicit_diff_or_chafen==1%���ý������ݶȱ���ʽ(=1)
                              g_diff_amv=double(subs(g_diff_sysm,U,U_tmp))';
                              g_output=double(subs(g_sysm,U,U_tmp));
                        else %���ò�ּ����������ʽ(=0)
                             [ g_diff_amv,g_output ] =diff_chafen( aa.index,U_tmp ,1);%1 ��ʾҪ�����ݶ�  0 ��ʾ��Ҫ�����ݶ�
                              g_compute_num=g_compute_num+num_u+1;
                              if norm(g_diff_amv)==0
                                   t=1; 
                              end
                        end
                        %hold on;plot(U_tmp(1),U_tmp(2),'o');
                       aa.U_record=[aa.U_record ;U_tmp];
                       aa.g_record=[aa.g_record; g_output];
                       x=U_tmp.*aa.bjc+aa.u;
                       aa.x_record=[aa.x_record; x];


                       if aa.index_for_RBDO==4&& aa.con_fun_index==1  %aa.iter_num==9 aa.con_fun_index==8
                                             t=1;
                       end
                       shoulian=abs( U_tmp/norm(U_tmp)*(-g_diff_amv)'/norm(g_diff_amv)-1);%  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                       if  abs( U_tmp/norm(U_tmp)*(-g_diff_amv)'/norm(g_diff_amv)-1)<aa.jingdu  %&&norm(aa.U_record(end-1,:)-U_tmp)<aa.jingdu    %zzzzzzzzzzzzzzzz����Ҫ
                            is_success=1;
                            break;
                       end  
                       U_amv=-g_diff_amv/norm(g_diff_amv)*beta;
          %end
          %������͹�ж�
          if ii>=ii_start
              is_ao=is_fun_ao(U_amv,aa.U_record(end,:),aa.U_record(end-1,:));
          end          
         % [ g_diff,g_output ] = diff_chafen( index,u_value, if_compute_tidu )
         %����ǰ�����
        if    ii>=ii_start&&is_ao==1     %ii>=3  &&  g_output> g_output_last||  (ii>=4||is_ao>0)
         %if    ii>=2&&  g_output> g_output_last     %ii>=3  &&  g_output> g_output_last  
         %if ii>=3  &&  g_output> g_output_last||  (ii>=4||is_ao>0)
                branch_i_num=branch_i_num+1;%������branch�Ĵ���
                is_ao=0;%0---��ʱ�����ʾ�����ڸ�λ�ò��ǰ�����
                %U_start0=aa.U_record(end-1,:);
                %g_start=aa.g_record(end-1,:);
                
                U_start0=U_amv;
                %g_start=aa.g_record(end,:);
                
                
                U_end0=U_tmp;  %aa.U_record(end,:)
                %g_end=g_output;%aa.g_record(end-1,:)
                
                U_start=U_start0;
                U_end=U_end0;
                if norm(U_start-U_end)==0
                     t=1;
                end
%                 t_i=0:1/100:1;
%                 for i=1:size(t_i,2)
%                      [g_diff_i(i,:),U_tmp,g_output_ii(i,:)]=tidu(U_start,U_end,t_i(i),beta,1e-5); 
%                 end
%                 figure(2);
%                 plot(t_i,(g_diff_i));hold on;
%                 t=0:0.01:1;y=zeros(1,size(t,2));
%                 plot(t,y,'r');

%                 t_start=0;t_end=1;t_mid=0.5;   t_limit_1=t_start;t_limit_2=t_end;
%                 [g_diff_start,u, g_start]=tidu(U_start,U_end,t_start,beta, abs(t_limit_2-t_limit_1)*0.01  ); g_compute_num=g_compute_num+2;
%                 [g_diff_end,u, g_end]=tidu(U_start,U_end,t_end,beta, abs(t_limit_2-t_limit_1)*0.01 );        g_compute_num=g_compute_num+2;
%                 g_diff_array=[(g_diff_start) ;(g_diff_end)]; 
%                 %g_output_array=[g_start g_end ];
%                 t_array=[0 ;1];
%                 t_new=0.5;
%                 if_always_spline=0;
%                 g_limit_1=g_start;g_limit_2=g_end;  
%                 vector=g_limit_2-g_limit_1;         g_diff_limit_1=g_diff_start;  g_diff_limit_2=g_diff_end;  
                
                iter=0;g_new=1e10;t_new=0.5;  t_limit_1=0; t_limit_2=1; t_array=[];g_diff_array=[]; method_type=[];
                t_array_ori=[]; g_compute_num_each_record=g_compute_num;
                if_always_erfenfa=0 ; %if_find_t_success=0;
            while 1
                iter=iter+1;
                g_new_last=g_new;
                %jiange=min(abs(t_limit_2-t_limit_1)*0.1,1e-3);
                %jiange=abs(t_limit_2-t_limit_1)*0.001;
                
                jiange=min(abs(t_limit_2-t_limit_1)*0.0001,aa.jingdu);%����ʵ���õ��Ǹ��о���
                jiange=min(abs(t_limit_2-t_limit_1)*0.01,aa.jingdu);%����Ԫʵ��ʵ���õ��Ǹ��о���---------------------------------------------------------------------------------------------------
                t_limit_1=t_limit_1;
                t_limit_2=t_limit_2;
                jiange;
                %jiange=abs(t_limit_2-t_limit_1)*0.001; 
                %jiange=(abs(t_limit_2-t_limit_1)*0.00001);

                [g_diff_new,U_tmp,g_new]=tidu(U_start,U_end,t_new,beta,jiange);  g_compute_num=g_compute_num+2;
                 %plot(t_new,g_diff_new,'*');
                 t_array_ori=[t_array_ori t_new];
                if isnan(g_diff_new)
                     t=1; 
                end
                %����t_new�����Ҽ���λ��
                if g_diff_new<0%  t_new���t_start ����ʵ���ͬ��
                            g_diff_limit_1=g_diff_new;
                            t_limit_1=t_new;
                            %g_limit_1=g_new;
               else
                            g_diff_limit_2=g_diff_new;
                            t_limit_2=t_new;   
                            %g_limit_2=g_new;
              end
                
                
                %plot(t_new,(g_diff_new),'o');hold on;
                if iter>=3   
                     t_array=[t_array ;t_new];
                     g_diff_array=[g_diff_array; g_diff_new];
                     [t_array,g_diff_array]=fun_sort(t_array,g_diff_array);%��С��������
                     [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,g_diff_array);
                end
                if  size(t_array,1)<=2
                        t_array=[t_array ;t_new]; g_diff_array=[g_diff_array ;g_diff_new] ;
                        if size(t_array,1)==2
                            [t_array,g_diff_array]=fun_sort(t_array,g_diff_array);%��С��������
                            %t_array���ҳ�g_diff_arrayС��0��t����ֵ
                            [ t_limit_1, t_limit_2 ]=update_limite(t_limit_1,t_limit_2,t_array,g_diff_array);
                        end
                end                
                
                t_new_bias=t_new+jiange;
                [g_diff_new_bias,U_tmp,g_new_bias]=tidu(U_start,U_end,t_new_bias,beta,jiange);  g_compute_num=g_compute_num+2;
                g_diff_2=(g_diff_new_bias-g_diff_new)/jiange;
                t_newx=t_new-g_diff_new/g_diff_2;              
                if isnan(t_newx)
                     t=1; 
                end
                if_find_t_success=1;
                
                if iter>=1  &&   (t_newx-t_limit_1)*(t_newx-t_limit_2)>0  %||if_always_erfenfa==1)%t_new����t_limit_1~t_limit_2֮��     �ĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸĸ�--����2��Ϊ1
                          t_newx=(t_limit_1+t_limit_2)*0.5;%���ַ�
                          if_find_t_success=0;
                          if_always_erfenfa=1;
                end
                method_type=[method_type ;if_find_t_success];
                %t_array��Ԫ��С��2ʱ���������
%                 if if_find_t_success==1%size(t_array,1)>=2 && if_always_spline==0  && 
%                     if g_diff_new<0%  t_new���t_start ����ʵ���ͬ��
%                             g_diff_limit_1=g_diff_new;
%                             t_limit_1=t_new;
%                             %g_limit_1=g_new;
%                     else
%                             g_diff_limit_2=g_diff_new;
%                             t_limit_2=t_new;   
%                             %g_limit_2=g_new;
%                     end

                    
%                     %��ֵ������t_new
%                     t_array=[t_array;t_new];
%                     g_diff_array=[g_diff_array;g_diff_new];
%                     [t_array,g_diff_array]=fun_sort(t_array,g_diff_array);%��С��������
                    
%                     %����ֱ��������limit����ƽ��ֵ�Ĳ�
%                     giff_mean=g_limit_2-g_limit_1;
%                     delta_giff_limit_1=g_limit_1-giff_mean;
%                     delta_giff_limit_2=g_limit_2-giff_mean;
%                     %ͨ��ֱ��������limit����ƽ��ֵ�Ĳ����t_new_local
%                     t_new_local=abs(delta_giff_limit_1)/(  abs(delta_giff_limit_1)  + abs(delta_giff_limit_2)   );
%                     
%                     U_limit_1=U_start+t_limit_1*vector; U_limit_2=U_start+t_limit_2*vector;
%                     U_local= U_limit_1+ t_new_local*( U_limit_2-U_limit_1);
%                     t_new_global_array=(U_local-U_start)./vector;
%                     t_new=t_new_global_array(1);
%                     %ti_new=interp1(g_diff_array,t_array,0,'cubic');%spline  cubic pchip 
%                     %t_new1=interp1(g_diff_array,t_array,0,'pchip');%spline
%                     if(t_new-t_limit_1)*(t_new-t_limit_2)>0  %t_new����t_limit_1~t_limit_2֮��
%                           t_new=(t_limit_1+t_limit_2)*0.5;%���ַ�
%                     end
                    
                   % t=1;
                    
%                     g_diff_mean= g_end-g_start;
%                     g_diff_delta_1=(g_diff_1-g_diff_mean);
%                     g_diff_delta_2=(g_diff_2-g_diff_mean);
%                     t_new=abs(g_diff_delta_1)/(abs(g_diff_delta_1)+abs(g_diff_delta_2));
%                     [g_diff_new,U_tmp,g_output]=tidu(U_start,U_end,t_new,beta);
%                     
%                     if abs(t_new-0.5)/0.5<0.1
%                         t_new=interp1(g_diff_array,t_array,0,'spline');
%                         if_always_spline=1;
%                     end
%                     [g_diff_new,U_tmp,g_output]=tidu(U_start,U_end,t_new,beta);
%                     if g_diff_new*g_diff_1>0% MPTP�㿿��U_start
%                          U_start=U_tmp;
%                          g_start=g_output;
%                          g_diff_1=g_diff_new;
%                     else
%                          U_end=U_tmp;
%                          g_end=g_output;
%                          g_diff_2=g_diff_new;
%                     end
                    
%                 else
%                     t_new=interp1(g_diff_array,t_array,0,'pchip');%spline
                    
%                end
               % [g_diff_new,U_tmp,g_output]=tidu(U_start,U_end,t_new,beta); 
%             
                %g_output_array=[g_output_array g_output];
%                 g_diff_array=[g_diff_array ;abs(g_diff_new)];
%                 t_array=[t_array ;t_new];
%                 
%                 [t_array,index]=sort(t_array,'ascend');%С��������
%                 g_diff_array_tmp=g_diff_array;
%                 %g_output_array_tmp=g_output_array;
%                 for i=1:size(t_array,1)
%                       g_diff_array(i,:)=g_diff_array_tmp(index(i),:);
%                       %g_output_array(i,:)=g_output_array_tmp(index(i),:);
%                 end
%                 figure(1);           
%                 plot(U_tmp(1),U_tmp(2),'*');
                t_new=t_newx;
                U_tmp_last2=aa.U_record(end-1,:);
                
%                 if  norm(U_tmp_last2-U_tmp)<aa.jingdu %/norm(U_tmp)
%                       is_success=1;
%                       break; 
%                 end
                if iter==5
                    aaaa=0;
                end
                g_diff_new=g_diff_new;%  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if iter>=2&& ( abs(g_diff_new)<0.01 )  %||  abs(t_limit_1-t_limit_2)<0.01 %                 %||abs(t_limit_2-t_limit_1)<0.01% (norm(g_new-g_new_last)/norm(g_new)<0.01) %||abs(g_diff_new)<0.01)%/norm(U_tmp)  aa.jingdu
                      is_success=1;%t_limit_2-t_limit_1
                      ii=ii+iter-1;
                      branch_g_compute_num(branch_i_num,:)=g_compute_num-g_compute_num_each_record;
                      break; 
                end
                g_output=g_new;
                aa.U_record=[aa.U_record ;U_tmp];
                aa.g_record=[aa.g_record; g_output];
                x=U_tmp.*aa.bjc+aa.u;
                aa.x_record=[aa.x_record; x];
                U_tmp_last=U_tmp;
                iter;
                if iter>50
                     t=1; 
                end
            end%while

        else%ii<=1
            U_tmp=U_amv;

        end
        %theta_output(ii,:)=atan2(cha_ji(U_tmp,-g_diff_amv),dot(U_tmp,-g_diff_amv))/pi*180;

        if  is_success==1%norm(U_tmp-U_tmp_last)/norm(U_tmp)<aa.jingdu %||is_success==1 /norm(U_tmp)
            is_success=1;
            %break;
        end

end
%aa.inner_iter_num=ii;
is_success=g_output;
aa.g_num_sora(aa.con_fun_index)=aa.g_num_sora(aa.con_fun_index)+g_compute_num;
if aa.if_RBDO_computaiton==1
    aa.inner_iter_num(aa.iter_num,aa.con_fun_index)=g_compute_num;
else
    aa.inner_iter_num=g_compute_num;
end
if aa.if_RBDO_computaiton==1
   eval([ 'aa.MPP_con_' num2str(aa.con_fun_index) '=[aa.MPP_con_' num2str(aa.con_fun_index)     '; U_tmp];' ]);% aa.MPP_con_1=[ aa.MPP_con_1;   U_tmp];
   x=U_tmp.*aa.bjc+aa.u;
   eval([ 'aa.MPP_con_' num2str(aa.con_fun_index) '_X=[aa.MPP_con_' num2str(aa.con_fun_index)     '_X; x];' ]);% aa.MPP_con_1_X=[ aa.MPP_con_1_X;   x];
end
t=1;


end


function [g_diff_t,U,g_output_t   ]=tidu(U_start,U_end,t,beta,jianju_bj)
global aa
     vector=U_end-U_start;
     U_t=U_start+t*vector;
     U=beta*U_t/norm(U_t);
     [ g_diff,g_output_t ] =diff_chafen( aa.index,U,0 );%0 ��ʾ��Ҫ�����ݶ�
     %delta=1e-8;%delta=1e-5;%delta=min(1e-5,jianju_bj);
     %delta=min(1e-8,jianju_bj*0.01);
     delta=jianju_bj*0.01;%����ʵ�����øô���
     delta=jianju_bj*0.1;%����Ԫʵ�����øô���---------------------------------------------------------------------------------------------------
     t=t+delta;
     U_t_extra=U_start+t*vector;
     U_extra=beta*U_t_extra/norm(U_t_extra);
     [ g_diff_extra,g_output_t_extra ] =diff_chafen( aa.index,U_extra,0 );%0 ��ʾ��Ҫ�����ݶ�
      g_diff_t=  (g_output_t_extra-g_output_t)/delta;
     
end

function  [t_array,k_array]=fun_sort(t_array,k_array)
               [t_array,index]=sort(t_array,'ascend');%С��������
                k_array_tmp=k_array;
                %g_output_array_tmp=g_output_array;
                for hh=1:size(t_array,1)
                      k_array(hh,:)=k_array_tmp(index(hh),:);
                      %g_output_array(i,:)=g_output_array_tmp(index(i),:);
                end
        
        
end

function [ t_limit_1 ,t_limit_2 ,g_diff_limit_1 ,g_diff_limit_2]=update_limite(t_limit_1x,t_limit_2x,t_array,g_diff_array)
                            t_limit_1=t_limit_1x;t_limit_2=t_limit_2x;
                            for i=1:size(t_array,1)%�����ݶ�g_diff_array�ķ��ţ�Ѱ���ݶ�g_diff_array �����ű仯ʱ�����ٽ�����������Ϊt_limit_1��t_limit_2
                                if(g_diff_array(i)<0)&& t_array(i)>t_limit_1x
                                    t_limit_1=t_array(i);
                                    g_diff_limit_1=g_diff_array(i);
                                end
                                if(g_diff_array(i)>0)&& t_array(i)<t_limit_2x
                                    t_limit_2=t_array(i);
                                    g_diff_limit_2=g_diff_array(i);
                                end
                            end  
end

function is_ao=is_fun_ao(n1,n2,n3)
% global aa;
%                n1=aa.U_record(end,:); n2=aa.U_record(end-1,:);
%                n3=aa.U_record(end-2,:);
               dis_1=norm(n1-n2); dis_2=norm(n2-n3);
               if (n1-n2)*(n2-n3)'>0 %&& dis_1<dis_2
                   is_ao=0;%��ʾ��͹����
               else
                   is_ao=1;%��ʾ�ǰ�����
               end
               
               
end
