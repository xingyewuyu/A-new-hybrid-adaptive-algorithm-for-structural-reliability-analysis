function [ x,beta,pf, UU,xx,gg ,n_vector ,g_num,nn,array_beta,v_i_array,U_k_new_array,u_k_pre_1,u_k_pre_2,nn_array] = JC_based_method_line_search_two_stage( u,std,type , if_plot0 )
%ÿ�ε������������߷���ֱ������         
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];    mpp_tmp_array=[];   
ab_array=[];    v_i_array=[];  U_k_new_array=[];  u_k_pre_1=[];u_k_pre_2=[]; nn_array=[]; 
n_k_array=[];
weishu=num;  tmp_bjc=bjc;  tmp_u=u;  method=0;  g_num=0;
nn=0; t_i=0.5;
 
%---------��ͼ---------------------
hold off;
if if_plot0==1
    if aa.type==9||aa.type==10||aa.type==31||aa.type==8
        f0=fun(u,type);%���ֵ
        k1=-5; k2=5;
        if aa.type==9
                k1=-5; k2=5;
        elseif aa.type==10
                k1=-6; k2=6;
        end
        length0=0.5;t_min=-1.8;t_max=f0*1;jingdu=1e-2;
        a1=k1;a2=k2;b1=k1;b2=k2;%k1=-1; k2=5;a1=k1;a2=k2;b1=k1;b2=k2;
        [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);   bjc=std;
        x1_ori=x1*bjc(1)+u(1);x2_ori=x2*bjc(2)+u(2);
        Z=fun([x1_ori,x2_ori],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));  g=18.46154-74769.23*x1/x2^3
        t_min=-f0;t_max=f0;
        tt=t_min:(t_max-t_min)/3:t_max;%1e-10
        if aa.type~=31
            for i=1:size(tt,2)
                t_value=tt(i);
           [C,h] = contour(x1,x2,Z,t_value,'b');axis([a1 a2 b1 b2]); grid on;hold on;
            end
        end
        [C,h] = contour(x1,x2,Z,1e-8,'r');grid on;hold on;

        [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*bjc(1)+u(1);xx2_ori=xx2*bjc(2)+u(2);
        Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
        quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;
        t=1;
    end
    set(gcf,'color','white');%box off;grid off;
end




while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;  g_num=g_num+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==4||type==325 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==325
                    num_tmp=num;    
                 end   
                X=x_start;
                VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
%             if  type==4 %||type==35%(strcmp(aa.type_variable,'logn'))
%                 if type==4
%                     num_tmp=num-2;
%                 elseif type==35
%                     num_tmp=2;    
%                  end   
%                 X(1:num_tmp)=u(1:num_tmp)+bjc(1:num_tmp).*x_start_bj(1:num_tmp);
% %                 u=X.*(6.517-log(X));
% %                 bjc=aa.bjc./aa.u.*X;
%                 %aa.u=250;aa.bjc=25; X=210;
%                 logn_para_u=log(u(1:num_tmp).^2./(bjc(1:num_tmp).^2+u(1:num_tmp).^2).^0.5);
%                 logn_para_sigma=(log(  bjc(1:num_tmp).^2./u(1:num_tmp).^2+1)  ).^0.5;
%                 F_x=cdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
%                 inv_norm_F_x=icdf('normal',F_x,0,1);
%                 tmp_bjc(1:num_tmp)=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
%                 tmp_u(1:num_tmp)=X(1:num_tmp)-inv_norm_F_x.*tmp_bjc(1:num_tmp);
%                 x_start_bj(1:num_tmp)= ( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==430  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   aEv=sqrt(6)*bjc((5:7))/pi; uEv=-psi(1)*aEv-u((5:7));
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X((5:7)),uEv,aEv);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc((5:7))=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u((5:7))=X((5:7))-inv_norm_F_x.*tmp_bjc((5:7));  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46||type==462||type==610%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==401%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
            end    
            if if_plot0==1
                 plot(x_start_bj(1),x_start_bj(2),'v'); 
            end
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
        g_start0=g_start;
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
    end
%     if method~=1
            %if nn<=3%JC��
            %1)JC������MPP��
                [ x,U_k_new,diff_g_u_bj,beta  ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type); g_num=g_num+weishu;
                 %plot(U_k_new(1),U_k_new(2),'o');  %g_start_x=fun(x,type);
                 diff=[ diff;  diff_g_u_bj];   
                 ab=-diff_g_u_bj/norm(diff_g_u_bj)-x_start_bj/norm(x_start_bj);
                 %ab=-diff_g_u_bj-(-diff_g_u_bj*x_start_bj'*x_start_bj)/norm(x_start_bj)^2; %ab=ab/norm(ab);
                 ab_array=[ab_array;ab]; plot(U_k_new(1),U_k_new(2),'*');
            %2)���ж�
            if nn>=2
            u3=U_k_new;u2=UU(end,:);u1=UU(end-1,:);
            n3=u3/norm(u3);  n2=u3/norm(u2);  n1=u3/norm(u1);
            %hui_k=(n3-n2)*(n2-n1)';  
            hui_k=(u3-u2)*(u2-u1)';
            hui_k=acos((u3-u2)*(u2-u1)'/norm(u3-u2)/norm(u2-u1))/pi*180;
            if nn==12
                t=1;
            end
                %if  (hui_k<-aa.jingdu) || norm(u3-u2)>norm(u2-u1)   %˵���񵴣����¼���MPP 
                hui_k
                %if  (hui_k<-0.5) || norm(u3-u2)>norm(u2-u1) 
                if  (hui_k>120) || norm(u3-u2)>norm(u2-u1) 
                 %hui_k
                %line search
                    U_pt_start=x_start_bj;  U_pt_end=U_k_new;     
                    if method==0
                            ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:));
                            v_i=U_pt_start+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start); v_i=beta*v_i/norm(v_i);
                            g_v_i=fun(v_i.*aa.bjc+aa.u,type);  g_num=g_num+1;
                            plot(U_k_new(1),U_k_new(2),'s'); 
                            plot(v_i(1),v_i(2),'+'); 
                            if nn==4
                               t=1; 
                            end
                           if_plot=0;jianju_mpp=norm(UU(end,:)-UU(end-1,:)); 
                           U_k_new=v_i;
                           beta=norm(U_k_new);
                           %�ҳ�ԭ����MPP֮���ֱ�� �� g(u)=0�Ľ��� 
                           %[U_k_new,g_U_k_new,g_num0]=fun_find_g0_mpp(0,v_i,tmp_u,tmp_bjc,type,g_v_i,delta0,jianju_mpp,if_plot);
                           [U_k_new,g_U_k_new,g_num0]=fun_find_g0_mpp3(0,g_start0,v_i,g_v_i,tmp_u,tmp_bjc,type,if_plot);
                           beta=norm(U_k_new);  g_num=g_num+g_num0;   
                           v_i_array=[v_i_array; v_i];  %U_k_new_array=[U_k_new_array;U_k_new];
                           u_k_pre_1=[u_k_pre_1;UU(end,:)];u_k_pre_2=[u_k_pre_2;UU(end-1,:)];  nn_array=[nn_array;nn]; 
                           if(g_U_k_new<0.1)
                                 method=1;
                           end
                    else%method==1
                           dis_last=norm(UU(end,:)-UU(end-1,:)); dis_new=norm(UU(end,:)-U_k_new);
                           if(dis_last>=dis_new)% U_k_new����UU(end,:)����
                               ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:));
                               v_i=x_start_bj+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start); v_i=beta*v_i/norm(v_i);
                           else%)% U_k_new����UU(end,:)��Զ
                               if abs(gg(end,:))<abs(gg(end-1,:))
                                      U_pt_start=UU(end,:);  U_pt_end=UU(end-1,:); 
                                      ramba=abs(ab_array(end,:))/(abs(ab_array(end,:))+abs(ab_array(end-1,:)))*norm(U_pt_end-U_pt_start);
                               else
                                      U_pt_end=UU(end,:);  U_pt_start=UU(end-1,:);  
                                      ramba=abs(ab_array(end-1,:))/(abs(ab_array(end,:))+abs(ab_array(end-1,:)))*norm(U_pt_end-U_pt_start);
                               end
                               beta=norm(U_pt_start);
                               
                               v_i=U_pt_start+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start); 
                               v_i=beta*v_i/norm(v_i);
                               %v_i=array_beta(end,:)*v_i/norm(v_i);
                           end
                           
                           plot(v_i(1),v_i(2),'+'); 
                           %g_v_i=fun(v_i.*aa.bjc+aa.u,type);  g_num=g_num+1; jianju_mpp=norm(UU(end,:)-UU(end-1,:));
                           %[U_k_new,g_U_k_new,g_num0]=fun_find_g0_mpp(0,v_i,tmp_u,tmp_bjc,type,g_v_i,delta0,jianju_mpp,if_plot); g_num=g_num+g_num0;
                           U_k_new=v_i;
                           %U_k_new=v_i/norm(v_i)*beta;
                           beta=norm(U_k_new);
                           t=1;
                          t=1;
                    end
                    %plot(U_k_new(1),U_k_new(2),'*'); 
                    %plot(U_k_new(1),U_k_new(2),'o');  %g_start_x=fun(x,type);
                    array_beta=[array_beta;beta];

                else
                    array_beta=[array_beta;beta];
                end
            else
                array_beta=[array_beta;beta];  
            end
            %U_k_new_array=[U_k_new_array;U_k_new];
    %plot(U_k_new(1),U_k_new(2),'o');  %g_start_x=fun(x,type);
%                            v_i_array=[v_i_array; v_i];  U_k_new_array=[U_k_new_array;U_k_new];
%                            u_k_pre_1=[u_k_pre_1;UU(end,:)];u_k_pre_2=[u_k_pre_2;UU(end-1,:)];  nn_array=[nn_array;nn]; 
    n_k_array=[n_k_array; U_k_new/norm(U_k_new) ];
    if size(diff,1)>=2
        error_diff=[error_diff; diff(end,:)-diff(end-1,:)];
        error=[error;  norm(error_diff(end,:))];
    end

   if nn>=1
   end
            if nn==2
               t=1; 
            end
    nn=nn+1;[beta nn]
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
    %t1 = toc  % ���㾭����ʱ��
    aa.nn=nn;
    if nn-1>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
            
        end
    end
    x_start_bj=U_k_new;
    x=x_start_bj.*tmp_bjc+tmp_u;
    xx=[xx;X];


end
%nn=nn-1;
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)];  UU=[UU; U_k_new];
aa.gg=gg; aa.xx=xx;aa.UU=UU;
 n_vector=[];
 
  plot(UU(:,1),UU(:,2),'-bo');
  plot(UU(:,1),UU(:,2),'-g');
% hold on;
% for i=1:size(UU,1)
%     plot(UU(i,1),UU(i,2),'ro');
% end 
t=1;
end






function [ x,U_k_new,diff_g_u_bj,beta ] =JC_compute_mpp(X,x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type)

            %delta0
            [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
            %diff_g_x_bj
                        if isnan(diff_g_x_bj(1))
                            t=1;
                        end
            diff_g_x=diff_g_x_bj./tmp_bjc;
            gs=diff_g_x.*tmp_bjc;
        %     tidu_bj=tidu.*bjc;
               beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  
               beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
               u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
               alpha=-gs./norm(gs);%----------------���ݶȷ���
             x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;

            diff_g_u_bj=diff_g_x_bj;
end



%�ҳ�ԭ����MPP֮���ֱ�� �� g(u)=0�Ľ��� 
%�ҳ�ԭ����MPP֮���ֱ�� �� g(u)=0�Ľ��� 
function [U_k_new,g_U_k_new,g_num]=fun_find_g0_mpp3(u_satrt,g_satrt,u_end,g_end,tmp_u,tmp_bjc,type,if_plot)
global aa;
        g_num=0;
        v_i=u_end-u_satrt;vector=v_i/norm(v_i);
        t_i0=norm(v_i); f_t_i0=g_end;
%         if f_t_i0<-10%g(u)<0
%             t_i0=t_i0/2;
%             fuhao=1;%��ʾ��g(u)>0������
%             u_i0=u_satrt+vector*t_i0;
%         elseif f_t_i0 <10
%                t_i0=t_i0; 
%         else%g(u)>0  f_t_i0>10
%             t_i0=t_i0*2;
%             fuhao=-1;%��ʾ��g(u)<0������
%             u_i0=u_satrt+vector*t_i0;
%         end
%         f_t_i0=fun(u_i0.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
        t_i=0;f_t_i=g_satrt;
        iter_num=0;  
        %1)�ҳ�g(u)>0�ĵ�
        %t_i=min(0.5,0.5*jianju_mpp);
        
        while 1
%            u_i=u_satrt+vector*t_i;
%            f_t_i=fun(u_i.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
           
           %t_i_new=t_i0-f_t_i0/(f_t_i-f_t_i0)*(t_i-t_i0);%��ֵ��
           t_i_new=t_i-f_t_i/(f_t_i-f_t_i0)*(t_i-t_i0);%��ֵ��
           u_i_new=u_satrt+vector*t_i_new;
           if g_num==2;
              ttt=0; 
           end
           f_t_i_new=fun(u_i_new.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
           
           f_t_i0=f_t_i;
           t_i0=t_i;
           t_i=t_i_new;
           f_t_i=f_t_i_new;%;   
           if(abs(f_t_i)<aa.jingdu)%aa.jingdu *0.1
               break;
           end
        end%while
        if if_plot==1
           plot(u_i(1),u_i(2),'o');
        end
        %if_plot=1;
        %2)�ҳ�g(u)=0�ĵ�
        %[ t_i_end,u_i_end,f_t_i_end,g_num_end ] =fun_Steffensen_vector(0,f_t_i,type,-vector,delta0,tmp_u,tmp_bjc,u_i,0);
         %U_k_new= u_i_end;  g_U_k_new=f_t_i_end;  g_num=g_num+g_num_end;
         u_i=u_satrt+vector*t_i;
         U_k_new= u_i;  g_U_k_new=f_t_i;  

end
% function [U_k_new,g_U_k_new,g_num]=fun_find_g0_mpp(u_satrt,g_satrt,u_end,g_end,tmp_u,tmp_bjc,type,if_plot)
% global aa;
%         g_num=0;
%         iter_num=0;  %vector=u_end/norm(u_end);
%         %1)�ҳ�g(u)>0�ĵ�
%         %t_i=min(0.5,0.5*jianju_mpp);
%         t1=0; t2=1;
%         %u_1= u_satrt+(u_end-u_satrt)*t1;  u_2= u_satrt+(u_end-u_satrt)*t2;
%         g1=g_satrt;g2=g_end;
%         u1=u_satrt;u2=u_end;
%         while 1
%            tx=t1-(t1-t2)/(g1-g2)*g1;
%            u_x= u1+(u2-u1)*tx; 
%            if if_plot==1
%                plot(u_x(1),u_x(2),'o');
%            end
%            gx=fun(u_x.*tmp_bjc+tmp_u,type);  g_num=g_num+1;
%            if tx>1
%                  %t1=t2;t2=tx;
%                  u1=u2;u2=u_x;
%                  g1=g2;g2=gx;
%            elseif tx>0.5
%                  %t1=tx;t2=t2;
%                  u1=u_x;u2=u2;
%                  g1=gx;g2=g2;
%            else%tx<0.5
%                 %t1=t1;t2=tx;
%                 u1=u1;u2=u_x;
%                 g1=g1;g2=gx;
%            end
%            if(abs(gx)<aa.jingdu *0.01)
%                break;
%            end
% 
%         end%while
% 
%         %if_plot=1;
%         %2)�ҳ�g(u)=0�ĵ�
%         %[ t_i_end,u_i_end,f_t_i_end,g_num_end ] =fun_Steffensen_vector(0,f_t_i,type,-vector,delta0,tmp_u,tmp_bjc,u_i,0);
%          %U_k_new= u_i_end;  g_U_k_new=f_t_i_end;  g_num=g_num+g_num_end;
%          U_k_new= u_x;  g_U_k_new=gx;  
% 
% end

% function [U_k_new,g_U_k_new,g_num]=fun_find_g0_mpp(start_u0,v_i,tmp_u,tmp_bjc,type,g_start,delta0,jianju_mpp,if_plot)
% global aa;
%         g_num=0;
%     