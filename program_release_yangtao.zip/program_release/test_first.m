%test_first
clear;
clc;
global aa;
global path;

%path='d:\1\reliability_line_search\program';
file_mulu=which('test_first.m');%f=fullfile('D:','Matlab','example.txt');file0=fliplr('main_first_panelobj_iternum_butongstartpoint_1.m');
file_index=findstr(file_mulu,'test_first.m');
path=file_mulu(1:file_index-2);
cd(path);
 %load matlab-type42.mat
addpath(genpath(path));aa.nn=0;

type=9;%325; %ex1      ex2      ex3       ex4    ex5  ex6   ex7    ex8 ----zzzzzzzzzzzzz----�����õ���ʵ��˳��
             %8��9     4      47(���37)    7    325  401   60   42 ----zzzzzzzzzzzzz----�����õ���ʵ����Ӧ��typeֵ
aa=[];       
aa.type=type;  aa.nn=0; aa.g_num=0;
aa.jingdu=1e-3;   aa.g_diff_tongji=[]; aa.inner_num_g=0; aa.beta=[];aa.gg=[]; aa.xx=[];aa.UU=[];aa.kkt=[];aa.inner_num_g_iter=[];
aa.if_compare_with_real_tidu=1;%�������ʵ�ݶȽ��бȽ�
[u bjc var ]=input_canshu1(type);para_num=size(u,2);
fun_num=0;  
%---�������ܺ��������Խ����ķ���  
tic;  % ������ʱ��
aa.if_compare_with_real_tidu=1;%�������ʵ�ݶȽ��бȽ�
if_plot0=1;
if_JC=0;  
if type==1||type==3||type==5||type==7||type==9 
    if_JC=1;disp('test JC_method_ansys2..............................');
   [ x0,beta0,pf0,UU0,xx0,gg0 ,n_vector0,nn0,array_beta0,num_g_JC] = JC_method_ansys2( u,bjc,type, if_plot0 );hold off; %------------ok
   %plot(UU0(:,1),UU0(:,2),'-go');
end

if type==1||type==3||type==4||type==5||type==6||type==7%||type==9      
    disp('test bieren_DSTM_method.............................................'); 
   [ x_DSTM,beta_DSTM,pf_DSTM,UU_DSTM,xx_DSTM,gg_DSTM ,n_vector_DSTM,nn_DSTM,array_beta_DSTM,num_g_DSTM] = bieren_DSTM_method( u,bjc,type, if_plot0  ); 
end

if type==1||type==3||type==4||type==5||type==6||type==7%||type==9      
    disp('test bieren_adaptive_method.............................................'); 
[ x_AFRA,beta_AFRA,pf_AFRA,UU_AFRA,xx_AFRA,gg_AFRA,n_vector_AFRA,nn_AFRA,array_beta_AFRA,num_g_AFRA ] = bieren_adaptive_method(u,bjc,type, if_plot0 ); 
end

if type==1||type==3||type==4||type==5||type==7||type==8%||type==9   
    disp('test bieren_HRHLRF_method.............................................'); 
[ x_HRHLRF,beta_HRHLRF,pf_HRHLRF,UU_HRHLRF,xx_HRHLRF,gg_HRHLRF ,n_vector_HRHLRF,nn_HRHLRF,array_beta_HRHLRF,num_g_HRHLRF] = bieren_rHLRF_method( u,bjc,type, if_plot0  );
end


if type==1||type==2||type==3||type==4||type==5||type==7||type==8||type==9   
  disp('test HLRF_BFGS_method.............................................'); 
 [ x_HLRF_BFGS,beta_HLRF_BFGS,pf_HLRF_BFGS, UU_HLRF_BFGS,xxHLRF_BFGS,gg_HLRF_BFGS ,n_vector_HLRF_BFGS,nn_HLRF_BFGS,array_beta_HLRF_BFGS,num_g_HLRF_BFGS  ] = ...
                                 HLRF_BFGS_method( u,bjc,type, if_plot0 );
end

%�ҵķ���
hold off;
%[ x4,beta4,pf4, UU4,xx4,gg4 ,n_vector4,g_num4  ] = JC_based_method_line_search_min_g_simplify2( u,bjc,type);num_g4=g_num4;aa.inner_num_g=0;hold off;
%if type~=325
disp('test our method.............................................'); 
[ x_line_search,beta_line_search,pf_line_search, UU_line_search,xx_line_search,gg_line_search ,n_vector_line_search,  ...
    num_g_line_search ,nn_line_search,array_beta_line_search,v_i_array_line_search,...
    U_k_new_array_line_search,u_k_pre_1_line_search,u_k_pre_2_line_search,nn_array_line_search  ]  ...
                  = JC_based_method_line_search_min_g_simplify( u,bjc,type, if_plot0 );%num_g_line_search=g_num_line_search;aa.inner_num_g=0;hold off;

t=1;    


