function Y_new=fun(x,type)
global fun_num
global path
global aa;global fun_val;
yiban=size(x,2)/2;
    aa.g_num=aa.g_num+1;
    fun_num=fun_num+1;
    
    if type==1  % Case 1 in Example 1 The 2-dimensional functions
          x1=x(:,1:yiban);x2=x(:,yiban+1:end);
          Y_new=exp(0.4*x1+7)-exp(0.3*x2+5)-200;
    elseif type==2    % Case 2 in Example 1 The 2-dimensional functions 
          x1=x(:,1:yiban);x2=x(:,yiban+1:end);P=1;
          Y_new=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2))); 
    elseif type==3    %   Example 2  The 6-dimensional nonlinear performance function with non-normal variables. 
          Nc=x(:,1);Nf=x(:,2);nc=x(:,3);nf=x(:,4);theta1=x(:,5);theta2=x(:,6);%S=x(1);D=x(2);F=x(3);L=x(4);T=x(5);
          Dc=nc./Nc;Df=nf./Nf;
          Y_new=2-exp(theta1.*Dc)+(exp(theta1)-2)./(exp(-theta2)-1)...
                  .*(exp(-theta2.*Dc)-1)-Df;
    elseif type==4    %   Example 3 The strong non-linear performance function with high dimension
          Y_new=2; num=size(x,2);
          for i=1:num-1
              Y_new=Y_new+0.015*x(i)^5;
          end
          Y_new=Y_new-x(num)*0.5; 
          for i=1:num-2
              Y_new=Y_new+0.015*x(i)^2*x(i+1)^3*x(i+2)*1;
          end
          Y_new=Y_new-x(num-1)*x(num)*0.1;
    elseif type==5    %   Example 4 The 9-dimensional engineering case with norm variables.
          Eo=x(:,1);Ei=x(:,2);to=x(:,3);ti=x(:,4);
          G=x(5);b=x(6);L=x(7);P=x(8);Sa=x(9);
          h=0.02;delta_T=130;aofa_i=13e-6;aofa_o=6e-6;
          w=(G./h.*(1./Eo./to+2./Ei./ti)).^0.5;
          y1=P.*w/(4*b.*sinh(w.*L/2));
          y2=P.*w/(4*b.*cosh(w.*L/2)).*(2*Eo.*to-Ei.*ti)./(2*Eo.*to+Ei.*ti);
          y3=(aofa_i-aofa_o).*delta_T.*w/((1./Eo./to+2./Ei./ti).*cosh(w.*L/2));  xx=0.5;
          yingli_max=y1.*cosh(w.*xx)+(y2+y3).*sinh(w.*xx);
          Y_new=Sa-yingli_max;    
    elseif type==6    %   Example 5 The 8-dimensional strong nonlinear engineering case with non-normal variables.
            x1=x(:,1);x2=x(:,2);x3=x(:,3);x4=x(:,4);   
            x5=x(:,5);x6=x(:,6);x7=x(:,7);x8=x(:,8);
            kp=x1; ks=x2; mp=x3; ms=x4;  hui_p=x5; hui_s=x6; Fs=x7; S0=x8; 
            wp=(kp/mp)^0.5; ws=(ks/ms)^0.5; hui_a=(hui_p+hui_s)*0.5; wa=(wp+ws)*0.5; ita=(wp-ws)/wa; v=ms/mp;

            p1=pi*S0/4/hui_s/ws^3;
            p2=(4*hui_a^2+ita^2)*hui_p*hui_s+v*hui_a^2;
            p3= hui_s*hui_a/p2;
            p4=(hui_p*wp^3+hui_s*ws^3)*wp;
            p5=p4/4/(hui_a*wa^4);
            Ex2=p1*p3*p5;
            P=3;
            Y_new=Fs-ks*P*Ex2^0.5; 
    elseif type==7    %   Example 6  The 11-dimensional case of the 72-bar truss.
             H=x(1);  B=x(2);  t=x(3);  a_a=x(4); a_b=x(5); a_c=x(6); E=x(7); density=x(8);  P1=x(9); P2=x(10); P3=x(11); 
             b=B-2*t;    h=H-2*t;
            area=(H*B-h*b)/1e6;
                     [W,dispmax,stressmax,frequency]=Trusssizeopt_hengjia_compu_abc(area,E,density,P1,P2,P3,a_a,a_b,a_c);
            dispmax=dispmax*1000;%��λm
            Y_new=150-frequency;
    elseif type==8    %   Example 7 The 13-dimensional nonlinear case of the four-storey building.
            example4_sim_xiu(x,aa.bjc,aa);
            Y_new=fun_val.con3;%����2��¥��λ�Ʋ�  
    elseif type==9    %   Example 8  The bending transducer.
            dv=x;
            fid=fopen(strcat(path,'\test_ansys\Transducer\dv.txt'),'w+');   
            fprintf(fid,'%16.10f,',dv);%,\n
            status=fclose(fid);
            [ data ] = run_ansys( path );
            Y_new=144-abs(data(1));
    end

    
    
    
    

    
    
    
    
    