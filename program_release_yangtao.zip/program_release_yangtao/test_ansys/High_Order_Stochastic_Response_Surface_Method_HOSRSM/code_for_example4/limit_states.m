function g = limit_states(z)
% Limit State Functions
% (This function is called by HOSRSM.m as limit_state )
%
%   g = limit_states(z)
%
% Input:
%   z - sample values of the standardized normal random variables 
%       which are involved in the limit state function
%
% Output:
%   g - value of the limit function
%
% Department of Civil and Environmental Engineering
% Duke University
% Siu Chung Yau, Henri P. Gavin, January 2006, Updated October 2009

% Example 1 - Hypothetical Limit State with 2 Variables
% g = -0.16*(z(1)-1)^3 - z(2) + 4 - 0.04*cos(z(1)*z(2));

% Example 2 - Hypothetical Limit State with 3 Variables
% g = -0.32*(z(1)-1)^2*z(2)^2 - z(2) + z(3)^3 + 8 - 0.2*sin(z(1)*z(3));

% Example 3 - Dynamic Problem of One Degree of Freedom
%             (7 Random Variables)  
% rmax = example3_sim(z);    
% g = 0.04 - rmax;

Example 4 - Dynamic Problem of Six Degrees of Freedom
            (8 Random Variables)
g = example4_sim(z);

% Example 5 - Hypothetical Limit State with 2 Variables
% mu = 10 ;
% si =  3 ;
% z =  mu + z*si; 
% g = 2.2257 - 0.025*sqrt(2)/27*(z(1)+z(2)-20)^3 + 33/140*(z(1)-z(2));

% Example 6 - beam deflection
% S = 0.2034519; % sqrt(log(1+Vx))  for log-normal variables
% l = 30.0000 *(1 + z(1)*0.1);            % normal length, in
% b =  0.8359/1.0488088 * exp(z(2)*0.02034519);  % log-normal width, in
% h =  2.5093/1.0488088 * exp(z(3)*0.2034519);   % log-normal depth, in
% E = 1e7;      % modulus, psi
% P = 20;       % tip load, lb
% g = 0.15 - 4*P*(l/h)^3 / (E*b);

% Example 7 - Hypothetical Limit State with 2 Variables, and 2 design points
%
% g = 7 - z(1)^2 - z(2);

% Example 8 - Hypothetical Limit State with 2 Variables, and 2 design points
%
%C1 = 5.0; C2 = 0.5; C3 =  2.0; C4 = 1.5; r = 3;       % Case I
%C1 = 3.0; C2 = 2.0; C3 = -0.1; C4 = 1.0; r = 4;       % Case II
%g = C1 + C2*(z(1) + C3)^r - C4*(z(1) + C3)^3  -  z(2);

% Example 9 - Hypothetical Limit State with 3 Variables
%
%   g = z(1)^4/40.0 + 2.0*z(2)^2 + z(3) + 3.0;

% Example 10 
% - Hypothetical Limit State with 3 Variables and Significant Cross Terms
% (10.14.2009)
%
%g = 20 + z(1) + 2*z(1)^2 + 3*z(1)^3 - 4*z(2) + 5*z(1)^2*z(2) - 6*z(3) + 7*z(1)^2*z(3) + 8*z(1)*z(2)*z(3);

% ------------------------------------------- limit_states.m 
% updated 1-23-2006, 10-14-09
