function  data=run_ansys( path,aa )
%UNTITLED2 Summary of this function goes here
global aa;
%   Detailed explanation goes here
output_file_name='outdata.txt';
if aa.type==42
       output_file_name='outdata1.txt';
       path1=strcat(path,'\test_ansys\shuiba\');
       runfile='dam_model_static_analysis.lgw';     %dam   dam_model_static_analysis.lgw
elseif aa.type==44
       path1=strcat(path,'\test_ansys\piezoresistive\');
       runfile='piezoresistive.lgw';
elseif aa.type==45
       path1=strcat(path,'\test_ansys\support\');
       runfile='support.lgw';
elseif aa.type==9
       path1=strcat(path,'\test_ansys\Transducer\');
       runfile='xducer2d.cdb';  
% elseif aa.type
%        path1=strcat(path,'\test_ansys\shuiba\');
%        runfile='dam_model_static_analysis.lgw';     %dam   dam_model_static_analysis.lgw
end
% if exist(strcat(path1,'*.mnf'),'file')
  %   delete(strcat(path1,'*.mnf'));
 %end
if exist(strcat(path1,output_file_name),'file')
    delete(strcat(path1,output_file_name));
end 
 t=delete_files(path1,'file*.*');

 
%(2)-------------����ansys���У�����������------------------
cd(path1);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %(2.1)��ȡ������ԭ�����е�����
% 
% fid = fopen([path1 'piezoresistive1.lgw'],'rt');
% [mingling,COUNTo] = fscanf(fid,'%s  ',[1,inf]);
% fclose(fid);
% 
% 
% %(2.2)����ANSYS����Ŀ¼��ansys�������У������浽�������ļ���
% mulu_ansys=['/CWD,''' path1  ''''];%����ANSYS����Ŀ¼
% mingling=[ mulu_ansys    '\n '  mingling  ];
% fid = fopen([path1 'piezoresistive2.lgw'],'wt');
% fprintf(fid,'%s\n',mingling);
% fclose(fid);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%��2.3����������������
% system('"C:\Program Files\ANSYS Inc\v150\ansys\bin\winx64\ANSYS150.exe" -b -p ane3fl -i piezoresistive.lgw -o sh.log');  %winopen('d:\ex\tenbar.bat')
 string1=['"d:\Program Files\ANSYS Inc\v150\ansys\bin\winx64\ANSYS150.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
  string2=['"c:\Program Files\ANSYS Inc\v150\ansys\bin\winx64\ANSYS150.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
  string2=['"e:\Program Files\ANSYS Inc\v192\ansys\bin\winx64\ANSYS192.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
  string2=['"d:\Program Files\ANSYS Inc\v221\ansys\bin\winx64\ANSYS221.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
  string2=['"E:\Programe\ANSYS2022R1\ANSYS Inc\v221\ansys\bin\winx64\ANSYS221.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];

  string2=['"E:\Program Files\ANSYS Inc\v221\ansys\bin\winx64\ANSYS221.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
  string2=['"E:\Programe\ANSYS2022R1\ANSYS Inc\v221\ansys\bin\winx64\ANSYS221.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];
 %    string=['"C:\Program Files\ANSYS Inc\v150\ansys\bin\winx64\ANSYS150.exe" -b -p ane3fl -i ',runfile,'  -o sh.log'];% strcat('"C:\Program Files\ANSYS Inc\v150\ansys\bin\winx64\ANSYS150.exe" -b -p ane3fl -i ',runfile,'  -o sh.log');
  %    system(string1);  
system(string2);  
% system('"D:\Program Files\ANSYS Inc\v140\ansys\bin\intel\ansys140" -b p ane3fl -i "D:\FEM\ANSYS\test.txt" -o "D:\FEM\ANSYS\result.out"')
% t = timer( 'Period',0.1 ,'TimerFcn', {@TimerFcn1});
%aa.nnn(aa.con_fun_index)=aa.nnn(aa.con_fun_index)+1;
while(1)%�ȴ�������ȫ������
 pause(1);
 if exist(strcat(path1,output_file_name),'file')
     break;
 end
end
%(4)-------------��ȡ�ļ�
%1����ȡsave_time�ļ�
        fid = fopen(strcat(path1,output_file_name),'r');
        [data,COUNT] = fscanf(fid,'%f  \n',[1,inf]);
        fclose(fid);
        delete(output_file_name) ;
%delete outdata.txt;
cd(path);
t=1;
%        71.09912201162076428318
%         0.00482391174911281796
%         3.02473461814568178596

function t=delete_files(dir0,prefix)
% ��������Ҫɾ��������'prefix_'��ͷ���ļ�
    %prefix = 'prefix_';
    % ��ȡ��ǰĿ¼�������ļ�
    files = ls(fullfile(dir0, ['*' prefix '*']));
    % �����ļ��б�
    for i = 1:length(files)
        if exist(strcat(dir0,files(i,:)),'file')
            delete(strcat(dir0,files(i,:))) ;%delete(files(i,:)) ;
        end
    end
    t=1;
