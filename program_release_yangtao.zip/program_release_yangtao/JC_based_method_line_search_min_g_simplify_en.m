function [ x,beta,pf, UU,xx,gg ,n_vector ,g_num,nn,array_beta,v_i_array,U_k_new_array,u_k_pre_1,u_k_pre_2,nn_array] = JC_based_method_line_search_min_g_simplify_en( u,std,type , if_plot0 )
% Implementation of the hybrid adaptive algorithm (corresponding to the HAMA algorithm in Section 3.3 of the paper)
% Paper title: A new hybrid adaptive algorithm for structural reliability analysis
% The above hybrid adaptive algorithm is summarized as follows:


% Specifying G(X), ��_X, ��_X. Set k=0, ��=0.001, X^0=��_X
% Input parameters:
%   u: Mean vector of random variables (e.g., ��_X in the paper)
%   std: Standard deviation vector of random variables (e.g., ��_X in the paper)
%   type: Problem type identifier (corresponding to examples in the paper, e.g., type=1 for Example 1 Case 1)
%   if_plot0: Plot flag (1 to enable plotting)
% Output parameters:
%   x: Final design point (MPP, corresponding to u* in the paper)
%   beta: Reliability index (corresponding to �� in the paper)
%   pf: Failure probability
%   UU: Collection of U-space points during iteration (each row corresponds to u^k for one iteration)
%   xx: Collection of X-space points during iteration
%   gg: Collection of performance function values during iteration
%   n_vector: Collection of unit vectors (for search direction)
%   g_num: Number of performance function calls
%   nn: Total number of iterations
%   array_beta: Collection of reliability indices for each iteration
%   v_i_array: Collection of adaptive search points v^k (corresponding to v^k in Section 3.1 of the paper)
%   U_k_new_array: Collection of new MPP points u^{k+1}
%   u_k_pre_1: Collection of previous iteration points u^{k-1}
%   u_k_pre_2: Collection of points from two iterations ago u^{k-2}
%   nn_array: Collection of iteration indices

global aa; % Global variable for storing intermediate results and statistical information of the algorithm

% ========== STEP 1: Parameter initialization ==========
u1=u; std1=std; bjc=std; % Initialize variables (bjc is an alias for standard deviation)
x=u; last_normx=1e9; % Initialize x to the mean, last_normx used for convergence judgment
num=size(x,2); % Number of random variables
gg=[]; xx=u; diff=[]; error_diff=[]; error=[]; UU=[]; kkt=[]; array_beta=[]; 
aa.theta=[]; mpp_tmp_array=[]; % Initialize collection of intermediate variables
ab_array=[]; v_i_array=[]; U_k_new_array=[]; u_k_pre_1=[]; u_k_pre_2=[]; nn_array=[];   
n_k_array=[]; % Used to store unit vectors for search direction
weishu=num; tmp_bjc=bjc; tmp_u=u; method=0; g_num=0; % weishu is the dimension of variables, g_num is the count of performance function calls
nn=0; t_i=0.5; % nn is the iteration count, t_i is the line search parameter
aa.jingdu=1e-3; % ��=0.001 (convergence tolerance)

if_use_my_method=0; aa.inner_num_g=0; % Flag to control whether to use custom method

% ========== MAIN ITERATION LOOP (Steps 2-12) ==========
% Main iteration loop (corresponding to the Algorithm in Section 3.3 of the paper)
while 1 % Convergence condition: norm(u^{k+1} - u^k) / norm(u^k) < precision aa.jingdu
    
    % ========== STEP 2: Transform X^k to u^k by Eq.(4) and Eq.(6) ==========
    last_normx=norm(x); % Save the norm of the current point to check convergence
    
    % Current iteration point
    X=x; x_start=X;
    if if_use_my_method==0
        % Calculate the performance function value (g(u) in the paper)
        g_start=fun(x_start,type); aa.inner_num_g=aa.inner_num_g+1; g_num=g_num+1;
    else
        g_start=g_U_k_new; % Use the previously calculated value
    end
    if_use_my_method=0; % Reset flag
    gg=[gg; g_start]; % Save performance function value
    
    % Transform to U-space (corresponding to formulas (4) and (6) in the paper)
    x_start_bj=(x_start-tmp_u)./tmp_bjc; % Standardization processing
    
    % Handle different distribution types (including non-normal distributions)
    if type==3 || type==6 
        if type==3
            num_tmp=num-2;
        elseif type==6
            num_tmp=num;    
        end   
        X=x_start;
        VV=bjc./u;
        tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5; % Lognormal distribution transformation
        tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
        x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
    elseif type==4     
        X=x_start;
        aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
        F_x=1-evcdf(-X,-uu,1./aofa); pdf_x=pdf('ev',-X,-uu,1./aofa);
        inv_norm_F_x=icdf('normal',F_x,0,1);  
        tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
        tmp_u=X-inv_norm_F_x.*tmp_bjc;  
        x_start_bj=( X-tmp_u )./tmp_bjc;
    elseif type==7 || type==9 % Non-normal distribution processing (Section 2.1 of the paper)
        num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
        X=x_start;
        VV=bjc./u;
        tmp_u=u; tmp_bjc=bjc;
        x_start_bj=( X-tmp_u )./tmp_bjc;
        tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
        tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5)); 
        x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
    end   
    UU=[UU; x_start_bj]; % Save U-space points
    
    % Set the step size delta0 for gradient calculation (adaptive adjustment)
    if nn==0
        delta0=aa.delta; % Initial step size
        g_start0=g_start; % Save initial performance function value
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01, delta0); % Adjust step size based on the last iteration
    end

    % ========== STEP 3: Compute f(u^k) by the HLRF algorithm, i.e., Eq.(5) ==========
    [ x, U_k_new, diff_g_u_bj, beta ] = JC_compute_mpp(X, x_start_bj, delta0, tmp_u, tmp_bjc, g_start, type); 
    g_num=g_num+weishu; aa.inner_num_g=aa.inner_num_g+weishu; % Update function call count
    diff=[ diff; diff_g_u_bj ]; % Save gradient difference
    ab=-diff_g_u_bj/norm(diff_g_u_bj) - x_start_bj/norm(x_start_bj); % Calculate search direction (��^k in Section 3.1 of the paper)
    ab_array=[ab_array; ab]; % Save direction vector

    % ========== STEP 4: Branch selection based on convergence conditions ==========
    % If k��2 or f(u^k) satisfies Case 1 (Branch 1), set u^{k+1}=f(u^k) and go to Step 12
    % Otherwise, go to Step 5 for using Branch 2
    if nn>=2
        u3=U_k_new; u2=UU(end,:); u1=UU(end-1,:); % Current, last, and second last iteration points
        % Formula (18): ��^k = acos[(u^{k+1} - u^k) �� (u^k - u^{k-1}) / (||u^{k+1} - u^k|| ||u^k - u^{k-1}||)]
        hui_k=acos((u3-u2)*(u2-u1)'/norm(u3-u2)/norm(u2-u1))/pi*180; % Calculate angle ��^k
        
        % ========== STEP 4: Determine whether to enter Branch 2 (Formula (24)) ==========
        % Determine whether to enter Branch 2: if ��^k �� 90�� or ��^k > ��^{k-1}
        if (hui_k>90) || norm(u3-u2)>norm(u2-u1) 
            
            % ========== STEP 5: Compute v^k by Eqs.(19)-(20) ==========
            % Adaptive MPP search (Section 3.1 of the paper)
            U_pt_start=x_start_bj; U_pt_end=U_k_new;    
            
            if method==0
                % Calculate v^k (formulas (19)-(20) in the paper)
                % Formula (19): ��^k = -?g(u^k)/||?g(u^k)|| - r^k where r^k = u^k/||u^k||
                % Formula (20): v^k = u^k + ��^k [f(u^k) - u^k]/||f(u^k) - u^k||
                % where ��^k = ||��^k||/(||��^k|| + ||��^{k-1}||) ||u^k - u^{k-1}||
                ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:)); % Weight coefficient ��^k
                v_i=U_pt_start + ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start); % v^k point
                g_v_i=fun(v_i.*tmp_bjc+tmp_u, type); g_num=g_num+1; aa.inner_num_g=aa.inner_num_g+1; % Calculate performance function value at v^k
                tol=aa.jingdu; % Convergence tolerance
                
                % ========== STEP 6: If g(v^k) �� 0, set u^{k+1}=v^k ==========
                if abs(g_v_i)<tol
                    % ========== STEP 11: Set u^{k+1}=v^k ==========
                    U_k_new=v_i; % If v^k is on the failure surface, directly use it as the new MPP
                    
                % ========== STEP 7: If g(v^k) �� 0, check if g(v^k) �� g(0) ==========
                elseif g_v_i<g_start0 % Check search direction validity
                    
                    % ========== STEP 8: Use secant method to find intersection point u* ==========
                    % Use the secant method to find the intersection with the failure surface (Appendix A of the paper)
                    if_plot=0; jianju_mpp=norm(UU(end,:)-UU(end-1,:)); 
                    U_k_new=v_i;
                    beta=norm(U_k_new);
                    [U_k_new, g_U_k_new, g_num0]=fun_find_g0_mpp3(0, g_start0, v_i, g_v_i, tmp_u, tmp_bjc, type, if_plot, tol);
                    g_num=g_num+g_num0; aa.inner_num_g=aa.inner_num_g+g_num0;
                    
                    % Check convergence condition (A.3)
                    if abs(g_U_k_new) < tol
                        % ========== STEP 10: Set u^{k+1}=u* ==========
                        if_use_my_method=1; % Update flag
                    else
                        % ========== STEP 9: Compute u^{k+1} by Eq.(23) ==========
                        % Alternative method: weighted average of the previous two iteration points
                        % Formula (23): u^{k+1} = ��_1 u^k + ��_2 u^{k-1}
                        % where ��_1 = ��_1/(��_1 + ��_2), ��_2 = ��_2/(��_1 + ��_2)
                        % ��_1 = |g(u^k) - g(0)|, ��_2 = |g(u^{k-1}) - g(0)|
                        U_pt_start=x_start_bj; U_pt_end=UU(end-1,:);
                        delta_start=abs(abs(gg(end))-abs(g_start0)); delta_end=abs(abs(gg(end-1))-abs(g_start0));
                        v_i=delta_start/(delta_start+delta_end)*U_pt_start + delta_end/(delta_start+delta_end)*U_pt_end;
                        U_k_new=v_i;
                        if_use_my_method=0;
                    end
                else
                    % ========== STEP 9: Compute u^{k+1} by Eq.(23) ==========
                    % Alternative method: weighted average of the previous two iteration points (formula (23) in Section 3.2 of the paper)
                    U_pt_start=x_start_bj; U_pt_end=UU(end-1,:);
                    delta_start=abs(abs(gg(end))-abs(g_start0)); delta_end=abs(abs(gg(end-1))-abs(g_start0));
                    v_i=delta_start/(delta_start+delta_end)*U_pt_start + delta_end/(delta_start+delta_end)*U_pt_end;
                    U_k_new=v_i;
                    if_use_my_method=0;
                end
                
                % Update reliability index and store results
                beta=norm(U_k_new); % Update reliability index
                v_i_array=[v_i_array; v_i]; U_k_new_array=[U_k_new_array; U_k_new];
                u_k_pre_1=[u_k_pre_1; UU(end,:)]; u_k_pre_2=[u_k_pre_2; UU(end-1,:)]; 
                nn_array=[nn_array; nn]; 
                
            else
                % Calculate alternative method (alternative scheme in the paper)
                ramba=abs(ab)/(abs(ab)+abs(ab_array(end-1,:)))*norm(UU(end,:)-UU(end-1,:));
                v_i=x_start_bj+ramba*(U_pt_end-U_pt_start)/norm(U_pt_end-U_pt_start);
                n_k=v_i/norm(v_i);
                beta=-(g_start-diff_g_u_bj*x_start_bj')/(diff_g_u_bj*n_k');
                U_k_new=beta*n_k;
            end
            array_beta=[array_beta; beta]; % Save the �� of this iteration
            
        else
            % ========== BRANCH 1: Directly use HLRF result (Case 1 satisfied) ==========
            % If k��2 or f(u^k) satisfies Case 1, set u^{k+1}=f(u^k)
            array_beta=[array_beta; beta]; 
        end
    else
        % For first two iterations (k��2), use HLRF directly
        array_beta=[array_beta; beta]; 
    end
    
    % Save unit direction vector
    n_k_array=[n_k_array; U_k_new/norm(U_k_new)]; % Save unit direction vector

    % ========== STEP 12: Convergence check ==========
    % Convergence check (stopping criterion in the paper: ||u^{k+1} - u^k|| / ||u^k|| �� ��)
    tol_real=norm(U_k_new - x_start_bj)/norm(U_k_new);
    aa.nn=nn;
    if nn-1>=1
        if norm(U_k_new - x_start_bj)/norm(U_k_new) < aa.jingdu
            break; % Convergence condition reached
        end
    end
    
    % Update iteration point for next iteration (k = k + 1)
    x_start_bj=U_k_new;
    x=x_start_bj.*tmp_bjc + tmp_u; % Transform back to X-space
    xx=[xx; x]; % Save X-space points
    nn=nn+1; % Increase iteration count (k=k+1)
end

% ========== FINAL CALCULATIONS ==========
% Calculate failure probability and final output
% Formula (2): p_f �� ��(-��) (Failure probability)
pf=normcdf(-beta); % Formula (2) in the paper
UU=[UU; U_k_new]; % Save final MPP
aa.gg=gg; aa.xx=xx; aa.UU=UU; % Save global results
n_vector=[]; % Collection of unit vectors (can be filled as needed)
end

% ========== SUB-FUNCTION: JC METHOD FOR MPP CALCULATION ==========
% Sub-function: Calculate MPP using the JC method (HLRF method in formula (5) of the paper)
% Formula (5): �� = [g(u^k) - ?g(u^k)^T u^k] / ||?g(u^k)||
function [ x, U_k_new, diff_g_u_bj, beta ] = JC_compute_mpp(X, x_start_bj, delta0, tmp_u, tmp_bjc, g_start, type)
    [diff_g_x_bj]=diff_chafen(x_start_bj, delta0, tmp_u, tmp_bjc, g_start, type); % Calculate gradient using finite difference
    diff_g_x=diff_g_x_bj./tmp_bjc; % Gradient transformation
    gs=diff_g_x.*tmp_bjc; 
    beta=(g_start - diff_g_x*(X-tmp_u)')/norm(gs); % Reliability index �� (formula (5) in the paper)
    beta2=(g_start - diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj); 
    u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj); % MPP point direction
    alpha=-gs./norm(gs); % Negative gradient direction
    x=tmp_u + beta*tmp_bjc.*alpha; % New design point
    U_k_new=(x-tmp_u)./tmp_bjc; % Transform to U-space
    diff_g_u_bj=diff_g_x_bj; % Output gradient
end

% ========== SUB-FUNCTION: SECANT METHOD FOR FAILURE SURFACE INTERSECTION ==========
% Sub-function: Secant method to find the intersection with the failure surface (Appendix A of the paper)
% Formula (22): t_{i+1} = t_i - g*(t_i)(t_i - t_{i-1}) / [g*(t_i) - g*(t_{i-1})]
function [U_k_new, g_U_k_new, g_num]=fun_find_g0_mpp3(u_satrt, g_satrt, u_end, g_end, tmp_u, tmp_bjc, type, if_plot, tol)
    global aa;
    g_num=0;
    v_i=u_end - u_satrt; vector=v_i/norm(v_i); % Search direction vector
    t_i0=norm(v_i); f_t_i0=g_end; % Initialize parameters
    t_i=0; f_t_i=g_satrt;
    iter_num=0;  
    
    % Secant method iteration (formula (22) in the paper)
    while 1
        t_i_new=t_i - f_t_i/(f_t_i - f_t_i0)*(t_i - t_i0); % Parameter update
        u_i_new=u_satrt + vector*t_i_new; % New point
        f_t_i_new=fun(u_i_new.*tmp_bjc + tmp_u, type); g_num=g_num+1; % Performance function calculation
        f_t_i0=f_t_i; t_i0=t_i; % Update old values
        t_i=t_i_new; f_t_i=f_t_i_new;
        if abs(f_t_i) < tol % Convergence condition
            break;
        end
    end
    u_i=u_satrt + vector*t_i; 
    U_k_new=u_i; g_U_k_new=f_t_i; % Output intersection point
end