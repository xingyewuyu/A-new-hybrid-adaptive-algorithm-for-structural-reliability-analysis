function [ x,beta,pf, UU,xx,gg,n_vector ,nn ,beta_record ,num_g] = bieren_adaptive_method( u,std,type, if_plot0 )
         
%��������An Adaptive First-Order Reliability Analysis Method for Nonlinear Problems�ķ���
global aa;

u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
 gg=[]; xx=u; beta_record=[]; g_record=[]; UU=[];   
%UU=zeros(1,num);
weishu=num;
theta_k=0;   tmp_bjc=bjc;  tmp_u=u;
nn=0;hui_para=0.4;%----�����������Ҫ��ԽСԽ�ã����ǵ�����������
ramba=0.8; delta=0.6;%3.57~4    delta---�����������Ҫ��Խ��Խ�ã����ǵ�����������
aa.inner_num_g=0;
while (1)%abs(norm(x)-last_normx)/norm(x)>1e-6
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    x_start=x;X=x_start;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;

            if  type==3 ||type==6 
                   if type==3
                       num_tmp=num-2;
                   elseif type==6
                       num_tmp=num;    
                   end   
                   X=x_start;
                   VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
                   t=1;
            elseif type==4     
                   X=x_start;
                   aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
                   F_x=1-evcdf(-X,-uu,1./aofa);  pdf_x=pdf('ev',-X,-uu,1./aofa);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u=X-inv_norm_F_x.*tmp_bjc;  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   t=1;
            elseif type==7||type==9%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
                   t=1;
            end 
        UU=[UU; x_start_bj];   
        if nn==0
            delta0=aa.delta;%delta0=1e-4;%delta0=aa.jingdu;%aa.jingdu
        else
            delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        end
        for i=1:weishu
            %delta0=1e-10;
            u_new=x_start_bj;
            u_new(i)=x_start_bj(i)+delta0;
            x_tmp=tmp_u+u_new.*tmp_bjc;
            g_new(i)= fun(x_tmp,type);%ƫ��ֵ
            diff_g_x_bj(i)=(g_new(i)-g_start)/delta0;
        end
        aa.inner_num_g=aa.inner_num_g+num;
                if isnan(diff_g_x_bj(1))
                    t=1;
                end
        
        A_k=x_start_bj-hui_para*diff_g_x_bj/norm(diff_g_x_bj);%17
        V_k=A_k/norm(A_k);%18
        if nn<1
            beta=-(diff_g_x_bj*x_start_bj'-g_start)/norm(diff_g_x_bj);%beta=-(diff_g_x_bj*x_start_bj'-g_start)/norm(diff_g_x_bj);
            U_k_new=-beta*diff_g_x_bj/norm(diff_g_x_bj);
             %U_k_new=(diff_g_x_bj*x_start_bj'-g_start)*diff_g_x_bj/norm(diff_g_x_bj)^2;
        else
             U_k_new=(diff_g_x_bj*x_start_bj'-(1-ramba)*g_start)*V_k/(diff_g_x_bj*V_k');%19
        end
        beta=norm(U_k_new);
   
    x=U_k_new.*tmp_bjc+tmp_u;
    %UU=[UU; U_k_new];
    g_record=[g_record;g_start];
    xx=[xx;x];
    beta_record=[beta_record; beta];
    beta_last=beta;
    
    nn=nn+1; 
    aa.nn=nn;
    if nn-1>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
        if nn-1>=1
            theta_k_last=theta_k;
            theta_k=acos(x_start_bj*U_k_new'/norm(x_start_bj)/norm(U_k_new));
            if  theta_k_last<delta*theta_k
                ramba=ramba*delta;               hui_para=hui_para*delta;  
            elseif  theta_k_last<theta_k
                ramba=ramba*theta_k_last/theta_k; hui_para=hui_para*theta_k_last/theta_k;  
            else
                ramba=max(ramba,0.2);           hui_para=max(hui_para,0.2);
            end
        end
    end

end
%nn=nn-1;
pf=normcdf(-beta);%55.5299
%gg=[gg; fun(xx(end,:),type)];
UU=[UU;U_k_new];  num_g=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU;
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;

t=1;
end

