% test_first.m - Test script for the paper "A new hybrid adaptive algorithm for structural reliability analysis"
% Declaration: This script is the companion code for the paper, used to validate the proposed Hybrid Adaptive Algorithm (HAMA).
% The main algorithm is implemented in JC_based_method_line_search_min_g_simplify.txt.
% 
% Usage Instructions:
% 1. Environment Requirements: MATLAB R2014b or higher, ANSYS 2022R1 (for finite element analysis).
% 2. Before running, modify the string2 variable in run_ansys.m according to the actual ANSYS installation path to point to ANSYS221.exe.
% 3. Select different test instances (corresponding to examples in the paper) by modifying the value of the variable 'type'.
% 
% Correspondence between 'type' values and paper examples:
%   type = 1: Corresponds to Case 1 of Example 1 in the paper (2D nonlinear function)
%   type = 2: Corresponds to Case 2 of Example 1 in the paper (Highly nonlinear function)
%   type = 3: Corresponds to Example 2 in the paper (6D non-normal variable problem)
%   type = 4: Corresponds to Example 3 in the paper (High-dimensional highly nonlinear problem)
%   type = 5: Corresponds to Example 4 in the paper (9D engineering case)
%   type = 6: Corresponds to Example 5 in the paper (8D nonlinear engineering case)
%   type = 7: Corresponds to Example 6 in the paper (72-bar truss problem)
%   type = 8: Corresponds to Example 7 in the paper (Four-story building vibration problem)
%   type = 9: Corresponds to Example 8 in the paper (Bending transducer problem)
%
% Execution Method: Execute this script directly in MATLAB, or call via the command line.
% Output includes reliability index ��, failure probability pf, and iteration process data.
%
% Author: [Fill in according to paper author information]
% Date: December 2025

clear;
clc;
global aa;
global path;

% Initialize path and global variables
file_mulu=which('test_first_EN.m');
file_index=findstr(file_mulu,'test_first_EN.m');
path=file_mulu(1:file_index-2);
cd(path);
addpath(genpath(path)); 
aa.nn=0; % Initialize iteration count

type=5; % Set test instance type (modify this value to switch examples)
aa=[];
aa.type=type; aa.nn=0; aa.g_num=0;
aa.jingdu=1e-3; % Set convergence tolerance
aa.g_diff_tongji=[]; aa.inner_num_g=0; aa.beta=[]; aa.gg=[]; aa.xx=[]; aa.UU=[]; aa.kkt=[]; aa.inner_num_g_iter=[];
aa.if_compare_with_real_tidu=1; % Enable real gradient comparison (for debugging)

[u, bjc, var]=input_canshu1(type); % Load input parameters (mean and standard deviation)
para_num=size(u,2);
fun_num=0;

tic; % Start timer
aa.if_compare_with_real_tidu=1; % Gradient comparison flag
if_plot0=1; % Enable plotting
if_JC=0;

% Test different algorithms based on the 'type' value
if type==1 || type==3 || type==5 || type==7 || type==9 
    if_JC=1;
    disp('Testing JC_method_ansys2 algorithm...');
    [x0, beta0, pf0, UU0, xx0, gg0, n_vector0, nn0, array_beta0, num_g_JC] = JC_method_ansys2(u, bjc, type, if_plot0);
    hold off;
end

if type==1 || type==3 || type==4 || type==5 || type==6 || type==7
    disp('Testing DSTM algorithm...');
    [x_DSTM, beta_DSTM, pf_DSTM, UU_DSTM, xx_DSTM, gg_DSTM, n_vector_DSTM, nn_DSTM, array_beta_DSTM, num_g_DSTM] = bieren_DSTM_method(u, bjc, type, if_plot0);
end

if type==1 || type==3 || type==4 || type==5 || type==6 || type==7
    disp('Testing AFRA algorithm...');
    [x_AFRA, beta_AFRA, pf_AFRA, UU_AFRA, xx_AFRA, gg_AFRA, n_vector_AFRA, nn_AFRA, array_beta_AFRA, num_g_AFRA] = bieren_adaptive_method(u, bjc, type, if_plot0);
end

if type==1 || type==3 || type==4 || type==5 || type==7 || type==8
    disp('Testing HRHLRF algorithm...');
    [x_HRHLRF, beta_HRHLRF, pf_HRHLRF, UU_HRHLRF, xx_HRHLRF, gg_HRHLRF, n_vector_HRHLRF, nn_HRHLRF, array_beta_HRHLRF, num_g_HRHLRF] = bieren_rHLRF_method(u, bjc, type, if_plot0);
end

if type==1 || type==2 || type==3 || type==4 || type==5 || type==7 || type==8 || type==9
    disp('Testing HLRF_BFGS algorithm...');
    [x_HLRF_BFGS, beta_HLRF_BFGS, pf_HLRF_BFGS, UU_HLRF_BFGS, xxHLRF_BFGS, gg_HLRF_BFGS, n_vector_HLRF_BFGS, nn_HLRF_BFGS, array_beta_HLRF_BFGS, num_g_HLRF_BFGS] = HLRF_BFGS_method(u, bjc, type, if_plot0);
end

% Test the hybrid adaptive algorithm (HAMA) proposed in the paper
hold off;
disp('Testing the hybrid adaptive algorithm (HAMA) proposed in the paper...');
[x_line_search, beta_line_search, pf_line_search, UU_line_search, xx_line_search, gg_line_search, n_vector_line_search, ...
    num_g_line_search, nn_line_search, array_beta_line_search, v_i_array_line_search, ...
    U_k_new_array_line_search, u_k_pre_1_line_search, u_k_pre_2_line_search, nn_array_line_search] = ...
    JC_based_method_line_search_min_g_simplify_en(u, bjc, type, if_plot0);

toc; % Output computation time