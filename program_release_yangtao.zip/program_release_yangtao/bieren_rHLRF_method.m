function [ x,beta,pf, UU,xx,gg ,n_vector,nn,array_beta,num_g  ] = bieren_rHLRF_method( u,std,type, if_plot0 )
%2019_Establishment of non-negative constraint method as a robust and efficient first-order reliability method
%length based on Armijo line sear
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  
tmp_bjc=bjc;  tmp_u=u; 

theta_tol=0.005;   aa.inner_num_g=0;
nn=0;
while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x); if_continue=1;
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==3 ||type==6 
                   if type==3
                       num_tmp=num-2;
                   elseif type==6
                       num_tmp=num;    
                   end   
                   X=x_start;
                   VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
                   t=1;
            elseif type==4     
                   X=x_start;
                   aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
                   F_x=1-evcdf(-X,-uu,1./aofa);  pdf_x=pdf('ev',-X,-uu,1./aofa);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u=X-inv_norm_F_x.*tmp_bjc;  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   t=1;
            elseif type==7||type==9%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
                   t=1;
            end 
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        %norm(UU(end-1,:)-x_start_bj)
    end

    [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
    diff_g_x=diff_g_x_bj./tmp_bjc;
    % HL-RF������ʽ
       gs=diff_g_x.*tmp_bjc;   
       beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);   
       beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
       UHL=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
       
    if nn>2
       d1=UHL-UU(end,:);d2=UU(end,:)-UU(end-1,:);d3=UU(end-1,:)-UU(end-2,:);
      theta_2=acos(d1*d2'/norm(d1)/norm(d2));
      theta_1=acos(d3*d2'/norm(d3)/norm(d2));
      
      if abs(theta_2-theta_1)<theta_tol
          U_k_new=UHL;if_continue=0;
      end
    end
    if if_continue==1
        % �����µ�ĺ���ֵ
        fUH = fun(UHL.*tmp_bjc+tmp_u,type);
        % ���㵱ǰ��ĺ���ֵ
        gU = g_start;
        % ����������������
        d = UHL - x_start_bj;d=d';
        % ������Լ���ɿ��Ժ���ֵ
        h1U = (x_start_bj * x_start_bj') / 2 - (diff_g_x_bj * x_start_bj') / (diff_g_x_bj * diff_g_x_bj') * gU;
        h1UH = (UHL * UHL') / 2 - (diff_g_x_bj * UHL') / (diff_g_x_bj * diff_g_x_bj') * fUH;
        % �����������
        alpha = d' * d / (2 * (h1UH - h1U + d' * d));
        % ���Ʒ���������0��1֮��
        alpha = max(0, min(1, alpha));
        % ����U
        U_k_new = (1 - alpha) * x_start_bj + alpha * UHL;
    
    end
    
    x=tmp_u+U_k_new.*tmp_bjc;    
    beta=norm(U_k_new); array_beta=[array_beta;beta];
     plot(U_k_new(1),U_k_new(2),'+'); 

 
   if nn>=1
      theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
      theta(nn,:)=acos(theta(nn,:))/pi*180;
   end

   nn=nn+1;
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
   % t1 = toc  % ���㾭����ʱ��
    if nn-1>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
    end
end
%nn=nn-1;
pf=normcdf(-beta);%55.5299
%gg=[gg; fun(xx(end,:),type)];  
UU=[UU; U_k_new];  num_g=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU; aa.kkt=kkt;  aa.theta=theta; 
aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
t=1;
end


