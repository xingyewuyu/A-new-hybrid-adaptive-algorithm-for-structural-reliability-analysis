function [stressmax,dispmax]=exs4a(area,E,theta,P)
global fun_val;
A=area;
% theta=pi/6
%P----�غ�0.5e6 0.5MN
% example exs4a 
%----------------------------------------------------------------
% PURPOSE 
%    Analysis of a plane truss using loops.
%----------------------------------------------------------------

% REFERENCES
%     P-E Austrell 1994-03-08 
%     K-G Olsson 1995-09-28
%     O Dahlblom 2004-08-31
%----------------------------------------------------------------
clc;%clear;
%echo on 

%----- Topology matrix Edof -------------------------------------

 Edof=[1   1  2  5  6;
       2   3  4  7  8;
       3   5  6  9 10;
       4   7  8 11 12;
       5   7  8  5  6;
       6  11 12  9 10;
       7   3  4  5  6;
       8   7  8  9 10;
       9   1  2  7  8;
      10   5  6 11 12];
 
%----- Stiffness matrix K and load vector f ---------------------

 K=zeros(12); 
 f=zeros(12,1);  f(11)=P*sin(theta);  f(12)=-P*cos(theta);
 %f

%----- Element properties ---------------------------------------

% A=25.0e-4;	  E=2.1e11;   ep=[E A];	
ep=[E A];	
%----- Element coordinates --------------------------------------

 ex=[0 2;
     0 2;
     2 4;
     2 4;
     2 2;
     4 4;
     0 2;
     2 4;
     0 2;
     2 4];
 
 ey=[2 2;
     0 0;
     2 2;
     0 0;
     0 2;
     0 2;
     0 2;
     0 2;
     2 0;
     2 0];
 
%----- Create element stiffness matrices Ke and assemble into K -

 for i=1:10
    Ke=bar2e(ex(i,:),ey(i,:),ep);
    K=assem(Edof(i,:),K,Ke);
 end;
 
%----- Solve the system of equations ----------------------------

 bc= [1 0;2 0;3 0;4 0];   
 [a,r]=solveq(K,f,bc);

%----- Element forces -------------------------------------------

 ed=extract(Edof,a);

 for i=1:10
    N(i,:)=bar2s(ex(i,:),ey(i,:),ep,ed(i,:));
 end
 %N
dispmax=abs(a(12));%�غ����õ���y��������λ��
stressmax=N(1)/A/(1000*1000);%��λΪMPA  ���и˼������Ӧ��
fun_val.con1=stressmax;
fun_val.con2=dispmax;
%---------------------------- end -------------------------------
% echo off
