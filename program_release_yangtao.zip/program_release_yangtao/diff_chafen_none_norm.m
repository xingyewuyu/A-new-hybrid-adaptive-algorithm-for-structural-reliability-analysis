function   [g_diff]=diff_chafen_none_norm(u_k,u_delta,u,bjc,g_output,type)
%global num_con_fun1 fun_val
global aa;
num=max(size(u_k)); g_diff=zeros(1,num); 
VV=bjc./u;
% g_output=feval('fun',x_k);  aa.inner_num_g=aa.inner_num_g+1;
%if  if_compute_tidu==1   
        %g_new=g_diff;
        for i=1:num
            u_new=u_k;
            u_new(i)=u_k(i)+u_delta;
            x_tmp = y_to_X(u_new', u', bjc',type)';
            g_new= fun(x_tmp,type);%ƫ��ֵ
            g_diff(i)=(g_new-g_output)/u_delta;
        end
        aa.inner_num_g=aa.inner_num_g+num;
        %g_diff =g_diff';
%end
        
        
     
t=1;