function [ x,beta,pf, UU,xx,gg ,n_vector,nn,array_beta ,num_g ] = HLRF_BFGS_method( u,std,type, if_plot0 )
%HLRF�CBFGS optimization algorithm for structural reliability   
global aa;
u1=u;std1=std;bjc=std;
x_ori=u;last_normx=1e9;
num=size(x_ori,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  

weishu=num;  tmp_bjc=bjc;  tmp_u=u;
B_inv=eye(weishu,weishu);

nn=0;aa.inner_num_g=0; 
while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x_ori);
%----------------------����ݶ�---------------------    
    X=x_ori;x_start=X;%xΪ��׼�ռ�ı���  ;X Ϊԭʼ�ռ�ı���
    if nn==0
       g_start=fun(x_start,type);  aa.inner_num_g=aa.inner_num_g+1;
    else
       g_start=g_start_new;
    end
    gg=[gg; g_start];   
    x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==3 ||type==6 
                   if type==3
                       num_tmp=num-2;
                   elseif type==6
                       num_tmp=num;    
                   end   
                   X=x_start;
                   VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
                   t=1;
            elseif type==4     
                   X=x_start;
                   aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
                   F_x=1-evcdf(-X,-uu,1./aofa);  pdf_x=pdf('ev',-X,-uu,1./aofa);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u=X-inv_norm_F_x.*tmp_bjc;  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   t=1;
            elseif type==7||type==9%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
                   t=1;
            end   
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        %norm(UU(end-1,:)-x_start_bj)
    end
    %delta0
    
    %delta0
    if nn==0
           [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
    else
           diff_g_x_bj=diff_g_x_bj_new;
    end
    %diff_g_x_bj  
                if isnan(diff_g_x_bj(1))
                    t=1;
                end
   
    d_k=(diff_g_x_bj*B_inv*x_start_bj'-g_start)*B_inv*diff_g_x_bj'/( diff_g_x_bj*B_inv*diff_g_x_bj')-B_inv*x_start_bj';
    %
    %u_k_new=(diff_g_x_bj*x_start_bj'-g_start)*diff_g_x_bj/norm(diff_g_x_bj)^2;
    u_k_new=x_start_bj  +  d_k';
    hui_k= (g_start-diff_g_x_bj*B_inv*x_start_bj')/( diff_g_x_bj*B_inv*diff_g_x_bj');     
        
    ramba_k_plus_1=hui_k;  
    
    p_k=u_k_new-x_start_bj;
    
    
    if type==3||type==7%  4---ƣ��ʵ��   401--72�˼�
        g_start_new=fun(y_to_X(u_k_new', u', bjc',type)',type); aa.inner_num_g=aa.inner_num_g+1;
        diff_g_x_bj_new=diff_chafen_none_norm(u_k_new,delta0,u,bjc,g_start_new,type);
    else
        g_start_new=fun(u_k_new.*tmp_bjc+tmp_u,type); aa.inner_num_g=aa.inner_num_g+1;
        diff_g_x_bj_new=diff_chafen(u_k_new,delta0,tmp_u,tmp_bjc,g_start_new,type);
    end
    grad_L_new = u_k_new + ramba_k_plus_1 * diff_g_x_bj_new;
    grad_L_old = x_start_bj + ramba_k_plus_1 * diff_g_x_bj;
    q_k=grad_L_new-   grad_L_old;
    
    %diff_g_x=diff_g_x_bj./tmp_bjc; 
    
    B_inv_new=B_inv+(1+q_k*B_inv*q_k'/(p_k*q_k')  )*p_k'*p_k/(p_k*q_k')-   ( p_k'*q_k*B_inv+ B_inv*q_k'*p_k)/(p_k*q_k');

%     q=q_k';p=p_k';
%                 term1 = (q' * B_inv * q) / (p' * q);
%             term2 = (B_inv * q * p' + p * q' * B_inv) / (p' * q);
%             B_inv = B_inv + (1 + term1) * (p * p') / (p' * q) - term2;
%             
     B_inv=B_inv_new;
    beta=norm(u_k_new);array_beta=[array_beta;beta];
    x_ori=u_k_new.*tmp_bjc+tmp_u;%xΪ��׼�ռ�ı���  ;X Ϊԭʼ�ռ�ı���
   nn=nn+1;
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta

   if nn>=1
      theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
      theta(nn,:)=acos(theta(nn,:))/pi*180;
   end
   [nn  beta]
   if nn==10
      t=1; 
   end
    %t1 = toc  % ���㾭����ʱ��
    if nn-1>=1
        if norm(u_k_new-x_start_bj)/norm(u_k_new)<aa.jingdu
          break;
        end
    end
end
%nn=nn-1;  
x=x_ori;
pf=normcdf(-beta);%55.5299
%gg=[gg; fun(x,type)];  
UU=[UU; u_k_new];  num_g=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU; aa.kkt=kkt;  aa.theta=theta; 
aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
 
 plot(UU(:,1),UU(:,2),'-bo');
 plot(UU(:,1),UU(:,2),'-g');
t=1;
end

