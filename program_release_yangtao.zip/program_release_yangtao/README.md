# A-new-hybrid-adaptive-algorithm-for-structural-reliability-analysis
  
Prior to executing the code, MATLAB R2014b and ANSYS 2022R1 must be installed to ensure proper operation.
Additionally, based on the actual installation location of ANSYS, the value of string2 in run_ansys.m needs to be modified to point to the actual location of ANSYS221.exe.

Please run the test file named "test_first_EN.m".
The variable type in the code represents different test instances. Modifying its value allows testing different cases, where:

type = 1 corresponds to Case 1? in Example 1 of the paper.

type = 2 corresponds to Case 2? in Example 1 of the paper.

type = 3 corresponds to Example 2 of the paper.

type = 4 corresponds to Example 3 of the paper.

type = 5 corresponds to Example 4 of the paper.

type = 6 corresponds to Example 5 of the paper.

type = 7 corresponds to Example 6 of the paper.

type = 8 corresponds to Example 7 of the paper.

type = 9 corresponds to Example 8 of the paper.







