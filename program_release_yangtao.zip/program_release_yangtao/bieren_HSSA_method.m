function [ x,beta,pf, UU,xx,gg ,n_vector,nn ] = bieren_HSSA_method( u,std,type )
%A novel self-adaptive step size first-order method for structural reliability
%analysis based on modified Sigmoid function and Armij
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  

weishu=num;  tmp_bjc=bjc;  tmp_u=u; 
ramba_0=1; a=1; B=2; b=0.5; c=3; A=1.5; theta_min=30/180*pi; ramba_min=0.1; theta_0=180/180*pi; rou=0.5;
nn=0;
while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==4 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==35
                    num_tmp=2;    
                 end   
                X(1:num_tmp)=u(1:num_tmp)+bjc(1:num_tmp).*x_start_bj(1:num_tmp);
%                 u=X.*(6.517-log(X));
%                 bjc=aa.bjc./aa.u.*X;
                %aa.u=250;aa.bjc=25; X=210;
                logn_para_u=log(u(1:num_tmp).^2./(bjc(1:num_tmp).^2+u(1:num_tmp).^2).^0.5);
                logn_para_sigma=(log(  bjc(1:num_tmp).^2./u(1:num_tmp).^2+1)  ).^0.5;
                F_x=cdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                inv_norm_F_x=icdf('normal',F_x,0,1);
                tmp_bjc(1:num_tmp)=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                tmp_u(1:num_tmp)=X(1:num_tmp)-inv_norm_F_x.*tmp_bjc(1:num_tmp);
                x_start_bj(1:num_tmp)= ( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
%                    mu=100;sigma=12;
%                    aEv=sqrt(6)*sigma/pi;  uEv=-psi(1)*aEv-mu;
%                    FQ=1-evcdf(-150,uEv,aEv);%
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==430  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   aEv=sqrt(6)*bjc((5:7))/pi; uEv=-psi(1)*aEv-u((5:7));
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X((5:7)),uEv,aEv);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc((5:7))=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u((5:7))=X((5:7))-inv_norm_F_x.*tmp_bjc((5:7));  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   %x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            end         
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        norm(UU(end-1,:)-x_start_bj)
    end
    delta0
    
    %delta0
    [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
    %diff_g_x_bj
                if isnan(diff_g_x_bj(1))
                    t=1;
                end
    diff_g_x=diff_g_x_bj./tmp_bjc;
    gs=diff_g_x.*tmp_bjc;
%     tidu_bj=tidu.*bjc;
       beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  array_beta=[array_beta;beta];
       beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
       u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
       alpha=-gs./norm(gs);%----------------���ݶȷ���
     x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;
     if nn>0
        %while(1)
             n_k=(UU(end,:)-UU(end-1,:))/norm(UU(end,:)-UU(end-1,:));
             p_k=(U_k_new-UU(end,:))/norm(U_k_new-UU(end,:));
             hui_k=n_k*p_k';
             %theta_k=theta_0;
             theta_k=acos(hui_k);%/pi*180;
             if (theta_k<theta_min)
                 ramba_k=ramba_k*A*(1-exp(-B*abs(2*(1-theta_k/pi))))/ ( a+b*exp(-2*abs(1-theta_k/pi)     )       );
                 if ramba_k<ramba_min
                       ramba_k=ramba_min;
                 end
             else% (theta_k>theta_min)
                    ramba_k=ramba_0;
                    while(1)
                                if(ramba_k>ramba_min)
                                    c_k=2*norm(x_start_bj)/norm(diff_g_x_bj);
                                    g_k=x_start_bj+c_k*sign(g_start)*diff_g_x_bj;
                                    d_k=U_k_new-x_start_bj;
                                    F_u_k= 0.5*x_start_bj*x_start_bj'+c_k*abs(g_start);

                                    g_U_k_new=fun(U_k_new,type); aa.inner_num_g=aa.inner_num_g+1;
                                    F_u_k_plus_1=0.5*U_k_new*U_k_new'+c_k*abs(g_U_k_new);
                                    if(F_u_k_plus_1-rou*ramba_k*g_k*d_k'-F_u_k<=0)
                                        break; 
                                    else
                                        ramba_k=ramba_k*0.5;
                                    end
                                else%ramba_k<ramba_min
                                    ramba_k=ramba_min;
                                    break;
                                end
                               % F(u_k)<=F(u)+rou*ramba_k*g_k*d_k;
                                
                     end%while
             end
        %end
     else
         ramba_k=ramba_0;
     end

     U_k_new=x_start_bj+ramba_k*(U_k_new-x_start_bj);
    
    %UU=[UU; U_k_new];
    diff=[ diff;  diff_g_x_bj]; 
    if size(diff,1)>=2
        error_diff=[error_diff; diff(end,:)-diff(end-1,:)];
        error=[error;  norm(error_diff(end,:))];
    end
    xx=[xx;X];

    %nn
    kkt=[kkt ;U_k_new/norm(U_k_new)+diff_g_x_bj/norm(diff_g_x_bj)];
    
       %theta(nn,:)=acos(U_k_new*diff_g_x_bj'/norm(U_k_new)/norm(diff_g_x_bj))/pi*180;
   if nn>=1
      theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
      theta(nn,:)=acos(theta(nn,:))/pi*180;
   end
    if nn>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
    end
   nn=nn+1;
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;beta
    t1 = toc  % ���㾭����ʱ��
end
nn=nn+1;
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)];  UU=[UU; U_k_new];  g_num=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU; aa.kkt=kkt;  aa.theta=theta; 
aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
t=1;
end


%        diff_g_x=diff_g_x_bj./std;
%     %����Ƕȣ��ɿ���ֵ���µ������
%     gs=diff_g_x_bj;
%     alpha=-gs/norm(gs);%----------------���ݶȷ���
%     beta=(g_start+diff_g_x*(u-x)')/norm(gs);
%     x=u+beta*std.*alpha;   
%     UU=[UU; (x-u)./std];
