function Y_new=fun(x,type)
global fun_num
global path
global aa;global fun_val;
yiban=size(x,2)/2;
    aa.g_num=aa.g_num+1;
    fun_num=fun_num+1;
    if type==1%ʵ��0 
     Q=x(:,1); L=x(:,2); E=x(:,3); I=x(:,4);
     Y_new=Q.*L.^4./(8*E.*I)-4;
    elseif type==88%ʵ��1 
         Q=x(:,1); L=x(:,2); E=x(:,3); I=x(:,4);
         Y_new=Q.*L.^4./(8*E.*I)-4;
    elseif type==2%ʵ��2Multiple Linearization Method for Nonlinear Reliability Analysis
              x1=x(:,1);x2=x(:,2);
              Y_new=2-0.1*x1.^2+0.06*x1.^3-x2;
    elseif type==3%ʵ��3
            Q=x(:,1); L=x(:,2); E=x(:,3); I=x(:,4);obj=Q.*L.^4./(8*E.*I)-4;
            Y_new=(Q-2).^2+(L-1).^2+(E+3).^2+(I-0.5).^2+0.001;%�ɿ���̫��
            %Y_new=(Q-2).^2+(L-1).^2+(E+3).^2+(I-0.5).^2+2;
    elseif type==4||type==400 %Hybrid High Dimensional Model Representation for  Example 2
        Nc=x(:,1);Nf=x(:,2);nc=x(:,3);nf=x(:,4);theta1=x(:,5);theta2=x(:,6);%S=x(1);D=x(2);F=x(3);L=x(4);T=x(5);
        Dc=nc./Nc;Df=nf./Nf;
        Y_new=2-exp(theta1.*Dc)+(exp(theta1)-2)./(exp(-theta2)-1)...
            .*(exp(-theta2.*Dc)-1)-Df;
    elseif type==5
      M1=x(:,1); M2=x(:,2); F=x(:,3); Y=x(:,4);   b=0.3; h=0.6;
      Y_new=1-4*M1./(b.*h.^2.*Y)-4*M2./(b.^2.*h.*Y)-F.^2./(b.*h.*Y).^2;  
    elseif type==6%Subset simulation for structural reliability sensitivity analysis
       q=x(:,1);L=x(:,2);As=x(:,3);Ac=x(:,4);Es=x(:,5);Ec=x(:,6);
       Y_new=0.03-q.*L.^2/2.*(3.81./(Ac.*Ec)+1.13./(As.*Es));
       Y_new=0.03/(q.*L.^2/2.*(3.81./(Ac.*Ec)+1.13./(As.*Es)))-1;
    elseif type==7%Reliability sensitivity analysis with random and interval variables  Example 1 adhesive bonding example
      Eo=x(:,1);Ei=x(:,2);to=x(:,3);ti=x(:,4);
      G=x(5);b=x(6);L=x(7);P=x(8);Sa=x(9);
      h=0.02;delta_T=130;aofa_i=13e-6;aofa_o=6e-6;
        w=(G./h.*(1./Eo./to+2./Ei./ti)).^0.5;
        y1=P.*w/(4*b.*sinh(w.*L/2));
        y2=P.*w/(4*b.*cosh(w.*L/2)).*(2*Eo.*to-Ei.*ti)./(2*Eo.*to+Ei.*ti);
        y3=(aofa_i-aofa_o).*delta_T.*w/((1./Eo./to+2./Ei./ti).*cosh(w.*L/2));  xx=0.5;
        yingli_max=y1.*cosh(w.*xx)+(y2+y3).*sinh(w.*xx);
        Y_new=Sa-yingli_max;    
    elseif type==8
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);
       Y_new=exp(0.4*x1+7)-exp(0.3*x2+5)-200;
       %Y_new=(exp(0.4*x1+7))^4-(exp(0.3*x2+5))^4-200;
       t=1;
      elseif type==9%�ṹ�ɿ�ָ������һ���µĵ�������   һ�ֽṹ�ɿ���ָ�����������
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);P=100;
       Y_new=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2))); 
       elseif type==10%�����ʽ���ܺ����ɿ��ȵ�һ���·���   g=18.46154-74769.23*x1/x2^3 
        x1=x(:,1:yiban);x2=x(:,yiban+1:end);
       Y_new=18.46154-74769.23*x1./x2.^3 ;
    elseif type==121%ʧЧ���ʼ���Ľض���Ҫ������
        F=x(:,1);M1=x(:,2);M0=x(:,3);  
         Y_new=1-2e-5*F-(2e-4*M1).^1.2-(2e-5*M0).^2.1;
    elseif type==14%�ṹ�ɿ�ָ���ͨ�ü��㷽��g(x)=x1^3+x2^3-4      
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);  
       Y_new=x1.^3+x2.^3-4;
    elseif type==141%% g(x)=x1^3+x2^3-67.5   %HLRF�CBFGS optimization algorithm for structural reliability     
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);  
       Y_new=x1.^3+x2.^3-67.5;
      elseif type==15%�����̬�ռ��иĽ������޲���������  ����ṹ�ɿ���ָ������������㷨 �� 2
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);u=0.2;
       Y_new=exp(u*(1+x1-x2))+exp(u*(5-5*x1-x2))-1;     
    elseif type==16%����ṹ�ɿ���ָ������������㷨   �� 1
        x1=x(:,1);x2=x(:,2);x3=x(:,3);
        Y_new=x3-(x1-1)^2-1.5*(x2-2)^2;    Y_new=-Y_new;
    elseif type==17%  �ṹ�ɿ���ָ��������ת�ݶ��㷨  HF ������   
                                      %An Adaptive First-Order Reliability Analysis Method for Nonlinear Problems Example 1
       %A robust approximation method for nonlinear cases of structural reliability analysis Example 1
       %A new directional stability transformation method of chaos control for first order reliability analysis  --Example 1  
       x1=x(:,1:yiban);x2=x(:,yiban+1:end);  
       Y_new=x1.^3+x2.^3+x1.^2.*x2-18;
       %Y_new=x1.^3+x2.^3-18;%2015-HLRF�CBFGS optimization algorithm for structural reliability Problem 7
    elseif type==18%ʧЧ���ʼ���Ľض���Ҫ������ �ض���̬�ֲ������ʧЧ���ʼ���Ľض���Ҫ������
        w=x(:,1);E=x(:,2);I=x(:,3);   L=5;
       Y_new=L/360-0.0069*w.*L.^4./(E.*I);
    elseif type==19%ansys   -----------����------------------- 
        L=x(:,1:yiban);w=x(:,yiban+1:end);
        dv=[L w];
fid=fopen(strcat(path,'test_ansys\1\dv.txt'),'w+'); 
fprintf(fid,'%6.5f,',dv);%,\n
status=fclose(fid);
        [ data ] = run_ansys( path );
        qiangdu=355;
         Y_new=qiangdu-data;
    elseif type==20%ansys   ------------���ּ�------------------ 
        %L=x(:,1:yiban);w=x(:,yiban+1:end);
        dv=x;
fid=fopen(strcat(path,'test_ansys\1\dv.txt'),'w+'); 
fprintf(fid,'%6.5f,',dv);%,\n
status=fclose(fid);
        [ data ] = run_ansys( path );
        qiangdu=0.03;
         Y_new=qiangdu-abs(data);         
     elseif type==31 %An Adaptive First-Order Reliability Analysis Method for Nonlinear Problems Example 2
        x1=x(:,1:yiban);x2=x(:,yiban+1:end);  %A robust approximation method for nonlinear cases of structural reliability analysis Example 2
        %x1=x(:,1);x2=x(:,2);
       Y_new=x1.^4+2*x2.^4-20;   % Y_new=-Y_new;
     elseif type==32%                  An Adaptive First-Order Reliability Analysis Method for Nonlinear Problems Example 4
        x1=x(:,1);x2=x(:,2);  %lognormal Gumbel
        Y_new=x1.^4+x2.^2-50; 
     elseif type==325%                  %An Adaptive First-Order Reliability Analysis Method for Nonlinear Problems Example 5 
        x1=x(:,1);x2=x(:,2);x3=x(:,3);x4=x(:,4);  %lognormal Gumbel
        x5=x(:,5);x6=x(:,6);x7=x(:,7);x8=x(:,8);
        kp=x1; ks=x2; mp=x3; ms=x4;  hui_p=x5; hui_s=x6; Fs=x7; S0=x8; 
        wp=(kp/mp)^0.5; ws=(ks/ms)^0.5; hui_a=(hui_p+hui_s)*0.5; wa=(wp+ws)*0.5; ita=(wp-ws)/wa; v=ms/mp;
        
        p1=pi*S0/4/hui_s/ws^3;
        p2=(4*hui_a^2+ita^2)*hui_p*hui_s+v*hui_a^2;
        p3= hui_s*hui_a/p2;
        p4=(hui_p*wp^3+hui_s*ws^3)*wp;
        p5=p4/4/(hui_a*wa^4);
        Ex2=p1*p3*p5;
%         Ex2=pi*S0/4/hui_s/ws^3*  hui_s*hui_a/(hui_p*hui_s*(4*hui_a^2+ita^2)+v*hui_a^2)...   
%                    * (hui_p*wp^3+hui_s*ws^3)*wp/4/(hui_a*wa^4);
        P=3;
        Y_new=Fs-ks*P*Ex2^0.5; 
     elseif type==33%                  %New effcient and robust method for structural reliability analysis and Example 1
        x1=x(:,1);x2=x(:,2); 
       Y_new=x1-1.7*x2+1.5*(x1+1.7*x2).^2+5;   
     elseif type==34%                  %New effcient and robust method for structural reliability analysis and Example 2 
        x1=x(:,1);x2=x(:,2); 
       Y_new=log(exp(1+x1+x2))+exp(5-5*x1-x2);%  Example 2
     elseif type==35% xxxxxxxxxxxxxxxxxxxxxxxxxxx %New effcient and robust method for structural reliability analysis and Example 3 
        x1=x(:,1);x2=x(:,2); 
       Y_new=x1.^4+x2.^2-50;%  Example 3      
     elseif type==36%                  %New effcient and robust method for structural reliability analysis and Example 4 
        x1=x(:,1);x2=x(:,2); x3=x(:,3);
       Y_new=x3+(x1-1.1).^2/1.5/1.5-(x2-0.2).^2/9+3.6;
     elseif type==37%                 �����ֲ�
        
        x1=x(:,1);x2=x(:,2); x3=x(:,3);x4=x(:,4);x5=x(:,5); x6=x(:,6);x7=x(:,7);x8=x(:,8); x9=x(:,9);x10=x(:,10);
       Y_new=2+0.015*(x1.^2+x2.^2+x3.^2+x4.^2+x5.^2+x6.^2+x7.^2+x8.^2+x9.^2)-x10;
       Y_new=2+0.015*(sum(x(1:9).^2))^3-x10;
     elseif type==371%      ��̬�ֲ�             %New effcient and robust method for structural reliability analysis and Example 5 
        %A robust approximation method for nonlinear cases of structural reliability analysis Example 4
        
        x1=x(:,1);x2=x(:,2); x3=x(:,3);x4=x(:,4);x5=x(:,5); x6=x(:,6);x7=x(:,7);x8=x(:,8); x9=x(:,9);x10=x(:,10);
       Y_new=2+0.015*(x1.^2+x2.^2+x3.^2+x4.^2+x5.^2+x6.^2+x7.^2+x8.^2+x9.^2)-x10;
       Y_new=2+0.015*(sum(x(1:9).^2))^3-x10;
       num=size(x,2);
       Y_new=2; tmp=0;
       for i=1:num-1
           tmp=tmp+x(i)^2;
       end
       Y_new=Y_new+tmp^3*0.015-x(num);
       
     elseif type==38%                 %A robust approximation method for nonlinear cases of structural reliability analysis Example 6
       x1=x(:,1);x2=x(:,2); x3=x(:,3);
       w=x1;E=x2;h=x3;
       Y_new=7/360-360*w/E/h^4;
     elseif type==39%        #С����://�����Ŀ�/wAGFYi7avH83ysx       �˼ҵļ�������3.632
       x1=x(:,1);x2=x(:,2); x3=x(:,3);%SG(��̫�ֲ�)   SQ(��ֵI�ͷֲ�)  R(������̫�ֲ�) 
       SG=x1;SQ=x2; R=x3;
       Y_new=R-SG-SQ; %  ��λKN
       
     elseif type==40  %--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2-----------72��-------------------Trusssizeopt_hengjia_compu.m
       H=x(1);  B=x(2);  t=x(3);  E=x(4); density=x(5); P=x(6);   
       b=B-2*t;    h=H-2*t;
       area=(H*B-h*b)/1e6;
       [W,dispmax,stressmax,frequency]=Trusssizeopt_hengjia_compu(area,E,density,P);
       Y_new=450-stressmax;%Ӧ��173.2     u=  [20 20 5  2.1e11 7860   100000];%��Ʊ���H B  t  E density P(zaihe)
       %Y_new=0.002-dispmax;%Ӧ��173.2      u=  [15 15 5  2.1e11 7860   100000];%��Ʊ���H B  t  E density P(zaihe) 
       %Y_new=165-frequency;%bjc=[0.05*u(1)/3  0.05*u(2)/3  0.05*u(3)/3 0.05*u(4)   0.02*u(5)   0.1*u(6) ]; var=bjc.^2;jingdu=1e-4; %  ��λKN
      elseif type==401%----Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ�� 72gan  example8.2   ���ָ� 
             H=x(1);  B=x(2);  t=x(3);  a_a=x(4); a_b=x(5); a_c=x(6); E=x(7); density=x(8);  P1=x(9); P2=x(10); P3=x(11); 
             b=B-2*t;    h=H-2*t;
            area=(H*B-h*b)/1e6;
                     %[W,dispmax,stressmax,frequency]=Trusssizeopt_hengjia_compu(area,E,density,P);
                     [W,dispmax,stressmax,frequency]=Trusssizeopt_hengjia_compu_abc(area,E,density,P1,P2,P3,a_a,a_b,a_c);
        %     end
            dispmax=dispmax*1000;%��λm
            Y_new=250-stressmax;%Ӧ��173.2
            Y_new=0.5-dispmax;%Ӧ��173.2
            Y_new=160-frequency;%Ӧ��173.2---ok
            Y_new=150-frequency;%Ӧ��173.2---ok
            t=1;
            
    elseif type==41 %--example exs4a  calfem_3.4  ������  exs4a.m P237
            H=x(1); B=x(2); t=x(3); theta=x(4);  P=x(5); E=x(6);%E=2.1e11;
            b=B-2*t;    h=H-2*t; area=(H*B-h*b)/1e6;
            [stressmax,dispmax]=exs4a(area,E,theta,P);
            Y_new=130-stressmax;%Ӧ��173.2  %y>0Ϊ��ȫ����0Ϊ����ȫ  bjc=[0.05*u(1)/3  0.05*u(2)/3  0.05*u(3)/3 0.1*u(4)   0.02*u(5)  0.2*u(6)];  
            Y_new=0.01-dispmax;%Ӧ��173.2  %y>0Ϊ��ȫ����0Ϊ����ȫ  bjc=[0.05*u(1)/3  0.05*u(2)/3  0.05*u(3)/3 0.1*u(4)   0.02*u(5)  0.2*u(6)];  
     elseif type==42%   Dam  -----------���--ANSYS��ľ����Ӧ��ʵ��(�ڶ���)��������\��ʮ��--------------- 
                    dv=x;
                    fid=fopen(strcat(path,'\test_ansys\shuiba\dv.txt'),'w+'); 
                    fprintf(fid,'%16.10f,',dv);%,\n
                    status=fclose(fid);
                    [ data ] = run_ansys( path);
                 %   qiangdu=80;
                     y=1.1-1.96e6/abs(data(2)); %      ��Ӧ��  ��ȫϵ��С1.1�򲻰�ȫ
                     y=1.5-x(6)/abs(data(2)); %      ��Ӧ��  ��ȫϵ��С1.1�򲻰�ȫ
                     y=1.3-x(6)/abs(data(2));
                     
%                      yingli_lashen=data(2)/1e6;%��λMPA
%                      ac=0.3; %��������
%                      a0=0.005;% ��ʼ����
                     C=1e-8;%���ϳ���
%                      Y=1.12;%��������ϵ����������ѷ�ȡ1.12���ڲ��ѷ�ȡ1.0
%                      delta_K=Y*yingli_lashen*(pi*0.005)^0.5;%Ӧ��ǿ�����ӷ�ֵ��MPa����m��
%                      m=3;%���ϳ���
%                      shouming=(ac-a0)/(C*delta_K^m);%��λ��
%                      shouming_year=shouming/(365*24*3600);
                     
                     Y_new=-y;
                     
     elseif type==43%Reliability sensitivity analysis with random and interval variables   Example 2��cantilever tube
         u=   [5    42    120    60    3    3    12  90   220  30   30];  % t d L1 L2 F1 F2 P T Sy theta1 theta2  
         t=x(1);   d=x(2); L1=x(3); L2=x(4);
         F1=x(5)*1000; F2=x(6)*1000;  P=x(7)*1000; T=x(8)*1000;
         Sy=x(9); theta1=30/180*pi;theta2=30/180*pi;    theta1=x(10)/180*pi;theta2=x(11)/180*pi;
         M=F1*L1*cos(theta1)+F2*L2*cos(theta2);
         A=pi/4*(d^2-(d-2*t)^2);  c=d/2;  I=pi/64*(d^4-(d-2*t)^4); J=2*I;
         yingli_lashen=(P+F1*sin(theta1)+F2*sin(theta2))/A+M*c/I;
         ying_jianqie=T*d/2/J;
         yingli_max=(yingli_lashen^2+3*ying_jianqie^2)^0.5;
         Y_new=Sy-yingli_max;                     
      elseif type==44%ansys   -----------Axisymmetric model of a piezoresistive pressure sensor----------------- 
        %L=x(:,1:yiban);w=x(:,yiban+1:end);
%         dv=XX(1:4);
        dv=x;   %zzzzzzzzzzzzzzz  delta0=1e-3��������
        strs=strcat(path,'test_ansys\piezoresistive\dv.txt');
        fid=fopen(strcat(path,'\test_ansys\piezoresistive\dv.txt'),'w+');
        fprintf(fid,'%16.10f,',dv);%,\n
        status=fclose(fid);
        [ data ] = run_ansys( path );
        weiyi=0.035;%��λΪmm
        weiyi=0.028;%��λΪmm
        weiyi=0.03;%��λΪmm
         Y_new=weiyi-abs(data(2))*1e3;  
        % Y_new=250-abs(data(1))*1e-6;  
         t=1;
     elseif type==45%--zzzA Modified Efficient Global Optimization Algorithm for Maximal ��Ҫ--���ʵ�� ANSYS7.0����ʵ���빤��Ӧ�� ��֧��
        %L=x(:,1:yiban);w=x(:,yiban+1:end);
%         dv=XX(1:4);
        dv=[aa.u_d x];
        fid=fopen(strcat(path,'\test_ansys\support\dv.txt'),'w+'); 
        fprintf(fid,'%16.10f,',dv);%,\n
        status=fclose(fid);
        [ data ] = run_ansys( path );
         Y_new=280-abs(data(1)); % Ӧ��MPa  
         %Y_new=0.8-abs(data(2)); % Ӧ��MPa  
         %Y_new=400-abs(data(1)); % Ӧ��MPa  
     elseif type==46%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16 or 15  ����̬�ֲ�
       x1=x(1);  x2=x(2);  x3=x(3);  x4=x(4); x5=x(5); x6=x(6);
      Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+0.001*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );%example 16
 elseif type==461%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16 or 15  ��̬�ֲ�
       x1=x(1);  x2=x(2);  x3=x(3);  x4=x(4); x5=x(5); x6=x(6);
       Y_new=x1^0.5+2*x2^0.5+2*x3^0.5+x4^0.5-5*x5^0.5-5*x6^0.5;%example 16  ����
       Y_new=x1^0.5+2*x2+2*x3+x4^0.5-5*x5-5*x6^0.5;
       Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6^0.5;
       
    elseif type==462%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16 or 15  �� ��̬�ֲ�
       x1=x(1);  x2=x(2);  x3=x(3);  x4=x(4); x5=x(5); x6=x(6);
       Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+0.001*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );%example 16 �ҵķ�����
       %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+1e-5*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  %����2��   %example 16
       %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+4e-5*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  %����2��   %example 16
       %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+4.3151e-5*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  %����2��   %example 16
       
       
       %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+4.3152e-5*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  ������  %example 16
       %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+0.0015*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  ������  %example 16
      %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+0.0025*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );%example 16
      %Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6;
      %Y_new=x1+2*x2+3*x3+x4-5*x5-5*x6;%example 15 
      
%       Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6+0.001704*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  %������
     %  Y_new=x1+2*x2+2*x3+x4-5*x5-5*x6^0.5+0.001702*sum( sin(100*x1)+ sin(100*x2)+sin(100*x3)+  sin(100*x4)+ sin(100*x5)+ sin(100*x6)    );  %������  �ҵķ�����
     elseif type==47%2015-HLRF�CBFGS optimization algorithm for structural reliability example 6
       %x1=x(1);  x2=x(2);  x3=x(3);  x4=x(4); x5=x(5); x6=x(6);
      Y_new=2; num=size(x,2);
      for i=1:num-1
          Y_new=Y_new+0.015*x(i)^5;
      end
      Y_new=Y_new-x(num)*0.5; 
      
      for i=1:num-2
          Y_new=Y_new+0.015*x(i)^2*x(i+1)^3*x(i+2)*1;
      end
      Y_new=Y_new-x(num-1)*x(num)*0.1; 
      
     elseif type==50%--Meta-heuristic search algorithms in truss optimization: Research on stability and complexity analyses P10 120 bar truss
             
                         [TRUSS, stress_tensile, stress_allow,dis,dis_allow]=Truss_analysis_120bar(x);
%              [TRUSS, stress_tensile, stress_allow,dis,dis_allow]=Truss_analysis_120bar(x);
%              dis_std=dis/dis_allow*0.005;
%              y=dis_std-0.01;
                        stress_tol=300;%stress_tol=stress_allow/58000*400
                          Y_new=stress_tol-stress_tensile/58000*400;
      elseif type==60%--zzzzzzzHybrid High Dimensional Model Representation for reliability analysis ��Ҫ--ʵ��4 Example 11
        %     if aa.initial_sample==1
              example4_sim_xiu(x,aa.bjc,aa);
            Y_new=fun_val.con3;%����2��¥��λ�Ʋ�  
            %g=example4_sim_xiu(x,aa.bjc,aa);      %none of inter-story displacements exceeds 0.04 m
            if(Y_new<0)
                t=1;
            end
      elseif type==6||type==610%--zzzzz H:\����\����\���й���\0MATLAB����Ԫ����\0zzzz\zzz942_Bar_Truss 
             %Adaptive evolution strategies in structural optimization
             [yingli_max,dis_max]=Truss26ObjFnManual(x);
             Y_new=170-yingli_max;   
             Y_new=0.381-dis_max;   
       elseif type==49%Chapter 33: Analysis of a Piezoelectric Flextensional Transducer in Water 
            dv=x;
            fid=fopen(strcat(path,'\test_ansys\Transducer\dv.txt'),'w+'); 
            fprintf(fid,'%16.10f,',dv);%,\n
            status=fclose(fid);
            [ data ] = run_ansys( path );
            Y_new=145-abs(data(1));
           % Y_new=0.6-abs(data(1)); % ������    
    end 
    t=1;
    
    
    
    
    

    
    
    
    
    