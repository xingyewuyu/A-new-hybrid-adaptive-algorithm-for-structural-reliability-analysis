function ObjVal=Truss_analysis_120bar_obj_fun(Individual)

Truss_Data=TrussData_120bar(Individual);

Truss_Data.A(1:12,:)=Individual(1);
Truss_Data.A(13:24,:)=Individual(2);
Truss_Data.A(25:36,:)=Individual(3);
Truss_Data.A(37:60,:)=Individual(4);
Truss_Data.A(61:84,:)=Individual(5);
Truss_Data.A(85:96,:)=Individual(6);
Truss_Data.A(97:120,:)=Individual(7);


dnsay=size(Truss_Data.dnkoor,1);
elsay=size(Truss_Data.eldn,1);

topser=dnsay*3;
yer=zeros(topser,1);

[rijitlik,elboy]=stiffness_3D_truss(topser,elsay,Truss_Data.eldn,Truss_Data.dnkoor,Truss_Data.E,Truss_Data.A);


%% Object Function
ObjVal=0;
for i=1:size(Truss_Data.eldn,1)
ObjVal=ObjVal+elboy(i)*Truss_Data.A(i);%*Truss_Data.GS;
end
% 
% %% Penalized Obj. Func.
% PEN=10^8;
% Z=ObjVal;
% for k=1:length(gg)
%      Z=Z+ PEN*gg(k);
% end
% TRUSS.PENALIZED=Z;
