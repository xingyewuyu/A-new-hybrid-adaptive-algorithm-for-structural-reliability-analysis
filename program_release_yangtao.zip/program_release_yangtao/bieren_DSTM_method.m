function [ x,beta,pf, UU,xx,gg ,n_vector,nn,array_beta,num_g  ] = bieren_DSTM_method( u,std,type, if_plot0 )
%An efficient -robust structural reliability method by adaptive finite-step
%length based on Armijo line sear
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  
tmp_bjc=bjc;  tmp_u=u; 

hui=0.05;
nn=0;aa.inner_num_g=0;
while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
    x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==3 ||type==6 
                   if type==3
                       num_tmp=num-2;
                   elseif type==6
                       num_tmp=num;    
                   end   
                   X=x_start;
                   VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
                   t=1;
            elseif type==4     
                   X=x_start;
                   aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
                   F_x=1-evcdf(-X,-uu,1./aofa);  pdf_x=pdf('ev',-X,-uu,1./aofa);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u=X-inv_norm_F_x.*tmp_bjc;  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   t=1;
            elseif type==7||type==9%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
                   t=1;
            end 
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
    end

    [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);

    diff_g_x=diff_g_x_bj./tmp_bjc;
    gs=diff_g_x.*tmp_bjc;
%     tidu_bj=tidu.*bjc;
       beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  array_beta=[array_beta;beta];
       beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
       u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
       alpha=-gs./norm(gs);%----------------���ݶȷ���
     x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;

      if nn>0
         u_k_HL=U_k_new;  
         n_k=x_start_bj+hui*(u_k_HL-x_start_bj);
         plot(n_k(1),n_k(2),'*');
         n_k=n_k/norm(n_k);
         U_k_new=beta*n_k;
         beta=norm(U_k_new);
         plot(U_k_new(1),U_k_new(2),'*'); 
      end
     x=tmp_u+U_k_new.*tmp_bjc;

    xx=[xx;x];

    %nn
    kkt=[kkt ;U_k_new/norm(U_k_new)+diff_g_x_bj/norm(diff_g_x_bj)];
    
   if nn>=1
      theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
      theta(nn,:)=acos(theta(nn,:))/pi*180;
   end

   nn=nn+1;[beta nn]
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
   % t1 = toc  % ���㾭����ʱ��
    if nn-1>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
    end
end
%nn=nn-1;
pf=normcdf(-beta);%55.5299
%gg=[gg; fun(xx(end,:),type)]; 
UU=[UU; U_k_new];  num_g=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU; aa.kkt=kkt;  aa.theta=theta; 
aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
  plot(UU(:,1),UU(:,2),'-bo');
  plot(UU(:,1),UU(:,2),'-g');
t=1;
end


