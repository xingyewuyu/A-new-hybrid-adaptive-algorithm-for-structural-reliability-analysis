function   [g_diff_x]=diff_chafen_lagelangri_function(u_k,u_delta,tmp_u,tmp_bjc,g_output,type,ramba_k)
%global num_con_fun1 fun_val
global aa;
num=max(size(u_k)); g_diff_x=zeros(1,num); 
% g_output=feval('fun',x_k);  aa.inner_num_g=aa.inner_num_g+1;
%if  if_compute_tidu==1   

fun_lagelangri0=0.5*u_k*u_k'+g_output*ramba_k;

%u_k_new=u_k;
x_k=tmp_u+u_k.*tmp_bjc; 
        for i=1:num
            u_new=u_k;
            u_new(i)=u_k(i)+u_delta;
            x_tmp=tmp_u+u_new.*tmp_bjc;
            
            g_new=0.5*u_new*u_new' +fun(x_tmp,type)*ramba_k;%ƫ��ֵ
            g_diff(i)=(g_new-g_output)/u_delta;

%             x_k_new=x_k;
%             x_k_new(i)=x_k(i)+u_delta;
%             u_k_new=(x_k_new-tmp_u)./tmp_bjc;
%             g_new(i)=0.5*u_k_new*u_k_new' +fun(x_k_new,type)*ramba_k;%ƫ��ֵ
%             g_diff_x(i)=(g_new(i)-g_output)/u_delta;
        end
        aa.inner_num_g=aa.inner_num_g+num;
        %g_diff =g_diff';
%end
        
        
     
t=1;