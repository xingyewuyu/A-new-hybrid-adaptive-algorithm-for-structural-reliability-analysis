function [ x,beta,pf, UU,xx,gg ,n_vector,nn ] = bieren_robust_approximation_method( u,std,type )
         
%��������A robust approximation method for nonlinear cases of structural reliability analysis�ķ���
global aa;
u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
gg=[]; xx=u; beta_record=[]; g_record=[]; UU=[];
%UU=zeros(1,num);
weishu=num;
theta_k=0;
nn=0; 
hui_para=0.2;%----�����������Ҫ��ԽСԽ�ã����ǵ�����������
ramba=0.1;    tmp_bjc=bjc;  tmp_u=u;
%hui_para=0.9; ramba=0.1;  
while (1)%abs(norm(x)-last_normx)/norm(x)>1e-6
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    x_start=x;X=x_start;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
    x_start_bj=(x_start-tmp_u)./tmp_bjc;
%         if aa.nn==2
%             t=1; 
%         end
            if  type==4||type==325 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==325
                    num_tmp=num;    
                 end   
                
%                 u=X.*(6.517-log(X));
%                 bjc=aa.bjc./aa.u.*X;
                %aa.u=250;aa.bjc=25; X=210;
                %https://blog.csdn.net/wanjiac/article/details/125057533 ������̫�ֲ� ��������
%                 logn_para_u=log(u(1:num).^2./(bjc(1:num).^2+u(1:num).^2).^0.5);
%                 logn_para_sigma=(log(  bjc(1:num).^2./u(1:num).^2+1)  ).^0.5;
%                 F_x=cdf('logn',X,logn_para_u,logn_para_sigma);
%                 inv_norm_F_x=icdf('normal',F_x,0,1);
%                 tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X,logn_para_u,logn_para_sigma);
%                 tmp_u=X-inv_norm_F_x.*tmp_bjc;
%                 bjc(1:num)=tmp_bjc;  u(1:num)=tmp_u;
%                 x_start_bj(1:num)= ( X-u(1:num) )./bjc(1:num);
%                u=365.8;bjc=54.9;X=u;
                X=x_start;
                VV=bjc./u;
                   tmp_bjc(1:num_tmp)=X(1:num_tmp).*(log(1+VV(1:num_tmp).^2)).^0.5;
                   tmp_u(1:num_tmp)=X(1:num_tmp).*(1-log(X(1:num_tmp))+log(u(1:num_tmp)./(1+VV(1:num_tmp).^2).^0.5));  
                   x_start_bj(1:num_tmp)=( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
%                 logn_para_u=log(u.^2./(bjc.^2+u.^2).^0.5);
%                 logn_para_sigma=(log(  bjc.^2./u.^2+1)  ).^0.5;
%                 F_x=cdf('logn',X,logn_para_u,logn_para_sigma);
%                 inv_norm_F_x=icdf('normal',F_x,0,1);
%                 tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X,logn_para_u,logn_para_sigma);
%                tmp_u=X-inv_norm_F_x.*tmp_bjc;
                %bjc=tmp_bjc;  u=tmp_u;
                %x_start_bj= ( X-tmp_u )./tmp_bjc;
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��ֵ�ֲ���̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
%                    mu=100;sigma=12;
%                    aEv=sqrt(6)*sigma/pi;  uEv=-psi(1)*aEv-mu;
%                    FQ=1-evcdf(-150,uEv,aEv);%
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
            elseif type==401%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-3+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
            end 
        UU=[UU; x_start_bj];   
        if nn==0
            delta0=aa.delta;%delta0=1e-4;%delta0=aa.jingdu;%aa.jingdu
        else
            delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        end
        for i=1:weishu
            %delta0=1e-10;
            u_new=x_start_bj;
            u_new(i)=x_start_bj(i)+delta0;
            x_tmp=tmp_u+u_new.*tmp_bjc;
            g_new(i)= fun(x_tmp,type);%ƫ��ֵ
            diff_g_x_bj(i)=(g_new(i)-g_start)/delta0;
        end
        aa.inner_num_g=aa.inner_num_g+num;
        

        if nn<1
            beta=-(diff_g_x_bj*x_start_bj'-g_start)/norm(diff_g_x_bj);%beta=-(diff_g_x_bj*x_start_bj'-g_start)/norm(diff_g_x_bj);
            U_k_new=-beta*diff_g_x_bj/norm(diff_g_x_bj);
             %U_k_new=(diff_g_x_bj*x_start_bj'-g_start)*diff_g_x_bj/norm(diff_g_x_bj)^2;
        else
             A_k=x_start_bj-hui_para*diff_g_x_bj/norm(diff_g_x_bj);%9
             V_k=A_k/norm(A_k);%10
             beta=(diff_g_x_bj*x_start_bj'-g_start*(1-ramba))/(diff_g_x_bj*V_k');%13
             U_k_new=beta*V_k;%11
        end
   
   
    x=U_k_new.*tmp_bjc+tmp_u;
    %UU=[UU; U_k_new];
    g_record=[g_record;g_start];
    xx=[xx;x];
    beta_record=[beta_record; beta];
    
    if nn>=1
        %if norm(beta-beta_last)<aa.jingdu
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
    end
    beta_last=beta;

    
    nn=nn+1;
    aa.nn=nn;
end
nn=nn+1;
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)]; UU=[UU;U_k_new];
aa.gg=gg; aa.xx=xx;aa.UU=UU;
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
t=1;
end

