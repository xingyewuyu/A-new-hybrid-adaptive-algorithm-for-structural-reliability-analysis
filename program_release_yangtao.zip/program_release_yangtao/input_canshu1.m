function [u bjc var jingdu]=input_canshu1(type)
global aa;
aa.delta=1e-4;%��ּ�����
aa.jingdu=1e-3;% 

    if type==1  % Case 1 in Example 1 The 2-dimensional functions
          u=  [0 0];%Nc Nf nc nf theta1 theta2
          bjc=[1 1];var=bjc.^2;
          jingdu=1e-3;aa.ymax=3;
    elseif type==2    % Case 2 in Example 1 The 2-dimensional functions 
          u=  [0 0];%һ�ֽṹ�ɿ���ָ�����������          ����ṹ�ɿ���ָ������������㷨 �� 2
          bjc=[1 1 ]*1;var=bjc.^2; aa.bjc=bjc; aa.u=u;
          jingdu=1e-4;        aa.ymax=5;
    elseif type==3    %   Example 2  The 6-dimensional nonlinear performance function with non-normal variables. 
          u=[5490 17100 549 4000 0.42 6];bjc=u.*0.15; aa.ymax=8;
          var=bjc.^2;jingdu=1e-4;%�����ֲ� �����ֲ� �����ֲ�  �����ֲ� ��̬�ֲ� ��̬�ֲ�
    elseif type==4    %   Example 3 The strong non-linear performance function with high dimension
          num=30;
          u=  ones(1,num);  % ��ֵ�ֲ�
          bjc=ones(1,num)*1;var=bjc.^2;jingdu=1e-4;aa.ymax=4;%  %   
    elseif type==5    %   Example 4 The 9-dimensional engineering case with norm variables.
          u=  [10e6  30e6  0.15   0.1   0.2e6   1    1.1   2000 4100 ];
          bjc=[0.1e6 0.3e6 0.0015 0.001 0.002e6 0.01 0.011 20   41  ];
          c=[0.02];
          bjc=u*c;
          var=bjc.^2;
          jingdu=1e-4;aa.ymax=6;    
    elseif type==6    %   Example 5 The 8-dimensional strong nonlinear engineering case with non-normal variables.
          u= [1    0.01  1   0.01  0.05  0.02  15 100];  % kp ks mp ms hui_p hui_s Fs S0                            adaptive �� hui_para=0.1 0.05  xxxxxxxxxxxxxxxxxxxxxxxxxxx
          bjc=[0.2 0.002 0.1 0.001 0.02  0.01  1.5 10];var=bjc.^2;jingdu=1e-4; % Lognormal  
          aa.bjc=bjc; aa.u=u; aa.ymax=4;
    elseif type==7    %   Example 6  The 11-dimensional case of the 72-bar truss.
          d0=[ 45 45 10  2   2  2];   %��Ʊ�����Χȷ��  uB uD uH  a b c   ����a ,b ,c Ϊÿ��Ŀ���������
          u=  [d0                        2.1e11 7860   8000  8000   8000];
          c=  [ 0.1*ones(1,size(d0,2))  0.1   0.1      0.1   0.1   0.1 ]*1;
          bjc=u.*c;
          var=bjc.^2;jingdu=1e-4; aa.num_of_non_norm_variable=size(u,2); aa.ymax=20; t=1;
    elseif type==8    %   Example 7 The 13-dimensional nonlinear case of the four-storey building.
            aa.d_L=[     300   50  1000  1e4  100    100];  %m1 m2   k1  k2  c1 c2
            aa.d_U=[     800  300  5000  5e5  1000   1000];%��Ʊ�����Χȷ��
            aa.d0=(aa.d_L+aa.d_U)/2;    aa.d=aa.d_U; aa.d0=aa.d_L;
            %2�����������Χȷ��
            aa.u_x= [6e3  3e7  6e4 2e4  0.05 3e7  1    1 ];% 
            c= 0.1*ones(1,size(aa.u_x,2)); 
            aa.bjc_x=c.*aa.u_x; 
            aa.delta_x=aa.bjc_x*3;  
            u=[aa.d0 aa.u_x];   
            delta_danbian=[aa.d0*0.05 c.*aa.u_x   ];  
            bjc=delta_danbian/3;   var=bjc.^2;jingdu=1e-4; aa.ymax=6; 
    elseif type==9    %   Example 8 The bending transducer.
            A1=6.89e10;A2=0.3;A3=2710;
            R1=3e7 ;R2=0.39;R3=1100;
            P1x=7.407e10; P1yz=8.696e10;Gxyxz=3.135e10;Gyz=3.289e10;
            P2xy=0.303;P2yz=0.356;P2xz=0.322;
            P3=7600;
            P4x=561; P4yz=904;
            u_x=[ A1 A2 A3 R1 R2 R3 P1x P1yz Gxyxz Gyz P2xy P2yz P2xz P3 P4x P4yz]; %���������ֵ  0.1ΪĦ��ϵ�� 0.5Ϊ��϶�뾶  4260Ϊ������  50Ϊת���ٶ�
            u=[u_x];bjc=[ A1*0.1 A2*0.01 A3*0.1 R1*0.1 R2*0.01 R3*01 P1x*0.1 P1yz*0.1 Gxyxz*0.1 Gyz*0.1 P2xy*0.01 P2yz*0.01 P2xz*0.01 P3*0.1 P4x*0.1 P4yz*0.1]; %bjc=[u_1*0.1 u_2*0.01];
            var=bjc.^2;jingdu=1e-4; aa.num_of_non_norm_variable=size(u,2); aa.ymax=20;     
    end
aa.bjc=bjc; aa.u=u;











