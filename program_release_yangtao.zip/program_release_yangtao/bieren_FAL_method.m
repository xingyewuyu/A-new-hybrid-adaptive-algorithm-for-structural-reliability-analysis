function [ x,beta,pf, UU,xx,gg ,n_vector,nn,array_beta] = bieren_FAL_method( u,std,type, if_plot0  )
%An efficient -robust structural reliability method by adaptive finite-step
%length based on Armijo line sear  2018
global aa;



%---------��ͼ---------------------
hold off;
if if_plot0==1
    if aa.type==9||aa.type==10||aa.type==31||aa.type==8
        f0=fun(u,type);%���ֵ
        k1=-5; k2=5;
        if aa.type==9
                k1=-5; k2=5;
        elseif aa.type==10
                k1=-6; k2=6;
        end
        length0=0.5;t_min=-1.8;t_max=f0*1;jingdu=1e-2;
        a1=k1;a2=k2;b1=k1;b2=k2;%k1=-1; k2=5;a1=k1;a2=k2;b1=k1;b2=k2;
        [x1,x2] = meshgrid(a1:0.05:a2,b1:0.05:b2);   bjc=std;
        x1_ori=x1*bjc(1)+u(1);x2_ori=x2*bjc(2)+u(2);
        Z=fun([x1_ori,x2_ori],type) ;%;P=1;Z=(1/P)*log(exp(P*(1+x1-x2))+exp(P*(5-5*x1-x2)));  g=18.46154-74769.23*x1/x2^3
        t_min=-f0;t_max=f0;
        tt=t_min:(t_max-t_min)/3:t_max;%1e-10
        if aa.type~=31
            for i=1:size(tt,2)
                t_value=tt(i);
           [C,h] = contour(x1,x2,Z,t_value,'b');axis([a1 a2 b1 b2]); grid on;hold on;
            end
        end
        [C,h] = contour(x1,x2,Z,1e-8,'r');grid on;hold on;

        [xx1,xx2] = meshgrid(a1:0.5:a2,b1:0.5:b2);xx1_ori=xx1*bjc(1)+u(1);xx2_ori=xx2*bjc(2)+u(2);
        Z2=fun([xx1_ori,xx2_ori],type) ;[Dx1,Dx2]=gradient(Z2);
        %quiver(xx1,xx2,Dx1,Dx2,1); colormap hsv;hold on;
        t=1;
    end
    set(gcf,'color','white');%box off;grid off;
end












u1=u;std1=std;bjc=std;
x=u;last_normx=1e9;
num=size(x,2);
%UU=zeros(1,num); 
gg=[]; xx=u; diff=[]; error_diff=[]; error=[];UU=[]; kkt=[]; array_beta=[];  aa.theta=[];  

weishu=num;  tmp_bjc=bjc;  tmp_u=u; 
ramba_0=1; a=1; B=2; b=0.5; c=3; A=1; theta_min=30/180*pi; ramba_min=0.1; theta_0=180/180*pi; rou=0.5;
nn=0;
while 1%abs(norm(x)-last_normx)/norm(x)>aa.jingdu
    last_normx=norm(x);
%----------------------����ݶ�---------------------    
    X=x;x_start=X;
    g_start=fun(x_start,type); gg=[gg; g_start];   aa.inner_num_g=aa.inner_num_g+1;
% weishu=size(x_start,2);
x_start_bj=(x_start-tmp_u)./tmp_bjc;
            if  type==4 %||type==35%(strcmp(aa.type_variable,'logn'))
                if type==4
                    num_tmp=num-2;
                elseif type==35
                    num_tmp=2;    
                 end   
                X(1:num_tmp)=tmp_u(1:num_tmp)+tmp_bjc(1:num_tmp).*x_start_bj(1:num_tmp);
%                 u=X.*(6.517-log(X));
%                 bjc=aa.bjc./aa.u.*X;
                %aa.u=250;aa.bjc=25; X=210;
                logn_para_u=log(u(1:num_tmp).^2./(bjc(1:num_tmp).^2+u(1:num_tmp).^2).^0.5);
                logn_para_sigma=(log(  bjc(1:num_tmp).^2./u(1:num_tmp).^2+1)  ).^0.5;
                F_x=cdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                inv_norm_F_x=icdf('normal',F_x,0,1);
                tmp_bjc(1:num_tmp)=pdf('normal',inv_norm_F_x,0,1)./pdf('logn',X(1:num_tmp),logn_para_u,logn_para_sigma);
                tmp_u(1:num_tmp)=X(1:num_tmp)-inv_norm_F_x.*tmp_bjc(1:num_tmp);
                x_start_bj(1:num_tmp)= ( X(1:num_tmp)-tmp_u(1:num_tmp) )./tmp_bjc(1:num_tmp);
            elseif type==39  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   tmp_bjc(3)=X(3).*(log(1+VV(3).^2)).^0.5;
                   tmp_u(3)=X(3).*(1-log(X(3))+log(u(3)./(1+VV(3).^2).^0.5));  x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   %SQ��̬��
                   %����һ���ο� https://blog.csdn.net/leo2351960/article/details/39210807
%                    mu=100;sigma=12;
%                    aEv=sqrt(6)*sigma/pi;  uEv=-psi(1)*aEv-mu;
%                    FQ=1-evcdf(-150,uEv,aEv);%
                   aEv=sqrt(6)*bjc(2)/pi; uEv=-psi(1)*aEv-u(2);
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X(2),uEv,aEv);
                   %������
                   aofa=pi/6^0.5/bjc(2); uu=u(2)+psi(1)/aofa;  
                   F_x4=1-evcdf(-X(2),-uu,1/aofa);%F_x3=exp(-exp(-aofa*(X(2)-uu)));
                   pdf_x4=pdf('ev',-X(2),-uu,1/aofa);%pdf_x3=aofa*exp(-aofa*(X(2)-uu)-exp(-aofa*(X(2)-uu)))

                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc(2)=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u(2)=X(2)-inv_norm_F_x.*tmp_bjc(2);  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==47     
                   X=x_start;
                   aofa=pi/6^0.5./bjc; uu=u+psi(1)./aofa;  
                   F_x=1-evcdf(-X,-uu,1./aofa);  pdf_x=pdf('ev',-X,-uu,1./aofa);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u=X-inv_norm_F_x.*tmp_bjc;  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   t=1;
            elseif type==430  
                   X=x_start;
                   VV=bjc./u;
                   %R��̬��
                   aEv=sqrt(6)*bjc((5:7))/pi; uEv=-psi(1)*aEv-u((5:7));
                   F_x=1-evcdf(-X(2),uEv,aEv);%  evcdfΪ Fxmin(-x)  F_x=Fxmax(x)=1-evcdf
                   pdf_x=pdf('ev',-X((5:7)),uEv,aEv);
                   inv_norm_F_x=icdf('normal',F_x,0,1);  
                   tmp_bjc((5:7))=pdf('normal',inv_norm_F_x,0,1)./pdf_x;
                   tmp_u((5:7))=X((5:7))-inv_norm_F_x.*tmp_bjc((5:7));  
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   %x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==46||type==610||type==37||type==47||type==325%2015-HLRF�CBFGS optimization algorithm for structural reliability example 16  
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_bjc=X.*(log(1+VV.^2)).^0.5;
                   tmp_u=X.*(1-log(X)+log(u./(1+VV.^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj=( X-tmp_u )./tmp_bjc;
            elseif type==401%--Matlab����Ԫ�ṹ����ѧ�����빤��Ӧ��   example8.2 ���Ӹ� -------------------------------------������ʵ��1 
                   num=size(x_start,2); nn_start=num-aa.num_of_non_norm_variable+1;
                   X=x_start;
                   VV=bjc./u;
                   %R������̫�ֲ� ��̬��
                   tmp_u=u;tmp_bjc=bjc;
                   x_start_bj=( X-tmp_u )./tmp_bjc;
                   
                   tmp_bjc(nn_start:end)=X(nn_start:end).*(log(1+VV((nn_start:end)).^2)).^0.5;
                   tmp_u(nn_start:end)=X(nn_start:end).*(1-log(X(nn_start:end))+log(u((nn_start:end))./(1+VV((nn_start:end)).^2).^0.5));  %x_start_bj(3)=(X(3)-tmp_u(3))/tmp_bjc(3);
                   x_start_bj(nn_start:end)=( X(nn_start:end)-tmp_u(nn_start:end) )./tmp_bjc(nn_start:end);
            end         
            if if_plot0==1
                 plot(x_start_bj(1),x_start_bj(2),'d'); 
            end
    UU=[UU; x_start_bj]; 
    if nn==0
        delta0=aa.delta;%delta0=1e-6;%delta0=aa.jingdu;%aa.jingdu  1e-3---�ʺ�type=44
    else
        delta0=min(norm(UU(end-1,:)-x_start_bj)*0.01,delta0);
        %norm(UU(end-1,:)-x_start_bj)
    end
    %delta0
    
    %delta0
    [diff_g_x_bj]=diff_chafen(x_start_bj,delta0,tmp_u,tmp_bjc,g_start,type);
%     %diff_g_x_bj
%                 if isnan(diff_g_x_bj(1))
%                     t=1;
%                 end
%     diff_g_x=diff_g_x_bj./tmp_bjc;
%     gs=diff_g_x.*tmp_bjc;
% %     tidu_bj=tidu.*bjc;
%        beta=(g_start-diff_g_x*(X-tmp_u)')/norm(gs);  array_beta=[array_beta;beta];
%        beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
%        u_k=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
%        alpha=-gs./norm(gs);%----------------���ݶȷ���
%      x=tmp_u+beta*tmp_bjc.*alpha;   U_k_new=(x-tmp_u)./tmp_bjc;
     if nn>0
                 beta2=(g_start-diff_g_x_bj*x_start_bj')/norm(diff_g_x_bj);
                 u_k_HL=-beta2*diff_g_x_bj/norm(diff_g_x_bj);
                 dk=norm(u_k_HL-x_start_bj);
                 dk_minus_1=norm(x_start_bj-UU(end-1,:));
                 if dk<dk_minus_1
                         delta_k=1;
                 elseif dk_minus_1<=dk&& dk<1.05*dk_minus_1
                         delta_k=0.95;
                 else% dk>1.05*dk_minus_
                         delta_k=max(0.75 ,0.85*dk_minus_1/dk   ); 
                 end

     else
         ramba_k=min(50/norm(diff_g_x_bj)^2,50);
         delta_k=1;
     end
     ramba_k=delta_k*ramba_k;
     n_k=(x_start_bj-ramba_k*diff_g_x_bj)/norm(x_start_bj-ramba_k*diff_g_x_bj);
     beta=-(g_start-diff_g_x_bj*x_start_bj')/(diff_g_x_bj*n_k');
     U_k_new=beta*n_k;
     x=tmp_u+U_k_new.*tmp_bjc;
    %UU=[UU; U_k_new];
    diff=[ diff;  diff_g_x_bj]; 
    if size(diff,1)>=2
        error_diff=[error_diff; diff(end,:)-diff(end-1,:)];
        error=[error;  norm(error_diff(end,:))];
    end
    xx=[xx;X];

    %nn
    kkt=[kkt ;U_k_new/norm(U_k_new)+diff_g_x_bj/norm(diff_g_x_bj)];
    
       %theta(nn,:)=acos(U_k_new*diff_g_x_bj'/norm(U_k_new)/norm(diff_g_x_bj))/pi*180;
   if nn>=1
      theta(nn,:)=(x_start_bj*diff_g_x_bj'/norm(x_start_bj)/norm(diff_g_x_bj)); 
      theta(nn,:)=acos(theta(nn,:))/pi*180;
   end
   array_beta=[array_beta ;norm(U_k_new) ];
   nn=nn+1;  [beta nn]

   
        aa.gg=gg;aa.UU=UU;  aa.beta=array_beta;%beta
    %t1 = toc  % ���㾭����ʱ��
    if nn-1>=1
        if norm(U_k_new-x_start_bj)/norm(U_k_new)<aa.jingdu
          break;
        end
    end
end
%nn=nn-1;
pf=normcdf(-beta);%55.5299
gg=[gg; fun(xx(end,:),type)];  UU=[UU; U_k_new];  g_num=aa.inner_num_g;
aa.gg=gg; aa.xx=xx;aa.UU=UU; aa.kkt=kkt;  aa.theta=theta; 
aa.sensitive=diff_g_x_bj/norm(diff_g_x_bj);%.*bjc;
aa.sensitive=[aa.sensitive;x_start_bj/norm(x_start_bj);];
n_vector=[];
 for i=2:size(UU,1)
    n_vector=[n_vector;UU(i,:)/norm(UU(i,:))  ];
 end
 UU=round( UU*10000)/10000;n_vector=round( n_vector*10000)/10000;
   plot(UU(:,1),UU(:,2),'-bo');
  plot(UU(:,1),UU(:,2),'-g');
t=1;
end


%        diff_g_x=diff_g_x_bj./std;
%     %����Ƕȣ��ɿ���ֵ���µ������
%     gs=diff_g_x_bj;
%     alpha=-gs/norm(gs);%----------------���ݶȷ���
%     beta=(g_start+diff_g_x*(u-x)')/norm(gs);
%     x=u+beta*std.*alpha;   
%     UU=[UU; (x-u)./std];
